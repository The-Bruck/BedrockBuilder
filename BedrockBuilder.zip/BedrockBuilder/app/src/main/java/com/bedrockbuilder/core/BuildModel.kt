package com.bedrockbuilder.core

/**
 * Sparse voxel model. Coordinates are absolute editing coordinates; the grid is the inclusive
 * box [minX..maxX] x [minY..maxY] x [minZ..maxZ]. On export everything is shifted to start at 0.
 */
class BuildModel {
    val palette = ArrayList<BlockState>()
    private val paletteIndex = HashMap<BlockState, Int>()
    val blocks = HashMap<Long, Int>()
    /** Second block layer (waterlogging etc.), preserved from imports. */
    val secondary = HashMap<Long, Int>()
    val blockEntities = HashMap<Long, CompoundTag>()
    var entities: List<Tag> = emptyList()
    var origin = intArrayOf(0, 0, 0)
    /** Export empty cells as minecraft:air (replaces terrain when loaded) instead of "keep existing". */
    var emptyAsAir = false

    var minX = 0; var minY = 0; var minZ = 0
    var maxX = 15; var maxY = 15; var maxZ = 15

    val sizeX get() = maxX - minX + 1
    val sizeY get() = maxY - minY + 1
    val sizeZ get() = maxZ - minZ + 1
    val blockCount get() = blocks.size

    fun idFor(state: BlockState): Int =
        paletteIndex.getOrPut(state) { palette.add(state); palette.size - 1 }

    fun getId(x: Int, y: Int, z: Int): Int = blocks[key(x, y, z)] ?: -1
    fun get(x: Int, y: Int, z: Int): BlockState? = blocks[key(x, y, z)]?.let { palette[it] }
    fun has(x: Int, y: Int, z: Int) = blocks.containsKey(key(x, y, z))

    fun inBounds(x: Int, y: Int, z: Int) =
        x in minX..maxX && y in minY..maxY && z in minZ..maxZ

    fun set(x: Int, y: Int, z: Int, state: BlockState?) {
        setId(key(x, y, z), if (state == null) -1 else idFor(state))
    }

    fun setId(key: Long, newId: Int) {
        val old = blocks[key] ?: -1
        if (old == newId) return
        if (newId < 0) blocks.remove(key) else blocks[key] = newId
        if (old >= 0 && (newId < 0 || palette[old].name != palette[newId].name)) {
            secondary.remove(key); blockEntities.remove(key)
        }
    }

    fun restore(key: Long, id: Int, sec: Int, be: CompoundTag?) {
        if (id < 0) blocks.remove(key) else blocks[key] = id
        if (sec >= 0) secondary[key] = sec else secondary.remove(key)
        if (be != null) blockEntities[key] = be else blockEntities.remove(key)
    }

    // ---- bounds -------------------------------------------------------------------------

    fun boundsValid(x0: Int, y0: Int, z0: Int, x1: Int, y1: Int, z1: Int): Boolean {
        val sx = x1 - x0 + 1; val sy = y1 - y0 + 1; val sz = z1 - z0 + 1
        if (sx < 1 || sy < 1 || sz < 1) return false
        if (sx > MAX_AXIS || sy > MAX_AXIS || sz > MAX_AXIS) return false
        return sx.toLong() * sy * sz <= MAX_VOLUME
    }

    /** Grows the grid to include the box. Returns false (and changes nothing) if limits would be exceeded. */
    fun expandToInclude(x0: Int, y0: Int, z0: Int, x1: Int, y1: Int, z1: Int): Boolean {
        val nx0 = minOf(minX, x0); val ny0 = minOf(minY, y0); val nz0 = minOf(minZ, z0)
        val nx1 = maxOf(maxX, x1); val ny1 = maxOf(maxY, y1); val nz1 = maxOf(maxZ, z1)
        if (nx0 == minX && ny0 == minY && nz0 == minZ && nx1 == maxX && ny1 == maxY && nz1 == maxZ) return true
        if (!boundsValid(nx0, ny0, nz0, nx1, ny1, nz1)) return false
        minX = nx0; minY = ny0; minZ = nz0; maxX = nx1; maxY = ny1; maxZ = nz1
        return true
    }

    /** Bounding box of all blocks as [minX,minY,minZ,maxX,maxY,maxZ], or null if empty. */
    fun usedBounds(): IntArray? {
        if (blocks.isEmpty()) return null
        var x0 = Int.MAX_VALUE; var y0 = Int.MAX_VALUE; var z0 = Int.MAX_VALUE
        var x1 = Int.MIN_VALUE; var y1 = Int.MIN_VALUE; var z1 = Int.MIN_VALUE
        for (k in blocks.keys) {
            val x = kx(k); val y = ky(k); val z = kz(k)
            if (x < x0) x0 = x; if (x > x1) x1 = x
            if (y < y0) y0 = y; if (y > y1) y1 = y
            if (z < z0) z0 = z; if (z > z1) z1 = z
        }
        return intArrayOf(x0, y0, z0, x1, y1, z1)
    }

    /**
     * Moves one side of the grid. axis 0..2 = X,Y,Z; high=true moves the max side. delta>0 grows.
     * Shrinking never cuts blocks. Returns an error message or null.
     */
    fun resizeSide(axis: Int, high: Boolean, delta: Int): String? {
        val lo = intArrayOf(minX, minY, minZ); val hi = intArrayOf(maxX, maxY, maxZ)
        if (high) hi[axis] += delta else lo[axis] -= delta
        if (hi[axis] < lo[axis]) return "Grid must be at least 1 block"
        if (delta < 0) {
            usedBounds()?.let { u ->
                if (high && hi[axis] < u[3 + axis] || !high && lo[axis] > u[axis]) return "Blocks would be cut off"
            }
        }
        if (!boundsValid(lo[0], lo[1], lo[2], hi[0], hi[1], hi[2]))
            return "Limit: $MAX_AXIS per axis, ${MAX_VOLUME / 1_000_000.0}M cells"
        minX = lo[0]; minY = lo[1]; minZ = lo[2]; maxX = hi[0]; maxY = hi[1]; maxZ = hi[2]
        return null
    }

    /**
     * Dynamic grid: the grid hugs the blocks plus a margin, growing and shrinking as you build.
     * Does nothing while the model is empty.
     */
    fun applyDynamicBounds(margin: Int = 3, minSize: Int = 8) {
        val u = usedBounds() ?: return
        var x0 = u[0] - margin; var x1 = u[3] + margin
        var y0 = u[1] - 1; var y1 = u[4] + margin
        var z0 = u[2] - margin; var z1 = u[5] + margin
        fun pad(lo: Int, hi: Int): IntArray {
            var a = lo; var b = hi
            while (b - a + 1 < minSize) { if ((b - a) % 2 == 0) b++ else a-- }
            return intArrayOf(a, b)
        }
        pad(x0, x1).let { x0 = it[0]; x1 = it[1] }
        pad(y0, y1).let { y0 = it[0]; y1 = it[1] }
        pad(z0, z1).let { z0 = it[0]; z1 = it[1] }
        if (!boundsValid(x0, y0, z0, x1, y1, z1)) {
            x0 = u[0]; y0 = u[1]; z0 = u[2]; x1 = u[3]; y1 = u[4]; z1 = u[5]
            if (!boundsValid(x0, y0, z0, x1, y1, z1)) return
        }
        minX = x0; minY = y0; minZ = z0; maxX = x1; maxY = y1; maxZ = z1
    }

    fun fitToBlocks() {
        val u = usedBounds() ?: return
        minX = u[0]; minY = u[1]; minZ = u[2]; maxX = u[3]; maxY = u[4]; maxZ = u[5]
    }

    companion object {
        const val MAX_AXIS = 256
        const val MAX_VOLUME = 4_194_304L
        private const val OFF = 1 shl 20
        private const val MASK = 0x1FFFFF

        fun key(x: Int, y: Int, z: Int): Long =
            ((x + OFF).toLong() shl 42) or ((y + OFF).toLong() shl 21) or (z + OFF).toLong()
        fun kx(k: Long): Int = ((k shr 42) and MASK.toLong()).toInt() - OFF
        fun ky(k: Long): Int = ((k shr 21) and MASK.toLong()).toInt() - OFF
        fun kz(k: Long): Int = (k and MASK.toLong()).toInt() - OFF

        fun create(sx: Int, sy: Int, sz: Int): BuildModel {
            val m = BuildModel()
            m.maxX = sx - 1; m.maxY = sy - 1; m.maxZ = sz - 1
            return m
        }
    }
}
