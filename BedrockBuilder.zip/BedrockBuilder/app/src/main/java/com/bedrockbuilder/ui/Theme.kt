package com.bedrockbuilder.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF7FD962), onPrimary = Color(0xFF0B2A00),
    secondary = Color(0xFF9FB4C8), tertiary = Color(0xFFF2B866),
    background = Color(0xFF10141B), surface = Color(0xFF171C25),
    surfaceVariant = Color(0xFF273040), onSurface = Color(0xFFE4E8EE),
)
private val Light = lightColorScheme(
    primary = Color(0xFF2F7D1B), secondary = Color(0xFF4A6178), tertiary = Color(0xFF8A5A00),
    background = Color(0xFFFBFCFF), surface = Color(0xFFF2F4F8),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
