package com.bedrockbuilder.core

import java.util.Random

/** Provides the block(s) used when placing: a single block or a weighted random palette. */
interface BlockSource {
    val blocks: List<BlockState>
    /** Index into [blocks] for the next cell to place. */
    fun nextIndex(): Int
}

class SingleBlock(private val block: BlockState) : BlockSource {
    override val blocks: List<BlockState> = listOf(block)
    override fun nextIndex() = 0
}

class WeightedPalette(
    override val blocks: List<BlockState>, weights: List<Int>, private val rnd: Random = Random(),
) : BlockSource {
    private val cumulative = IntArray(blocks.size)
    private val total: Int

    init {
        require(blocks.isNotEmpty()) { "Palette is empty" }
        var t = 0
        for (i in blocks.indices) { t += maxOf(1, weights.getOrElse(i) { 1 }); cumulative[i] = t }
        total = t
    }

    override fun nextIndex(): Int {
        val r = rnd.nextInt(total)
        for (i in cumulative.indices) if (r < cumulative[i]) return i
        return cumulative.size - 1
    }
}
