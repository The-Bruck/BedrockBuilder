package com.bedrockbuilder.core

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

class Basis(
    val px: Float, val py: Float, val pz: Float,
    val rx: Float, val ry: Float, val rz: Float,
    val ux: Float, val uy: Float, val uz: Float,
    val fx: Float, val fy: Float, val fz: Float,
)

object Projection {
    private val TAN_HALF_FOV = tan(Math.toRadians(22.5)).toFloat()
    fun focal(w: Float, h: Float): Float = min(w, h) / (2f * TAN_HALF_FOV)
}

/** Orbit camera. World: +X east, +Y up, +Z south. A cell (x,y,z) spans [x,x+1] etc. */
data class Camera(
    val yaw: Float = 35f, val pitch: Float = 30f, val dist: Float = 24f,
    val tx: Float = 8f, val ty: Float = 8f, val tz: Float = 8f,
) {
    fun basis(): Basis {
        val yr = Math.toRadians(yaw.toDouble()); val pr = Math.toRadians(pitch.toDouble())
        val cp = cos(pr)
        val ox = (cp * sin(yr)).toFloat(); val oy = sin(pr).toFloat(); val oz = (cp * cos(yr)).toFloat()
        val fx = -ox; val fy = -oy; val fz = -oz
        var rx = -fz; var rz = fx
        val rl = sqrt(rx * rx + rz * rz)
        rx /= rl; rz /= rl
        // up = right x forward
        val ux = -rz * fy
        val uy = rz * fx - rx * fz
        val uz = rx * fy
        return Basis(tx + ox * dist, ty + oy * dist, tz + oz * dist, rx, 0f, rz, ux, uy, uz, fx, fy, fz)
    }

    fun orbit(dYaw: Float, dPitch: Float) =
        copy(yaw = (yaw + dYaw) % 360f, pitch = (pitch + dPitch).coerceIn(-89f, 89f))

    fun zoom(factor: Float) = copy(dist = (dist / factor).coerceIn(1.5f, 900f))

    fun pan(dxPx: Float, dyPx: Float, w: Float, h: Float): Camera {
        val b = basis(); val s = dist / Projection.focal(w, h)
        return copy(
            tx = tx - b.rx * dxPx * s + b.ux * dyPx * s,
            ty = ty - b.ry * dxPx * s + b.uy * dyPx * s,
            tz = tz - b.rz * dxPx * s + b.uz * dyPx * s,
        )
    }

    companion object {
        fun fit(m: BuildModel, yaw: Float = 35f, pitch: Float = 30f): Camera {
            val sx = m.sizeX.toFloat(); val sy = m.sizeY.toFloat(); val sz = m.sizeZ.toFloat()
            val r = 0.5f * sqrt(sx * sx + sy * sy + sz * sz)
            return Camera(yaw, pitch, max(8f, r * 2.7f),
                m.minX + sx / 2f, m.minY + sy / 2f, m.minZ + sz / 2f)
        }
    }
}

class Projector(cam: Camera, val w: Float, val h: Float) {
    val b = cam.basis()
    val f = Projection.focal(w, h)
    private val cx = w / 2f
    private val cy = h / 2f
    private val near = 0.05f

    /** Projects a point; writes screen x,y to out[o], out[o+1]. Returns false if behind the camera. */
    fun project(x: Float, y: Float, z: Float, out: FloatArray, o: Int): Boolean {
        val vx = x - b.px; val vy = y - b.py; val vz = z - b.pz
        val zc = vx * b.fx + vy * b.fy + vz * b.fz
        if (zc < near) return false
        out[o] = cx + f * (vx * b.rx + vy * b.ry + vz * b.rz) / zc
        out[o + 1] = cy - f * (vx * b.ux + vy * b.uy + vz * b.uz) / zc
        return true
    }

    private fun depth(x: Float, y: Float, z: Float) =
        (x - b.px) * b.fx + (y - b.py) * b.fy + (z - b.pz) * b.fz

    /** Projects a line segment clipped to the near plane. Writes x1,y1,x2,y2 to out[o..o+3]. */
    fun segment(ax: Float, ay: Float, az: Float, bx: Float, by: Float, bz: Float, out: FloatArray, o: Int): Boolean {
        val da = depth(ax, ay, az); val db = depth(bx, by, bz)
        if (da < near && db < near) return false
        var x0 = ax; var y0 = ay; var z0 = az; var x1 = bx; var y1 = by; var z1 = bz
        if (da < near) {
            val t = (near - da) / (db - da)
            x0 = ax + (bx - ax) * t; y0 = ay + (by - ay) * t; z0 = az + (bz - az) * t
        } else if (db < near) {
            val t = (near - db) / (da - db)
            x1 = bx + (ax - bx) * t; y1 = by + (ay - by) * t; z1 = bz + (az - bz) * t
        }
        return project(x0, y0, z0, out, o) && project(x1, y1, z1, out, o + 2)
    }
}
