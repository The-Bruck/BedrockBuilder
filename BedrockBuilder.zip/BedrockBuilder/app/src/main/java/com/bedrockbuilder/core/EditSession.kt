package com.bedrockbuilder.core

class EditResult(val changed: Int, val boundsChanged: Boolean, val message: String?)

/** Applies edit operations to a model and keeps an undo/redo history. */
class EditSession(val model: BuildModel) {
    class Change(val key: Long, val oldId: Int, val newId: Int, val oldSec: Int, val oldBE: CompoundTag?)

    private val undoStack = ArrayDeque<List<Change>>()
    private val redoStack = ArrayDeque<List<Change>>()
    private var stroke: ArrayList<Change>? = null
    val strokeKeys = HashSet<Long>()

    val canUndo get() = undoStack.isNotEmpty()
    val canRedo get() = redoStack.isNotEmpty()

    fun beginStroke() { stroke = ArrayList(); strokeKeys.clear() }
    fun endStroke() {
        val s = stroke ?: return
        stroke = null; strokeKeys.clear()
        if (s.isNotEmpty()) push(s)
    }

    private fun push(changes: List<Change>) {
        undoStack.addLast(changes)
        redoStack.clear()
        var total = 0L
        for (c in undoStack) total += c.size
        while (undoStack.size > 100 || (total > 3_000_000 && undoStack.size > 1)) {
            total -= undoStack.removeFirst().size
        }
    }

    fun apply(
        op: Op, kind: ShapeKind, a: IntArray, b: IntArray, hollow: Boolean,
        block: BlockState, autoExpand: Boolean,
    ): EditResult {
        val buf = LongBuf()
        try {
            if (kind == ShapeKind.FLOOD) flood(a, buf) else Shapes.generate(kind, a, b, hollow, buf)
        } catch (e: IllegalArgumentException) {
            return EditResult(0, false, e.message)
        }
        var boundsChanged = false
        var clipped = false
        if (op == Op.PLACE && buf.size > 0 && kind != ShapeKind.FLOOD) {
            var x0 = Int.MAX_VALUE; var y0 = Int.MAX_VALUE; var z0 = Int.MAX_VALUE
            var x1 = Int.MIN_VALUE; var y1 = Int.MIN_VALUE; var z1 = Int.MIN_VALUE
            for (i in 0 until buf.size) {
                val k = buf.data[i]
                val x = BuildModel.kx(k); val y = BuildModel.ky(k); val z = BuildModel.kz(k)
                if (x < x0) x0 = x; if (x > x1) x1 = x
                if (y < y0) y0 = y; if (y > y1) y1 = y
                if (z < z0) z0 = z; if (z > z1) z1 = z
            }
            val outside = !model.inBounds(x0, y0, z0) || !model.inBounds(x1, y1, z1)
            if (outside) {
                if (autoExpand && model.expandToInclude(x0, y0, z0, x1, y1, z1)) boundsChanged = true
                else clipped = true
            }
        }
        val newId = if (op == Op.DESTROY) -1 else model.idFor(block)
        val changes = ArrayList<Change>()
        for (i in 0 until buf.size) {
            val key = buf.data[i]
            val x = BuildModel.kx(key); val y = BuildModel.ky(key); val z = BuildModel.kz(key)
            if (!model.inBounds(x, y, z)) continue
            val old = model.blocks[key] ?: -1
            when (op) {
                Op.PLACE -> if (old == newId) continue
                Op.DESTROY -> if (old < 0) continue
                Op.REPLACE -> if (old < 0 || old == newId) continue
                Op.PICK -> continue
            }
            changes.add(Change(key, old, newId, model.secondary[key] ?: -1, model.blockEntities[key]))
            model.setId(key, newId)
        }
        if (changes.isNotEmpty()) record(changes)
        val msg = when {
            clipped && changes.isNotEmpty() -> "Part of the shape was outside the grid and was skipped"
            clipped -> "Outside the grid — expand it or enable auto-expand"
            else -> null
        }
        return EditResult(changes.size, boundsChanged, msg)
    }

    private fun record(changes: List<Change>) {
        val s = stroke
        if (s != null) { s.addAll(changes); for (c in changes) strokeKeys.add(c.key) } else push(changes)
    }

    private fun flood(seed: IntArray, out: LongBuf) {
        require(model.inBounds(seed[0], seed[1], seed[2])) { "Tap inside the grid to flood fill" }
        val target = model.getId(seed[0], seed[1], seed[2])
        val limit = 300_000
        val seen = HashSet<Long>()
        val start = BuildModel.key(seed[0], seed[1], seed[2])
        seen.add(start); out.add(start)
        var head = 0
        val dx = intArrayOf(1, -1, 0, 0, 0, 0); val dy = intArrayOf(0, 0, 1, -1, 0, 0); val dz = intArrayOf(0, 0, 0, 0, 1, -1)
        while (head < out.size) {
            val k = out.data[head++]
            val x = BuildModel.kx(k); val y = BuildModel.ky(k); val z = BuildModel.kz(k)
            for (d in 0 until 6) {
                val nx = x + dx[d]; val ny = y + dy[d]; val nz = z + dz[d]
                if (!model.inBounds(nx, ny, nz)) continue
                val nk = BuildModel.key(nx, ny, nz)
                if (nk in seen || model.getId(nx, ny, nz) != target) continue
                seen.add(nk); out.add(nk)
                require(out.size <= limit) { "Region too large to flood fill" }
            }
        }
    }

    fun clearAll(): Int {
        val changes = ArrayList<Change>(model.blocks.size)
        for ((k, id) in model.blocks.entries.toList()) {
            changes.add(Change(k, id, -1, model.secondary[k] ?: -1, model.blockEntities[k]))
            model.setId(k, -1)
        }
        if (changes.isNotEmpty()) record(changes)
        return changes.size
    }

    fun undo(): Boolean {
        val c = undoStack.removeLastOrNull() ?: return false
        for (i in c.indices.reversed()) { val ch = c[i]; model.restore(ch.key, ch.oldId, ch.oldSec, ch.oldBE) }
        redoStack.addLast(c)
        return true
    }

    fun redo(): Boolean {
        val c = redoStack.removeLastOrNull() ?: return false
        for (ch in c) model.setId(ch.key, ch.newId)
        undoStack.addLast(c)
        return true
    }
}
