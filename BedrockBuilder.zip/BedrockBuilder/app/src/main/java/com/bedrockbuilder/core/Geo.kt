package com.bedrockbuilder.core

/** One quad of a block model: corners in cell-local coordinates (0..1), per-corner UV in texture pixels. */
class ModelFace(val corners: FloatArray, val uv: FloatArray, val normal: FloatArray, val bone: String)

class GeoModel(val texW: Int, val texH: Int, val faces: List<ModelFace>) {
    val bones: Set<String> get() = faces.map { it.bone }.toSet()
}

/** Parses Bedrock geometry (.geo.json) into quads. Supports 1.8-1.10 style and "minecraft:geometry" (1.12+). */
object GeoParser {
    private class Bone(val name: String, val parent: String?, val pivot: FloatArray, val rot: FloatArray,
                       val inflate: Float, val cubes: List<Any?>)

    private fun num(v: Any?): Float? = when (v) { is Long -> v.toFloat(); is Double -> v.toFloat(); else -> null }
    private fun vec(v: Any?, n: Int = 3): FloatArray? {
        val l = JsonLite.arr(v) ?: return null
        if (l.size < n) return null
        return FloatArray(n) { num(l[it]) ?: return null }
    }

    fun parse(root: Any?): Map<String, GeoModel> {
        val obj = JsonLite.obj(root) ?: return emptyMap()
        val out = LinkedHashMap<String, GeoModel>()
        val geos = JsonLite.arr(obj["minecraft:geometry"])
        if (geos != null) {
            for (g in geos) {
                val go = JsonLite.obj(g) ?: continue
                val desc = JsonLite.obj(go["description"]) ?: continue
                val id = desc["identifier"] as? String ?: continue
                val tw = num(desc["texture_width"])?.toInt() ?: 16
                val th = num(desc["texture_height"])?.toInt() ?: 16
                build(go["bones"], tw, th)?.let { out[id] = it }
            }
        } else {
            for ((k, v) in obj) {
                if (!k.startsWith("geometry.")) continue
                val g = JsonLite.obj(v) ?: continue
                val tw = num(g["texturewidth"])?.toInt() ?: 64
                val th = num(g["textureheight"])?.toInt() ?: 64
                build(g["bones"], tw, th)?.let { out[k.substringBefore(':')] = it }
            }
        }
        return out
    }

    private fun build(bonesJson: Any?, tw: Int, th: Int): GeoModel? {
        val list = JsonLite.arr(bonesJson) ?: return null
        val bones = ArrayList<Bone>()
        for (b in list) {
            val bo = JsonLite.obj(b) ?: continue
            bones.add(Bone(
                bo["name"] as? String ?: "bone", bo["parent"] as? String,
                vec(bo["pivot"]) ?: FloatArray(3), vec(bo["rotation"]) ?: FloatArray(3),
                num(bo["inflate"]) ?: 0f, JsonLite.arr(bo["cubes"]) ?: emptyList(),
            ))
        }
        val byName = bones.associateBy { it.name }
        val faces = ArrayList<ModelFace>()
        for (bone in bones) {
            val chain = ArrayList<Bone>()
            var cur: Bone? = bone; var guard = 0
            while (cur != null && guard++ < 32) { chain.add(cur); cur = cur.parent?.let { byName[it] } }
            for (c in bone.cubes) cube(JsonLite.obj(c) ?: continue, bone, chain, tw, th, faces)
        }
        if (faces.isEmpty() || tw <= 0 || th <= 0) return null
        return GeoModel(tw, th, faces)
    }

    // corner layout and (s,t) face coordinates match MeshBuilder's regular block faces
    private val ST = arrayOf(
        floatArrayOf(1f, 1f, 1f, 0f, 0f, 0f, 0f, 1f),   // +X east
        floatArrayOf(0f, 1f, 0f, 0f, 1f, 0f, 1f, 1f),   // -X west
        floatArrayOf(0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f),   // +Y up
        floatArrayOf(0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f),   // -Y down
        floatArrayOf(0f, 1f, 1f, 1f, 1f, 0f, 0f, 0f),   // +Z south
        floatArrayOf(1f, 1f, 0f, 1f, 0f, 0f, 1f, 0f),   // -Z north
    )
    private val FACE_NAMES = arrayOf("east", "west", "up", "down", "south", "north")
    private val NORMALS = arrayOf(
        floatArrayOf(1f, 0f, 0f), floatArrayOf(-1f, 0f, 0f), floatArrayOf(0f, 1f, 0f),
        floatArrayOf(0f, -1f, 0f), floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 0f, -1f),
    )

    private fun cube(c: Map<String, Any?>, bone: Bone, chain: List<Bone>, tw: Int, th: Int, out: MutableList<ModelFace>) {
        val o = vec(c["origin"]) ?: return
        val s = vec(c["size"]) ?: return
        val inf = num(c["inflate"]) ?: bone.inflate
        val x0 = o[0] - inf; val y0 = o[1] - inf; val z0 = o[2] - inf
        val x1 = o[0] + s[0] + inf; val y1 = o[1] + s[1] + inf; val z1 = o[2] + s[2] + inf
        val cubePivot = vec(c["pivot"]) ?: FloatArray(3)
        val cubeRot = vec(c["rotation"]) ?: FloatArray(3)
        val uvAny = c["uv"]
        val boxUv = vec(uvAny, 2)
        val faceUv = JsonLite.obj(uvAny)
        val w = s[0]; val h = s[1]; val d = s[2]

        for (f in 0 until 6) {
            val uvRect: FloatArray? = when {
                boxUv != null -> {
                    val u = boxUv[0]; val v = boxUv[1]
                    when (f) {
                        5 -> floatArrayOf(u + d, v + d, w, h)
                        0 -> floatArrayOf(u, v + d, d, h)
                        4 -> floatArrayOf(u + d + w + d, v + d, w, h)
                        1 -> floatArrayOf(u + d + w, v + d, d, h)
                        2 -> floatArrayOf(u + d, v, w, d)
                        else -> floatArrayOf(u + d + w, v, w, d)
                    }
                }
                faceUv != null -> {
                    val fo = JsonLite.obj(faceUv[FACE_NAMES[f]])
                    val uv = vec(fo?.get("uv"), 2); val sz = vec(fo?.get("uv_size"), 2)
                    if (uv != null && sz != null) floatArrayOf(uv[0], uv[1], sz[0], sz[1]) else null
                }
                else -> null
            }
            if (uvRect == null) continue
            val wf = when (f) { 0, 1 -> z1 - z0; 2, 3 -> x1 - x0; else -> x1 - x0 }
            val hf = when (f) { 0, 1 -> y1 - y0; 2, 3 -> z1 - z0; else -> y1 - y0 }
            if (wf < 1e-4f || hf < 1e-4f) continue
            val p = when (f) {
                0 -> floatArrayOf(x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1)
                1 -> floatArrayOf(x0, y0, z0, x0, y1, z0, x0, y1, z1, x0, y0, z1)
                2 -> floatArrayOf(x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1)
                3 -> floatArrayOf(x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1)
                4 -> floatArrayOf(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1)
                else -> floatArrayOf(x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0)
            }
            val n = NORMALS[f].copyOf()
            val pt = FloatArray(3)
            for (j in 0 until 4) {
                pt[0] = p[3 * j]; pt[1] = p[3 * j + 1]; pt[2] = p[3 * j + 2]
                rot(pt, cubePivot, cubeRot)
                for (b in chain) rot(pt, b.pivot, b.rot)
                p[3 * j] = (pt[0] + 8f) / 16f; p[3 * j + 1] = pt[1] / 16f; p[3 * j + 2] = (pt[2] + 8f) / 16f
            }
            val zero = FloatArray(3)
            rot(n, zero, cubeRot)
            for (b in chain) rot(n, zero, b.rot)
            val uv = FloatArray(8)
            for (j in 0 until 4) {
                uv[2 * j] = uvRect[0] + ST[f][2 * j] * uvRect[2]
                uv[2 * j + 1] = uvRect[1] + ST[f][2 * j + 1] * uvRect[3]
            }
            out.add(ModelFace(p, uv, n, bone.name))
        }
    }

    /** Rotates p about pivot by Euler angles (degrees), applying X, then Y, then Z (Bedrock convention). */
    private fun rot(p: FloatArray, pivot: FloatArray, r: FloatArray) {
        if (r[0] == 0f && r[1] == 0f && r[2] == 0f) return
        var x = p[0] - pivot[0]; var y = p[1] - pivot[1]; var z = p[2] - pivot[2]
        var a = Math.toRadians((-r[0]).toDouble()); var c = Math.cos(a).toFloat(); var s = Math.sin(a).toFloat()
        var ny = y * c - z * s; var nz = y * s + z * c; y = ny; z = nz
        a = Math.toRadians((-r[1]).toDouble()); c = Math.cos(a).toFloat(); s = Math.sin(a).toFloat()
        var nx = x * c + z * s; nz = -x * s + z * c; x = nx; z = nz
        a = Math.toRadians(r[2].toDouble()); c = Math.cos(a).toFloat(); s = Math.sin(a).toFloat()
        nx = x * c - y * s; ny = x * s + y * c; x = nx; y = ny
        p[0] = x + pivot[0]; p[1] = y + pivot[1]; p[2] = z + pivot[2]
    }
}
