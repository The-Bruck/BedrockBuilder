package com.bedrockbuilder.core

import java.io.ByteArrayInputStream
import java.util.zip.GZIPInputStream

class McStructureException(message: String) : Exception(message)

/** Reader/writer for Bedrock .mcstructure files (uncompressed little-endian NBT). */
object McStructure {

    fun read(input: ByteArray): BuildModel {
        var data = input
        try {
            if (data.size >= 2 && data[0] == 0x1f.toByte() && data[1] == 0x8b.toByte()) {
                data = GZIPInputStream(ByteArrayInputStream(data)).use { it.readBytes() }
            }
            var offset = 0
            if (data.size > 9 && data[0].toInt() != 10 && data[8].toInt() == 10) offset = 8
            return decode(Nbt.readRoot(data, offset))
        } catch (e: NbtException) {
            throw McStructureException("Not a valid .mcstructure file (${e.message})")
        } catch (e: java.io.IOException) {
            throw McStructureException("Could not decompress file")
        }
    }

    private fun decodeState(c: CompoundTag): BlockState? {
        val name = c.string("name") ?: return null
        val m = LinkedHashMap<String, Any>()
        c.compound("states")?.map?.forEach { (k, v) ->
            when (v) {
                is ByteTag -> m[k] = v.value.toInt() != 0
                is IntTag -> m[k] = v.value
                is ShortTag -> m[k] = v.value.toInt()
                is LongTag -> m[k] = v.value.toInt()
                is StringTag -> m[k] = v.value
                else -> {}
            }
        }
        return BlockState(name, m, c.int("version") ?: BLOCK_VERSION)
    }

    private fun decode(root: CompoundTag): BuildModel {
        val structure = root.compound("structure") ?: throw McStructureException("Missing 'structure' data")
        val size = root.list("size").intsOrNull()
        if (size == null || size.size < 3) throw McStructureException("Missing structure size")
        val sx = size[0]; val sy = size[1]; val sz = size[2]
        if (sx < 1 || sy < 1 || sz < 1 || sx > BuildModel.MAX_AXIS || sy > BuildModel.MAX_AXIS ||
            sz > BuildModel.MAX_AXIS || sx.toLong() * sy * sz > BuildModel.MAX_VOLUME
        ) throw McStructureException("Structure is too large ($sx x $sy x $sz). Limit is ${BuildModel.MAX_AXIS} per axis")

        val layers = structure.list("block_indices").listItems()
        val primary = layers.getOrNull(0).intsOrNull() ?: throw McStructureException("Missing block indices")
        val secondaryIdx = layers.getOrNull(1).intsOrNull()

        val paletteRoot = structure.compound("palette")
        val pal = paletteRoot?.compound("default")
            ?: paletteRoot?.map?.values?.filterIsInstance<CompoundTag>()?.firstOrNull()
            ?: throw McStructureException("Missing block palette")
        val states = pal.list("block_palette").listItems().map { (it as? CompoundTag)?.let(::decodeState) }

        val model = BuildModel.create(sx, sy, sz)
        val mapped = IntArray(states.size) { -1 }
        fun modelId(i: Int): Int {
            if (i < 0 || i >= states.size) return -1
            val s = states[i] ?: return -1
            if (mapped[i] == -1) mapped[i] = model.idFor(s)
            return mapped[i]
        }
        fun isAir(i: Int) = i >= 0 && i < states.size && states[i]?.name == "minecraft:air"

        val total = sx * sy * sz
        val syz = sy * sz
        for (i in 0 until minOf(total, primary.size)) {
            val p = primary[i]
            val s2 = if (secondaryIdx != null && i < secondaryIdx.size) secondaryIdx[i] else -1
            val x = i / syz; val y = (i / sz) % sy; val z = i % sz
            val key = BuildModel.key(x, y, z)
            if (p >= 0 && isAir(p)) model.emptyAsAir = true
            val pOk = p >= 0 && !isAir(p) && modelId(p) >= 0
            val sOk = s2 >= 0 && !isAir(s2) && modelId(s2) >= 0
            when {
                pOk -> { model.blocks[key] = modelId(p); if (sOk) model.secondary[key] = modelId(s2) }
                sOk -> model.blocks[key] = modelId(s2) // e.g. standalone water
            }
        }

        pal.compound("block_position_data")?.map?.forEach { (k, v) ->
            val idx = k.toIntOrNull()
            if (idx != null && idx in 0 until total && v is CompoundTag) {
                val key = BuildModel.key(idx / syz, (idx / sz) % sy, idx % sz)
                if (model.blocks.containsKey(key)) model.blockEntities[key] = v
            }
        }
        model.entities = structure.list("entities").listItems()
        root.list("structure_world_origin").intsOrNull()?.let { if (it.size >= 3) model.origin = it.copyOf(3) }
        return model
    }

    /** @param crop write only the bounding box of the blocks (used with the dynamic grid). */
    fun write(model: BuildModel, emptyAsAir: Boolean = model.emptyAsAir, crop: Boolean = false): ByteArray {
        val used = if (crop) model.usedBounds() else null
        val minX = used?.get(0) ?: model.minX; val minY = used?.get(1) ?: model.minY; val minZ = used?.get(2) ?: model.minZ
        val sx = if (used != null) used[3] - used[0] + 1 else model.sizeX
        val sy = if (used != null) used[4] - used[1] + 1 else model.sizeY
        val sz = if (used != null) used[5] - used[2] + 1 else model.sizeZ
        val total = sx * sy * sz
        val syz = sy * sz

        val at = IntArray(total) { -1 }
        for ((key, id) in model.blocks) {
            val x = BuildModel.kx(key) - minX
            val y = BuildModel.ky(key) - minY
            val z = BuildModel.kz(key) - minZ
            if (x < 0 || y < 0 || z < 0 || x >= sx || y >= sy || z >= sz) continue
            at[x * syz + y * sz + z] = id
        }

        val pal = ArrayList<BlockState>()
        val palMap = HashMap<BlockState, Int>()
        fun pid(s: BlockState) = palMap.getOrPut(s) { pal.add(s); pal.size - 1 }
        val air = if (emptyAsAir) pid(BlockState.AIR) else -1

        val layer0 = IntArray(total) { air }
        val layer1 = IntArray(total) { -1 }
        for (i in 0 until total) {
            val id = at[i]
            if (id < 0) continue
            layer0[i] = pid(model.palette[id])
        }
        for ((key, sec) in model.secondary) {
            val x = BuildModel.kx(key) - minX
            val y = BuildModel.ky(key) - minY
            val z = BuildModel.kz(key) - minZ
            if (x < 0 || y < 0 || z < 0 || x >= sx || y >= sy || z >= sz) continue
            val i = x * syz + y * sz + z
            if (at[i] >= 0) layer1[i] = pid(model.palette[sec])
        }

        val paletteList = ArrayList<Tag>(pal.size)
        for (s in pal) {
            val st = CompoundTag()
            for (k in s.states.keys.sorted()) {
                st[k] = when (val v = s.states.getValue(k)) {
                    is Boolean -> ByteTag(if (v) 1 else 0)
                    is Int -> IntTag(v)
                    is String -> StringTag(v)
                    else -> StringTag(v.toString())
                }
            }
            val e = CompoundTag()
            e["name"] = StringTag(s.name)
            e["states"] = st
            e["version"] = IntTag(s.version)
            paletteList.add(e)
        }

        val positionData = CompoundTag()
        for ((key, be) in model.blockEntities) {
            val x = BuildModel.kx(key) - minX
            val y = BuildModel.ky(key) - minY
            val z = BuildModel.kz(key) - minZ
            if (x < 0 || y < 0 || z < 0 || x >= sx || y >= sy || z >= sz) continue
            val i = x * syz + y * sz + z
            if (at[i] >= 0) positionData[i.toString()] = be
        }

        val def = CompoundTag()
        def["block_palette"] = ListTag(10, paletteList)
        def["block_position_data"] = positionData
        val palette = CompoundTag()
        palette["default"] = def

        val structure = CompoundTag()
        structure["block_indices"] = ListTag(9, listOf(IntListTag(layer0), IntListTag(layer1)))
        structure["entities"] = ListTag(10, model.entities)
        structure["palette"] = palette

        val root = CompoundTag()
        root["format_version"] = IntTag(1)
        root["size"] = IntListTag(intArrayOf(sx, sy, sz))
        root["structure"] = structure
        root["structure_world_origin"] = IntListTag(model.origin)
        return Nbt.writeRoot(root)
    }
}
