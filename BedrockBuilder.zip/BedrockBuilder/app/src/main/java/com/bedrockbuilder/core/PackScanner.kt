package com.bedrockbuilder.core

import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

class PackException(message: String) : Exception(message)

class PackTexture(val path: String, val ext: String, val bytes: ByteArray)

/** A block defined by an imported pack: identifier, six face texture paths (e,w,u,d,s,n) and its states. */
class PackBlock(
    val id: String, val facePaths: Array<String?>, val states: Map<String, List<Any>>,
    /** Custom 3D model (from a resource pack's .geo.json) and the texture path used for each of its bones ("*" = default). */
    val model: GeoModel? = null, val boneTextures: Map<String, String> = emptyMap(),
)

class PackSet(val packNames: List<String>, val blocks: List<PackBlock>, val textures: LinkedHashMap<String, PackTexture>) {
    /** Lines in block_textures.txt format, given the atlas cell index of each texture path. */
    fun mapText(cellOf: (String) -> Int?): String {
        val sb = StringBuilder()
        for (b in blocks) {
            val cells = b.facePaths.map { p -> p?.let { cellOf(it) } ?: -1 }
            if (cells.all { it < 0 }) continue
            sb.append(b.id).append(' ').append(cells.joinToString(" ") { if (it < 0) "-1" else "$it:0" }).append('\n')
        }
        return sb.toString()
    }
}

/** Reads .mcpack / .mcaddon / .zip archives (also nested) and extracts custom blocks and their textures. */
object PackScanner {
    private const val MAX_TOTAL = 300L * 1024 * 1024
    private const val MAX_ENTRIES = 30000

    fun readZip(bytes: ByteArray, prefix: String = "", out: LinkedHashMap<String, ByteArray> = LinkedHashMap(),
                depth: Int = 0, budget: LongArray = longArrayOf(0)): LinkedHashMap<String, ByteArray> {
        try {
            ZipInputStream(ByteArrayInputStream(bytes)).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (e.isDirectory) continue
                    if (out.size > MAX_ENTRIES) throw PackException("Archive has too many files")
                    val data = zin.readBytes()
                    budget[0] += data.size
                    if (budget[0] > MAX_TOTAL) throw PackException("Archive is too large")
                    val name = (prefix + e.name.replace('\\', '/')).trimStart('/')
                    if (name.contains("../")) continue
                    val lower = name.lowercase()
                    if (depth < 2 && (lower.endsWith(".mcpack") || lower.endsWith(".zip") || lower.endsWith(".mcaddon"))) {
                        readZip(data, "$name!/", out, depth + 1, budget)
                    } else out[name] = data
                }
            }
        } catch (e: java.io.IOException) {
            throw PackException("Not a valid pack archive")
        }
        return out
    }

    private class Pack(val root: String, val name: String, val resource: Boolean, val behavior: Boolean)

    fun scanAll(archives: List<ByteArray>): PackSet {
        val files = LinkedHashMap<String, ByteArray>()
        val budget = longArrayOf(0)
        for ((i, a) in archives.withIndex()) readZip(a, "a$i/", files, 0, budget)

        // find pack roots
        val packs = ArrayList<Pack>()
        for (path in files.keys.filter { it.endsWith("manifest.json") && (it == "manifest.json" || it.endsWith("/manifest.json")) }) {
            val root = path.removeSuffix("manifest.json")
            val m = try { JsonLite.obj(JsonLite.parse(String(files.getValue(path), Charsets.UTF_8))) } catch (e: Exception) { null } ?: continue
            val header = JsonLite.obj(m["header"])
            val name = (header?.get("name") as? String) ?: root.trimEnd('/').substringAfterLast('/')
            val modules = JsonLite.arr(m["modules"]) ?: emptyList()
            val types = modules.mapNotNull { (JsonLite.obj(it)?.get("type") as? String)?.lowercase() }
            packs.add(Pack(root, name, "resources" in types, "data" in types))
        }
        if (packs.isEmpty()) throw PackException("No resource or behavior pack found (manifest.json missing)")

        // terrain texture keys (resource packs)
        val keyPaths = HashMap<String, List<String>>()
        val resourceBlocks = LinkedHashMap<String, Map<String, String>>()  // id -> dir->key
        for (p in packs.filter { it.resource }) {
            files[p.root + "textures/terrain_texture.json"]?.let { b ->
                val td = JsonLite.obj(JsonLite.obj(parse(b))?.get("texture_data"))
                td?.forEach { (k, v) -> keyPaths[k] = texturePaths(JsonLite.obj(v)?.get("textures")) }
            }
            files[p.root + "blocks.json"]?.let { b ->
                JsonLite.obj(parse(b))?.forEach { (id, v) ->
                    val tex = JsonLite.obj(v)?.get("textures")
                    if (id != "format_version" && tex != null) faceKeysFromBlocksJson(tex)?.let { resourceBlocks[id] = it }
                }
            }
        }

        // block models from resource packs (models/**/*.json)
        val geos = LinkedHashMap<String, GeoModel>()
        for (p in packs.filter { it.resource }) {
            for ((path, b) in files) {
                if (!path.startsWith(p.root + "models/") || !path.endsWith(".json")) continue
                try { geos.putAll(GeoParser.parse(parse(b))) } catch (e: Exception) { /* skip bad model */ }
            }
        }

        // behaviour pack blocks
        class Def(val id: String, val keys: Map<String, String>?, val states: Map<String, List<Any>>, val geometry: String?)
        val defs = LinkedHashMap<String, Def>()
        for (p in packs.filter { it.behavior }) {
            for ((path, b) in files) {
                if (!path.startsWith(p.root + "blocks/") || !path.endsWith(".json")) continue
                val root = JsonLite.obj(parse(b)) ?: continue
                val block = JsonLite.obj(root["minecraft:block"]) ?: continue
                val desc = JsonLite.obj(block["description"]) ?: continue
                val id = desc["identifier"] as? String ?: continue
                val comps = JsonLite.obj(block["components"])
                val keys = comps?.get("minecraft:material_instances")?.let { materialKeys(it) }
                val geo = comps?.get("minecraft:geometry")?.let { g ->
                    (g as? String) ?: (JsonLite.obj(g)?.get("identifier") as? String)
                }
                defs[id] = Def(id, keys, states(desc), geo)
            }
        }

        // resolve textures
        val used = LinkedHashMap<String, PackTexture>()
        fun fileFor(path: String): PackTexture? {
            used[path]?.let { return it }
            for (p in packs.filter { it.resource }.reversed()) for (ext in listOf("png", "tga")) {
                val data = files["${p.root}$path.$ext"] ?: continue
                return PackTexture(path, ext, data).also { used[path] = it }
            }
            return null
        }
        fun pathFor(key: String?): String? {
            if (key == null) return null
            val cands = (keyPaths[key] ?: emptyList()) + listOf(key.removeSuffix(".png").removeSuffix(".tga"), "textures/blocks/$key", "textures/$key")
            val order = cands.sortedBy { if (it.endsWith("_opaque")) 0 else 1 }
            return order.firstOrNull { fileFor(it) != null }
        }
        fun faces(keys: Map<String, String>?): Array<String?> {
            val out = arrayOfNulls<String>(6)
            if (keys == null) return out
            val dirs = listOf("east", "west", "up", "down", "south", "north")
            for ((i, d) in dirs.withIndex()) {
                val k = keys[d] ?: (if (d in listOf("east", "west", "south", "north")) keys["side"] else null) ?: keys["*"]
                out[i] = pathFor(k)
            }
            return out
        }

        val blocks = ArrayList<PackBlock>()
        val seen = HashSet<String>()
        for (d in defs.values) {
            val keys = d.keys ?: resourceBlocks[d.id]
            val model = d.geometry?.let { geos[it] ?: geos[it.removePrefix("geometry.")] ?: geos["geometry.$it"] }
            val boneTex = LinkedHashMap<String, String>()
            if (model != null && keys != null) {
                val def = pathFor(keys["*"] ?: keys.values.firstOrNull())
                if (def != null) boneTex["*"] = def
                for (bone in model.bones) pathFor(keys[bone])?.let { boneTex[bone] = it }
            }
            blocks.add(PackBlock(d.id, faces(keys), d.states, model, boneTex)); seen.add(d.id)
        }
        for ((id, keys) in resourceBlocks) if (id !in seen && ':' in id) blocks.add(PackBlock(id, faces(keys), emptyMap()))
        // vanilla-id overrides from blocks.json (no namespace) are applied when their keys resolve inside the pack
        for ((id, keys) in resourceBlocks) if (':' !in id) {
            val f = faces(keys)
            if (f.any { it != null }) blocks.add(PackBlock(id, f, emptyMap()))
        }
        return PackSet(packs.map { it.name }.distinct(), blocks, used)
    }

    private fun parse(b: ByteArray): Any? = try { JsonLite.parse(String(b, Charsets.UTF_8)) } catch (e: Exception) { null }

    private fun texturePaths(t: Any?): List<String> = when (t) {
        is String -> listOf(t)
        is List<*> -> t.flatMap { texturePaths(it) }
        is Map<*, *> -> {
            val m = JsonLite.obj(t)!!
            (m["path"] as? String)?.let { listOf(it) } ?: texturePaths(m["variations"])
        }
        else -> emptyList()
    }

    /** blocks.json "textures": string, or {up,down,side,north,...} of terrain keys. */
    private fun faceKeysFromBlocksJson(t: Any?): Map<String, String>? = when (t) {
        is String -> mapOf("*" to t)
        is Map<*, *> -> JsonLite.obj(t)!!.mapNotNull { (k, v) -> (v as? String)?.let { k to it } }.toMap()
        else -> null
    }

    /** minecraft:material_instances -> face name ("*", "up", "side", ...) to terrain key. */
    private fun materialKeys(v: Any?): Map<String, String>? {
        val root = JsonLite.obj(v) ?: return null
        val mappings = JsonLite.obj(root["mappings"]); val materials = JsonLite.obj(root["materials"])
        if (mappings != null && materials != null) {
            val r = materials.mapNotNull { (k, x) -> (x as? String)?.let { k to ((mappings[it] as? String) ?: it) } }.toMap()
            return if (r.isEmpty()) null else r
        }
        val m = LinkedHashMap<String, String>()
        for ((k, x) in root) {
            val tex = when (x) { is String -> x; is Map<*, *> -> JsonLite.obj(x)!!["texture"] as? String; else -> null }
            if (tex != null) m[k] = tex
        }
        return if (m.isEmpty()) null else m
    }

    private fun states(desc: Map<String, Any?>): Map<String, List<Any>> {
        val out = LinkedHashMap<String, List<Any>>()
        for (field in listOf("states", "properties")) {
            JsonLite.obj(desc[field])?.forEach { (k, v) ->
                val vals: List<Any>? = when (v) {
                    is List<*> -> v.mapNotNull { x -> when (x) { is Long -> x.toInt(); is Boolean -> x; is String -> x; else -> null } }
                    is Map<*, *> -> {
                        val vv = JsonLite.obj(v)!!["values"]
                        val mm = JsonLite.obj(vv)
                        if (mm != null && mm["min"] is Long && mm["max"] is Long) {
                            val lo = (mm["min"] as Long).toInt(); val hi = (mm["max"] as Long).toInt()
                            (lo..minOf(hi, lo + 15)).toList()
                        } else JsonLite.arr(vv)?.mapNotNull { x -> when (x) { is Long -> x.toInt(); is Boolean -> x; is String -> x; else -> null } }
                    }
                    else -> null
                }
                if (!vals.isNullOrEmpty()) out[k] = vals
            }
        }
        return out
    }
}
