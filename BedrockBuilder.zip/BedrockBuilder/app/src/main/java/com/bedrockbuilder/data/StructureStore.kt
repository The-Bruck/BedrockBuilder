package com.bedrockbuilder.data

import android.content.Context
import com.bedrockbuilder.core.BuildModel
import com.bedrockbuilder.core.McStructure
import java.io.File

/** Saved structures live in app-private storage as real .mcstructure files. */
class StructureStore(private val context: Context) {
    data class Entry(
        val name: String, val sx: Int, val sy: Int, val sz: Int,
        val blocks: Int, val modified: Long, val error: String? = null,
    )

    private val dir = File(context.filesDir, "structures").apply { mkdirs() }

    companion object {
        private val cache = HashMap<String, Pair<Long, Entry>>()
    }

    fun file(name: String) = File(dir, "$name.mcstructure")
    fun exists(name: String) = file(name).exists()

    fun sanitize(raw: String): String {
        val s = raw.trim().replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim('.', ' ').take(60)
        return s.ifBlank { "Structure" }
    }

    fun uniqueName(raw: String): String {
        val base = sanitize(raw)
        if (!exists(base)) return base
        var i = 2
        while (exists("$base $i")) i++
        return "$base $i"
    }

    @Synchronized
    fun list(): List<Entry> {
        val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".mcstructure") } ?: return emptyList()
        return files.map { f ->
            val name = f.name.removeSuffix(".mcstructure")
            val cached = cache[name]
            if (cached != null && cached.first == f.lastModified()) cached.second
            else {
                val e = try {
                    val m = McStructure.read(f.readBytes())
                    Entry(name, m.sizeX, m.sizeY, m.sizeZ, m.blockCount, f.lastModified())
                } catch (ex: Exception) {
                    Entry(name, 0, 0, 0, 0, f.lastModified(), ex.message ?: "Unreadable")
                }
                cache[name] = f.lastModified() to e
                e
            }
        }.sortedByDescending { it.modified }
    }

    fun load(name: String): BuildModel = McStructure.read(file(name).readBytes())

    fun write(name: String, bytes: ByteArray) {
        val target = file(name)
        val tmp = File(dir, "$name.tmp")
        tmp.writeBytes(bytes)
        if (!tmp.renameTo(target)) { target.delete(); if (!tmp.renameTo(target)) throw java.io.IOException("Could not save") }
    }

    fun delete(name: String) { file(name).delete() }

    fun rename(old: String, new: String): String {
        val target = uniqueName(new)
        if (!file(old).renameTo(file(target))) throw java.io.IOException("Could not rename")
        return target
    }

    fun duplicate(name: String): String {
        val target = uniqueName("$name copy")
        file(name).copyTo(file(target))
        return target
    }

    /** Copies a structure to the cache dir so it can be shared through FileProvider. */
    fun shareFile(name: String, bytes: ByteArray? = null): File {
        val d = File(context.cacheDir, "share").apply { mkdirs() }
        val f = File(d, "${sanitize(name)}.mcstructure")
        f.writeBytes(bytes ?: file(name).readBytes())
        return f
    }
}
