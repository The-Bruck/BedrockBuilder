package com.bedrockbuilder.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bedrockbuilder.core.*
import com.bedrockbuilder.data.Prefs
import com.bedrockbuilder.data.StructureStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    private val store = StructureStore(app)
    private val prefs = Prefs(app)

    var name by mutableStateOf("")
        private set
    var loaded by mutableStateOf(false)
        private set
    var loadError by mutableStateOf<String?>(null)
        private set
    var model = BuildModel()
        private set
    private var session = EditSession(model)

    /** Bumped on every model change so the UI knows to rebuild the mesh. */
    var revision by mutableIntStateOf(0)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    var camera by mutableStateOf(Camera())
    var op by mutableStateOf(Op.PLACE)
        private set
    var shape by mutableStateOf(ShapeKind.SINGLE)
        private set
    var hollow by mutableStateOf(false)
    var current by mutableStateOf(BlockState("minecraft:stone"))
        private set
    var layerY by mutableIntStateOf(0)
        private set
    var hideAbove by mutableStateOf(false)
    var locked by mutableStateOf(false)
    var anchor by mutableStateOf<IntArray?>(null)
        private set
    var message by mutableStateOf<String?>(null)

    var autoExpand by mutableStateOf(prefs.autoExpand)
        private set
    var showOutlines by mutableStateOf(prefs.showOutlines)
        private set
    var emptyAsAir by mutableStateOf(false)
        private set
    var recents by mutableStateOf(prefs.recents())
        private set
    var customs by mutableStateOf(prefs.customs())
        private set

    private var saveJob: Job? = null
    private var dirty = false

    init { prefs.recents().firstOrNull()?.let { current = it } }

    // ---- loading / saving -------------------------------------------------------------------

    fun open(n: String) {
        if (loaded && name == n) return
        saveNow()
        loaded = false; loadError = null; name = n
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { store.load(n) } }
            r.onSuccess { install(it) }
            r.onFailure { loadError = it.message ?: "Could not open structure" }
        }
    }

    private fun install(m: BuildModel) {
        model = m; session = EditSession(m)
        camera = Camera.fit(m)
        layerY = m.minY
        anchor = null; hideAbove = false
        emptyAsAir = m.emptyAsAir
        dirty = false
        refreshHistory()
        revision++
        loaded = true
    }

    private fun refreshHistory() { canUndo = session.canUndo; canRedo = session.canRedo }

    private fun changed() {
        layerY = layerY.coerceIn(model.minY, model.maxY)
        refreshHistory()
        revision++
        dirty = true
        saveJob?.cancel()
        saveJob = viewModelScope.launch { delay(1500); saveNow() }
    }

    /** Serialises on the calling (main) thread, then writes the file on IO. */
    fun saveNow() {
        if (!loaded || !dirty) return
        saveJob?.cancel()
        dirty = false
        val target = name
        val bytes = try { McStructure.write(model, emptyAsAir) } catch (e: Exception) { message = "Save failed: ${e.message}"; return }
        viewModelScope.launch(Dispatchers.IO) {
            try { store.write(target, bytes) } catch (e: Exception) { message = "Save failed: ${e.message}" }
        }
    }

    fun manualSave() {
        dirty = true; saveNow(); message = "Saved"
    }

    fun exportTo(uri: Uri) {
        if (!loaded) return
        val resolver = getApplication<Application>().contentResolver
        val bytes = McStructure.write(model, emptyAsAir)
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching { resolver.openOutputStream(uri, "wt")?.use { it.write(bytes) } ?: error("Could not write file") }
            }
            message = if (r.isSuccess) "Exported ${model.sizeX}×${model.sizeY}×${model.sizeZ} structure" else "Export failed: ${r.exceptionOrNull()?.message}"
        }
    }

    fun shareFile(onReady: (File) -> Unit) {
        if (!loaded) return
        val bytes = McStructure.write(model, emptyAsAir)
        val n = name
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { store.shareFile(n, bytes) } }
            r.onSuccess(onReady).onFailure { message = "Share failed: ${it.message}" }
        }
    }

    // ---- tool state ---------------------------------------------------------------------------

    fun selectOp(o: Op) { op = o; anchor = null }
    fun selectShape(s: ShapeKind) { shape = s; anchor = null }

    fun selectBlock(b: BlockState) {
        current = b
        recents = prefs.pushRecent(b)
    }

    fun addCustomBlock(b: BlockState) {
        customs = prefs.addCustom(b)
        selectBlock(b)
    }

    fun removeCustomBlock(b: BlockState) { customs = prefs.removeCustom(b) }

    fun setAutoExpand(v: Boolean) { autoExpand = v; prefs.autoExpand = v }
    fun setShowOutlines(v: Boolean) { showOutlines = v; prefs.showOutlines = v }
    fun setEmptyAsAir(v: Boolean) { emptyAsAir = v; model.emptyAsAir = v; dirty = true; saveNow() }

    fun setLayer(y: Int) { layerY = y.coerceIn(model.minY, model.maxY); if (hideAbove) revision++ }

    // ---- camera -------------------------------------------------------------------------------

    fun zoomBy(f: Float) { camera = camera.zoom(f) }
    fun fitView() { camera = Camera.fit(model, camera.yaw, camera.pitch) }
    fun setView(yaw: Float, pitch: Float) { camera = Camera.fit(model, yaw, pitch) }

    fun onTransform(zoom: Float, pan: androidx.compose.ui.geometry.Offset, w: Float, h: Float) {
        var c = camera
        if (zoom != 1f) c = c.zoom(zoom)
        if (!locked && (pan.x != 0f || pan.y != 0f)) c = c.pan(pan.x, pan.y, w, h)
        camera = c
    }

    // ---- gestures -----------------------------------------------------------------------------

    private var painting = false
    private var lastPaintKey = Long.MIN_VALUE

    private fun paintMode() = locked && shape == ShapeKind.SINGLE && op != Op.PICK

    fun onGestureStart() {
        painting = false; lastPaintKey = Long.MIN_VALUE
    }

    fun onGestureEnd() {
        if (painting) { session.endStroke(); painting = false; changed() }
    }

    fun onDrag(px: Float, py: Float, dx: Float, dy: Float, w: Float, h: Float) {
        if (!loaded) return
        if (paintMode()) {
            if (!painting) { session.beginStroke(); painting = true }
            val pick = pickAt(px, py, w, h) ?: return
            val cell = targetCell(pick, op) ?: return
            if (pick.hit && op == Op.PLACE && BuildModel.key(pick.bx, pick.by, pick.bz) in session.strokeKeys) return
            val k = BuildModel.key(cell[0], cell[1], cell[2])
            if (k == lastPaintKey) return
            lastPaintKey = k
            runOp(cell, cell, silent = true)
            return
        }
        if (!locked) camera = camera.orbit(-dx * 0.4f, dy * 0.4f)
    }

    fun onTap(px: Float, py: Float, w: Float, h: Float) {
        if (!loaded) return
        val pick = pickAt(px, py, w, h) ?: return
        if (op == Op.PICK) {
            if (pick.hit) {
                model.get(pick.bx, pick.by, pick.bz)?.let { selectBlock(it); message = "Picked ${it.shortName}" }
                op = Op.PLACE
            } else message = "Tap a block to pick it"
            return
        }
        val cell = targetCell(pick, op) ?: return
        if (!shape.twoPoints) { runOp(cell, cell); return }
        val a = anchor
        if (a == null) { anchor = cell; message = "First point set — tap the second point" }
        else { anchor = null; runOp(a, cell) }
    }

    private fun pickAt(px: Float, py: Float, w: Float, h: Float): PickResult? =
        Picker.pick(model, camera, w, h, px, py, layerY, hideAbove, if (autoExpand) 24 else 0)

    private fun targetCell(p: PickResult, op: Op): IntArray? = when {
        p.hit -> if (op == Op.PLACE) intArrayOf(p.bx + p.nx, p.by + p.ny, p.bz + p.nz) else intArrayOf(p.bx, p.by, p.bz)
        p.hasPlane -> intArrayOf(p.px, p.py, p.pz)
        else -> null
    }

    private fun runOp(a: IntArray, b: IntArray, silent: Boolean = false) {
        val r = session.apply(op, shape, a, b, hollow && shape.hollowable, current, autoExpand)
        if (r.message != null && !silent) message = r.message
        if (r.changed > 0 || r.boundsChanged) { if (!painting) changed() else { refreshHistory(); revision++; dirty = true } }
    }

    // ---- edit commands --------------------------------------------------------------------------

    fun undo() { if (session.undo()) changed() }
    fun redo() { if (session.redo()) changed() }
    fun clearAll() { val n = session.clearAll(); if (n > 0) changed(); message = "Removed $n blocks" }
    fun cancelAnchor() { anchor = null }

    fun resizeSide(axis: Int, high: Boolean, delta: Int) {
        val err = model.resizeSide(axis, high, delta)
        if (err != null) message = err else changed()
    }

    fun fitGridToBlocks() { model.fitToBlocks(); changed(); fitView() }

    fun setGridSize(sx: Int, sy: Int, sz: Int) {
        val x1 = model.minX + sx - 1; val y1 = model.minY + sy - 1; val z1 = model.minZ + sz - 1
        val used = model.usedBounds()
        if (!model.boundsValid(model.minX, model.minY, model.minZ, x1, y1, z1)) {
            message = "Limit: ${BuildModel.MAX_AXIS} per axis"; return
        }
        if (used != null && (x1 < used[3] || y1 < used[4] || z1 < used[5])) { message = "Blocks would be cut off"; return }
        model.maxX = x1; model.maxY = y1; model.maxZ = z1
        changed()
    }
}
