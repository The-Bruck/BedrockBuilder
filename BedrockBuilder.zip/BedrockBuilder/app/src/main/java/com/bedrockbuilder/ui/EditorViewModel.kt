package com.bedrockbuilder.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bedrockbuilder.core.*
import com.bedrockbuilder.data.HudConfig
import com.bedrockbuilder.data.HudElement
import com.bedrockbuilder.data.PaletteEntry
import com.bedrockbuilder.data.Prefs
import com.bedrockbuilder.data.StructureStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    private val store = StructureStore(app)
    private val prefs = Prefs(app)

    var name by mutableStateOf("")
        private set
    var loaded by mutableStateOf(false)
        private set
    var loadError by mutableStateOf<String?>(null)
        private set
    var model = BuildModel()
        private set
    private var session = EditSession(model)

    /** Bumped on every model change so the UI knows to rebuild the mesh. */
    var revision by mutableIntStateOf(0)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    var camera by mutableStateOf(Camera())
    var op by mutableStateOf(Op.PLACE)
        private set
    var shape by mutableStateOf(ShapeKind.SINGLE)
        private set
    var hollow by mutableStateOf(false)
    /** Whether the on-screen controls are visible (toggle with Hide UI / Show UI). */
    var hud by mutableStateOf(true)
    var dockTab by mutableIntStateOf(0)
    var dockOpen by mutableStateOf(true)
    var rotateCcw by mutableStateOf(false)
    var current by mutableStateOf(BlockState("minecraft:stone"))
        private set
    var layerY by mutableIntStateOf(0)
        private set
    var hideAbove by mutableStateOf(false)
    var locked by mutableStateOf(false)
    var anchor by mutableStateOf<IntArray?>(null)
        private set
    var message by mutableStateOf<String?>(null)

    // settings
    // HUD layout customisation
    var hudConfig by mutableStateOf(prefs.hudConfig())
        private set
    var hudEdit by mutableStateOf(false)
    var hudSelected by mutableStateOf(HudElement.HOTBAR)
    var showOutlines by mutableStateOf(prefs.showOutlines)
        private set
    var background by mutableIntStateOf(prefs.background)
        private set
    var emptyAsAir by mutableStateOf(false)
        private set
    var recents by mutableStateOf(prefs.recents())
        private set
    var customs by mutableStateOf(prefs.customs())
        private set

    // hotbar + palette
    var hotbar by mutableStateOf(prefs.hotbar())
        private set
    var slot by mutableIntStateOf(prefs.hotbarSlot)
        private set
    var paletteMode by mutableStateOf(false)
    var palette by mutableStateOf(prefs.palette())
        private set

    // textures (vanilla + this structure's packs)
    var textures by mutableStateOf<TextureSet?>(null)
        private set
    var packFiles by mutableStateOf<List<File>>(emptyList())
        private set

    private var saveJob: Job? = null
    private var dirty = false

    init {
        hotbar.getOrNull(slot)?.let { current = it }
        viewModelScope.launch {
            textures = withContext(Dispatchers.IO) { TextureSet.build(getApplication(), emptyList()) }
        }
    }

    // ---- loading / saving -------------------------------------------------------------------

    fun open(n: String) {
        if (loaded && name == n) return
        close()
        loadError = null; name = n
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val m = store.load(n)
                    val files = store.packFiles(n)
                    val ts = TextureSet.build(getApplication(), files.map { it.readBytes() })
                    Triple(m, files, ts)
                }
            }
            if (name != n) return@launch   // user left before it finished
            r.onSuccess { (m, files, ts) -> packFiles = files; textures = ts; install(m) }
            r.onFailure { loadError = it.message ?: "Could not open structure" }
        }
    }

    /** Saves and forgets the open structure so the next open always reads fresh data from disk. */
    fun close() {
        if (loaded) writeNow()
        saveJob?.cancel()
        loaded = false; name = ""; dirty = false; loadError = null
        anchor = null
        packFiles = emptyList()
    }

    private fun install(m: BuildModel) {
        model = m; session = EditSession(m)
        camera = Camera.fit(m)
        layerY = m.minY
        anchor = null; hideAbove = false
        emptyAsAir = m.emptyAsAir
        dirty = false
        refreshHistory()
        revision++
        loaded = true
    }

    private fun refreshHistory() { canUndo = session.canUndo; canRedo = session.canRedo }

    private fun changed() {
        layerY = layerY.coerceIn(model.minY, model.maxY)
        refreshHistory()
        revision++
        dirty = true
        saveJob?.cancel()
        val n = name
        saveJob = viewModelScope.launch { delay(1500); if (name == n) saveNow() }
    }

    private fun bytes(): ByteArray = McStructure.write(model, emptyAsAir)

    /** Writes synchronously (small files). Used when leaving the editor so the next open sees the saved data. */
    private fun writeNow() {
        if (!loaded || !dirty) return
        saveJob?.cancel()
        try { store.write(name, bytes()); dirty = false } catch (e: Exception) { message = "Save failed: ${e.message}" }
    }

    fun saveNow() = writeNow()

    fun manualSave() { dirty = true; writeNow(); message = "Saved" }

    fun exportTo(uri: Uri) {
        if (!loaded) return
        val resolver = getApplication<Application>().contentResolver
        val data = bytes()
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching { resolver.openOutputStream(uri, "wt")?.use { it.write(data) } ?: error("Could not write file") }
            }
            message = if (r.isSuccess) "Exported structure" else "Export failed: ${r.exceptionOrNull()?.message}"
        }
    }

    fun shareFile(onReady: (File) -> Unit) {
        if (!loaded) return
        val data = bytes()
        val n = name
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { store.shareFile(n, data) } }
            r.onSuccess(onReady).onFailure { message = "Share failed: ${it.message}" }
        }
    }

    // ---- packs (.mcpack / .mcaddon) ------------------------------------------------------------------

    fun importPack(uri: Uri) {
        if (!loaded) return
        val resolver = getApplication<Application>().contentResolver
        val n = name
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val data = resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Could not open file")
                    if (data.size > 200 * 1024 * 1024) error("File is too large")
                    var display = "pack.mcpack"
                    resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getString(0)?.let { display = it }
                    }
                    PackScanner.scanAll(listOf(data))   // validates; throws PackException
                    store.addPack(n, display, data)
                    val files = store.packFiles(n)
                    files to TextureSet.build(getApplication(), files.map { it.readBytes() })
                }
            }
            if (name != n) return@launch
            r.onSuccess { (files, ts) ->
                packFiles = files; textures = ts; revision++
                message = "Pack imported (${ts.packBlocks.size} custom blocks)"
            }
            r.onFailure { message = "Import failed: ${it.message}" }
        }
    }

    fun removePack(file: File) {
        val n = name
        viewModelScope.launch {
            val ts = withContext(Dispatchers.IO) {
                store.removePack(file)
                val files = store.packFiles(n)
                files to TextureSet.build(getApplication(), files.map { it.readBytes() })
            }
            if (name != n) return@launch
            packFiles = ts.first; textures = ts.second; revision++
        }
    }

    /** Quick-pick state options for a block, including states declared by imported behaviour packs. */
    fun hintsFor(blockName: String): List<StateHint> {
        val base = StateHints.forBlock(blockName)
        val pb = textures?.packBlocks?.firstOrNull { it.id == blockName } ?: return base
        return base + pb.states.map { (k, vals) ->
            StateHint(k, k.substringAfter(':'), vals.map { v -> v.toString() to v })
        }
    }

    // ---- tool state ---------------------------------------------------------------------------

    fun selectOp(o: Op) { op = o; anchor = null }
    fun selectShape(s: ShapeKind) { shape = s; anchor = null }

    fun selectSlot(i: Int) {
        slot = i.coerceIn(0, 8); prefs.hotbarSlot = slot
        hotbar.getOrNull(slot)?.let { current = it }
    }

    /** Sets the block of the selected hotbar slot (and uses it). */
    fun selectBlock(b: BlockState) {
        current = b
        hotbar = hotbar.toMutableList().also { it[slot] = b }
        prefs.saveHotbar(hotbar)
        recents = prefs.pushRecent(b)
    }

    fun clearSlot(i: Int) {
        hotbar = hotbar.toMutableList().also { it[i] = null }
        prefs.saveHotbar(hotbar)
    }

    fun addCustomBlock(b: BlockState) { customs = prefs.addCustom(b); selectBlock(b) }
    fun removeCustomBlock(b: BlockState) { customs = prefs.removeCustom(b) }

    // palette
    fun addToPalette(b: BlockState) {
        val i = palette.indexOfFirst { it.block == b }
        palette = if (i >= 0) palette.toMutableList().also { it[i] = PaletteEntry(b, minOf(20, it[i].weight + 1)) }
        else palette + PaletteEntry(b, 1)
        prefs.savePalette(palette)
    }
    fun addHotbarToPalette() { hotbar.filterNotNull().forEach { if (palette.none { e -> e.block == it }) addToPalette(it) } }
    fun setPaletteWeight(i: Int, w: Int) {
        palette = palette.toMutableList().also { it[i] = PaletteEntry(it[i].block, w.coerceIn(1, 20)) }
        prefs.savePalette(palette)
    }
    fun removeFromPalette(i: Int) { palette = palette.toMutableList().also { it.removeAt(i) }; prefs.savePalette(palette) }
    fun clearPalette() { palette = emptyList(); prefs.savePalette(palette) }

    private fun blockSource(): BlockSource =
        if (paletteMode && palette.isNotEmpty()) WeightedPalette(palette.map { it.block }, palette.map { it.weight })
        else SingleBlock(current)

    // settings
    // HUD layout
    fun moveHud(el: HudElement, dx: Float, dy: Float) {
        val c = hudConfig[el] ?: HudConfig()
        setHud(el, c.copy(dx = (c.dx + dx * c.scale).coerceIn(-3000f, 3000f), dy = (c.dy + dy * c.scale).coerceIn(-3000f, 3000f)))
    }
    fun scaleHud(el: HudElement, s: Float) {
        val c = hudConfig[el] ?: HudConfig()
        setHud(el, c.copy(scale = s.coerceIn(el.minScale, el.maxScale)))
    }
    private fun setHud(el: HudElement, c: HudConfig) {
        hudConfig = hudConfig.toMutableMap().also { it[el] = c }
        prefs.saveHud(el, c)
    }
    fun resetHud() { HudElement.values().forEach { setHud(it, HudConfig()) } }
    fun updateShowOutlines(v: Boolean) { showOutlines = v; prefs.showOutlines = v }
    fun updateEmptyAsAir(v: Boolean) { emptyAsAir = v; model.emptyAsAir = v; dirty = true; changedSoft() }
    fun updateBackground(argb: Int) { background = argb; prefs.background = argb }

    private fun changedSoft() { saveJob?.cancel(); val n = name; saveJob = viewModelScope.launch { delay(800); if (name == n) saveNow() } }

    fun setLayer(y: Int) { layerY = y.coerceIn(model.minY, model.maxY); if (hideAbove) revision++ }

    // ---- camera -------------------------------------------------------------------------------

    fun zoomBy(f: Float) { camera = camera.zoom(f) }
    fun fitView() { camera = Camera.fit(model, camera.yaw, camera.pitch) }
    fun setView(yaw: Float, pitch: Float) { camera = Camera.fit(model, yaw, pitch) }

    fun onTransform(zoom: Float, pan: androidx.compose.ui.geometry.Offset, w: Float, h: Float) {
        var c = camera
        if (zoom != 1f) c = c.zoom(zoom)
        if (!locked && (pan.x != 0f || pan.y != 0f)) c = c.pan(pan.x, pan.y, w, h)
        camera = c
    }

    // ---- gestures -----------------------------------------------------------------------------

    private var painting = false
    private var lastPaintKey = Long.MIN_VALUE

    private fun paintMode() = locked && shape == ShapeKind.SINGLE && op != Op.PICK && op != Op.ROTATE

    fun onGestureStart() { painting = false; lastPaintKey = Long.MIN_VALUE }

    fun onGestureEnd() {
        if (painting) { session.endStroke(); painting = false; changed() }
    }

    fun onDrag(px: Float, py: Float, dx: Float, dy: Float, w: Float, h: Float) {
        if (!loaded) return
        if (paintMode()) {
            if (!painting) { session.beginStroke(); painting = true }
            val pick = pickAt(px, py, w, h) ?: return
            val cell = targetCell(pick, op) ?: return
            if (pick.hit && op == Op.PLACE && BuildModel.key(pick.bx, pick.by, pick.bz) in session.strokeKeys) return
            val k = BuildModel.key(cell[0], cell[1], cell[2])
            if (k == lastPaintKey) return
            lastPaintKey = k
            runOp(cell, cell, silent = true)
            return
        }
        if (!locked) camera = camera.orbit(-dx * 0.4f, dy * 0.4f)
    }

    fun onTap(px: Float, py: Float, w: Float, h: Float) {
        if (!loaded) return
        val pick = pickAt(px, py, w, h) ?: return
        if (op == Op.PICK) {
            if (pick.hit) {
                model.get(pick.bx, pick.by, pick.bz)?.let { selectBlock(it); message = "Picked ${it.shortName}" }
                op = Op.PLACE
            } else message = "Tap a block to pick it"
            return
        }
        val cell = targetCell(pick, op) ?: return
        if (!shape.twoPoints) { runOp(cell, cell); return }
        val a = anchor
        if (a == null) { anchor = cell; message = "First point set — tap the second point" }
        else { anchor = null; runOp(a, cell) }
    }

    private fun pickAt(px: Float, py: Float, w: Float, h: Float): PickResult? =
        Picker.pick(model, camera, w, h, px, py, layerY, hideAbove, 0)

    private fun targetCell(p: PickResult, op: Op): IntArray? = when {
        p.hit -> if (op == Op.PLACE) intArrayOf(p.bx + p.nx, p.by + p.ny, p.bz + p.nz) else intArrayOf(p.bx, p.by, p.bz)
        p.hasPlane -> intArrayOf(p.px, p.py, p.pz)
        else -> null
    }

    private fun runOp(a: IntArray, b: IntArray, silent: Boolean = false) {
        val r = session.apply(op, shape, a, b, hollow && shape.hollowable, blockSource(),
            false, if (rotateCcw) -1 else 1)
        if (r.message != null && !silent) message = r.message
        if (r.changed > 0 || r.boundsChanged) {
            if (!painting) changed() else { refreshHistory(); revision++; dirty = true }
        }
    }

    // ---- edit commands --------------------------------------------------------------------------

    fun undo() { if (session.undo()) changed() }
    fun redo() { if (session.redo()) changed() }
    fun clearAll() { val n = session.clearAll(); if (n > 0) changed(); message = "Removed $n blocks" }
    fun cancelAnchor() { anchor = null }

    fun rotateStructure(clockwise: Boolean) {
        if (!loaded) return
        StructureTransform.rotateY(model, clockwise)
        session.clearHistory()
        camera = Camera.fit(model, camera.yaw, camera.pitch)
        changed()
        message = "Structure rotated 90° (undo history cleared)"
    }

    fun resizeSide(axis: Int, high: Boolean, delta: Int) {
        val err = model.resizeSide(axis, high, delta)
        if (err != null) message = err else changed()
    }

    fun fitGridToBlocks() { model.fitToBlocks(); changed(); fitView() }

    fun setGridSize(sx: Int, sy: Int, sz: Int) {
        val x1 = model.minX + sx - 1; val y1 = model.minY + sy - 1; val z1 = model.minZ + sz - 1
        val used = model.usedBounds()
        if (!model.boundsValid(model.minX, model.minY, model.minZ, x1, y1, z1)) {
            message = "Limit: ${BuildModel.MAX_AXIS} per axis"; return
        }
        if (used != null && (x1 < used[3] || y1 < used[4] || z1 < used[5])) { message = "Blocks would be cut off"; return }
        model.maxX = x1; model.maxY = y1; model.maxZ = z1
        changed()
    }
}
