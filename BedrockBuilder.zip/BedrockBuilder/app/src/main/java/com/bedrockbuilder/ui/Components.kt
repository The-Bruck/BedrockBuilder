package com.bedrockbuilder.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.bedrockbuilder.core.BlockState
import com.bedrockbuilder.core.BlockVisuals
import com.bedrockbuilder.core.TextureMap
import com.bedrockbuilder.data.HudConfig
import com.bedrockbuilder.data.HudElement
import kotlin.math.roundToInt

/** Block icon: the real texture when available, otherwise a flat colour swatch. */
@Composable
fun BlockIcon(textures: TextureSet?, name: String, size: Int = 28) {
    val entry = textures?.map?.entry(name)
    // prefer the top face for tinted/top-textured blocks, otherwise a side face
    val face = if (entry != null && entry.cells[2] > 0 && (entry.tints[2] != 0 || entry.cells[5] <= 0)) 2 else 5
    val cell = entry?.cells?.getOrNull(face) ?: -1
    if (textures != null && cell > 0) {
        val tint = TextureMap.TINTS[entry!!.tints[face]]
        val r = textures.map.rect(cell)
        Canvas(Modifier.size(size.dp)) {
            val px = this.size.width.toInt()
            drawImage(
                image = textures.image,
                srcOffset = IntOffset(r[0], r[1]),
                srcSize = IntSize(r[2], r[3]),
                dstSize = IntSize(px, px),
                filterQuality = FilterQuality.None,
                colorFilter = if (tint != 0xFFFFFF) ColorFilter.tint(Color(0xFF000000.toInt() or tint), BlendMode.Modulate) else null,
            )
        }
    } else {
        Box(Modifier.size(size.dp).background(Color(BlockVisuals.color(name)), RoundedCornerShape(4.dp)))
    }
}

/**
 * A Minecraft-style 9-slot hotbar. Tap a slot to select it; tap the selected (or an empty) slot, or long-press any slot,
 * to choose its block.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Hotbar(vm: EditorViewModel, onEditSlot: () -> Unit) {
    Row(
        Modifier.background(Color(0xCC1E1E1E), RoundedCornerShape(4.dp)).padding(2.dp),
        horizontalArrangement = Arrangement.spacedBy(1.dp),
    ) {
        for (i in 0 until 9) {
            val b: BlockState? = vm.hotbar.getOrNull(i)
            val selected = vm.slot == i
            Box(
                Modifier
                    .size(24.dp)
                    .background(Color(0xFF3B3B3B))
                    .border(if (selected) 2.dp else 1.dp, if (selected) Color.White else Color(0xFF151515))
                    .combinedClickable(
                        onClick = { if (selected || b == null) { vm.selectSlot(i); onEditSlot() } else vm.selectSlot(i) },
                        onLongClick = { vm.selectSlot(i); onEditSlot() },
                    ),
                contentAlignment = Alignment.Center,
            ) {
                if (b != null) BlockIcon(vm.textures, b.name, 18)
            }
        }
    }
}

/**
 * Wraps a HUD element so it can be moved and resized (see "Customize UI"). While editing, dragging the element moves it.
 */
@Composable
fun HudBox(vm: EditorViewModel, el: HudElement, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val cfg: HudConfig = vm.hudConfig[el] ?: HudConfig()
    val selected = vm.hudSelected == el
    Box(
        modifier
            .offset { IntOffset(cfg.dx.roundToInt(), cfg.dy.roundToInt()) }
            .graphicsLayer { scaleX = cfg.scale; scaleY = cfg.scale }
            .then(
                if (vm.hudEdit) Modifier.border(2.dp, if (selected) MaterialTheme.colorScheme.primary else Color(0xAAFFFFFF), RoundedCornerShape(8.dp))
                else Modifier
            )
    ) {
        content()
        if (vm.hudEdit) {
            Box(
                Modifier.matchParentSize().background(Color(0x33000000)).pointerInput(el) {
                    detectDragGestures(
                        onDragStart = { vm.hudSelected = el },
                        onDrag = { change, drag -> change.consume(); vm.moveHud(el, drag.x, drag.y) },
                    )
                }
            )
        }
    }
}


/** A pad button that reports "held" while the finger is down. The move is chosen at press time so it is always released. */
@Composable
private fun PadButton(label: String, moveFor: () -> Move, vm: EditorViewModel) {
    Box(
        Modifier.size(44.dp).background(Color(0xB0202020), RoundedCornerShape(10.dp))
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    val m = moveFor()
                    vm.setMove(m, true)
                    try { tryAwaitRelease() } finally { vm.setMove(m, false) }
                })
            },
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, style = MaterialTheme.typography.titleMedium) }
}

/** First-person movement pad: arrows walk (hold to keep moving), Up/Down fly, the centre button switches ◀▶ between strafe and turn. */
@Composable
fun MovePad(vm: EditorViewModel) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            PadButton("▲", { Move.FORWARD }, vm)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                PadButton("◀", { if (vm.arrowsTurn) Move.TURN_LEFT else Move.LEFT }, vm)
                Box(
                    Modifier.size(44.dp).background(Color(0xB0383838), RoundedCornerShape(10.dp)).clickable { vm.updateArrowsTurn(!vm.arrowsTurn) },
                    contentAlignment = Alignment.Center,
                ) { Text(if (vm.arrowsTurn) "Turn" else "Step", color = Color.White, style = MaterialTheme.typography.labelSmall) }
                PadButton("▶", { if (vm.arrowsTurn) Move.TURN_RIGHT else Move.RIGHT }, vm)
            }
            PadButton("▼", { Move.BACK }, vm)
        }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            PadButton("Up", { Move.UP }, vm)
            PadButton("Dn", { Move.DOWN }, vm)
        }
    }
}
