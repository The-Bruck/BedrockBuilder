package com.bedrockbuilder.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.bedrockbuilder.core.BlockState
import com.bedrockbuilder.core.BlockVisuals
import com.bedrockbuilder.core.TextureMap

/** Block icon: the real texture when available, otherwise a flat colour swatch. */
@Composable
fun BlockIcon(textures: TextureSet?, name: String, size: Int = 28) {
    val entry = textures?.map?.entry(name)
    // prefer the top face for tinted/top-textured blocks, otherwise a side face
    val face = if (entry != null && entry.cells[2] > 0 && (entry.tints[2] != 0 || entry.cells[5] <= 0)) 2 else 5
    val cell = entry?.cells?.getOrNull(face) ?: -1
    if (textures != null && cell > 0) {
        val tint = TextureMap.TINTS[entry!!.tints[face]]
        Canvas(Modifier.size(size.dp)) {
            val cs = textures.cellSize
            val px = this.size.width.toInt()
            drawImage(
                image = textures.image,
                srcOffset = IntOffset((cell % textures.cols) * cs, (cell / textures.cols) * cs),
                srcSize = IntSize(cs, cs),
                dstSize = IntSize(px, px),
                filterQuality = FilterQuality.None,
                colorFilter = if (tint != 0xFFFFFF) ColorFilter.tint(Color(0xFF000000.toInt() or tint), BlendMode.Modulate) else null,
            )
        }
    } else {
        Box(Modifier.size(size.dp).background(Color(BlockVisuals.color(name)), RoundedCornerShape(4.dp)))
    }
}

/** The 9-slot hotbar. Tap a slot to select it, tap the selected slot (or long-press any slot) to change its block. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Hotbar(vm: EditorViewModel, onEditSlot: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        for (i in 0 until 9) {
            val b: BlockState? = vm.hotbar.getOrNull(i)
            val selected = vm.slot == i
            Box(
                Modifier
                    .weight(1f)
                    .aspectRatio(1f)
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(6.dp))
                    .border(if (selected) 3.dp else 1.dp,
                        if (selected) MaterialTheme.colorScheme.primary else Color(0x33FFFFFF), RoundedCornerShape(6.dp))
                    .combinedClickable(
                        onClick = { if (selected || b == null) { vm.selectSlot(i); onEditSlot() } else vm.selectSlot(i) },
                        onLongClick = { vm.selectSlot(i); onEditSlot() },
                    ),
                contentAlignment = Alignment.Center,
            ) {
                if (b != null) BlockIcon(vm.textures, b.name, 28) else Text("+", style = MaterialTheme.typography.titleMedium)
                Text("${i + 1}", style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.align(Alignment.TopStart).padding(start = 3.dp, top = 1.dp),
                    color = Color(0xCCFFFFFF))
            }
        }
    }
}
