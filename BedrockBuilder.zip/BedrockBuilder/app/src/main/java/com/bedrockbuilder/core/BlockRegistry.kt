package com.bedrockbuilder.core

/**
 * Vanilla Bedrock block identifiers, taken from Mojang's bedrock-samples blocks.json (see VanillaIds).
 * Anything missing can be added in the app as a custom identifier.
 */
object BlockRegistry {
    enum class Category(val label: String) {
        BUILDING("Building"), WOOD("Wood"), COLOR("Colored"), ORE("Ores & metals"),
        NATURE("Nature"), NETHER_END("Nether & End"), REDSTONE("Redstone"),
        DECOR("Decor & utility"), TECHNICAL("Technical"),
    }

    val colors = listOf(
        "white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
        "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black",
    )

    val all: List<String> = VanillaIds.RAW.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }
        .map { "minecraft:$it" }.toList()

    private val cache = HashMap<String, Category>()

    fun category(name: String): Category = cache.getOrPut(name) { compute(name.substringAfter(':')) }

    fun inCategory(c: Category): List<String> = all.filter { category(it) == c }

    private fun any(n: String, vararg w: String) = w.any { n.contains(it) }

    private fun compute(n: String): Category {
        if (n == "air" || n.startsWith("light_block") || any(n, "structure_", "command_block", "jigsaw", "border_block",
                "info_update", "netherreactor", "moving_block", "invisible_bedrock", "reserved", "bubble_column",
                "end_portal", "end_gateway", "camera") || n == "barrier" || n == "allow" || n == "deny" || n == "portal"
        ) return Category.TECHNICAL
        if (colors.any { n.startsWith("${it}_") } && any(n, "wool", "carpet", "concrete", "terracotta", "glass", "shulker", "candle"))
            return Category.COLOR
        if (n == "hardened_clay" || n == "undyed_shulker_box" || n == "candle") return Category.COLOR
        val woody = any(n, "oak", "spruce", "birch", "jungle", "acacia", "mangrove", "cherry", "bamboo", "crimson", "warped", "poplar")
        val plantish = any(n, "leaves", "sapling", "propagule", "nylium", "roots", "fungus", "wart", "vines", "azalea")
        if (woody && !plantish && !any(n, "sandstone", "dandelion", "sugar") ) return Category.WOOD
        if (any(n, "bookshelf", "crafting_table", "barrel", "ladder", "scaffolding", "lectern", "loom", "fletching",
                "cartography", "smithing", "composter")) return Category.WOOD
        if (n.endsWith("_ore") || any(n, "ancient_debris", "copper", "amethyst", "raw_") ||
            n in setOf("coal_block", "iron_block", "gold_block", "redstone_block", "lapis_block", "diamond_block", "emerald_block", "netherite_block"))
            return Category.ORE
        if (any(n, "redstone", "repeater", "comparator", "observer", "piston", "dispenser", "dropper", "hopper", "lever",
                "pressure_plate", "button", "tripwire", "daylight", "rail", "crafter", "target", "tnt", "noteblock",
                "jukebox", "bell", "sculk_sensor", "sculk_shrieker", "sculk_catalyst"))
            return Category.REDSTONE
        if (any(n, "nether", "soul_", "basalt", "blackstone", "magma", "glowstone", "shroomlight", "end_", "purpur",
                "chorus", "bone_block", "respawn_anchor", "crying_obsidian", "ancient", "twisting", "weeping", "crimson", "warped", "lodestone", "netherite"))
            return Category.NETHER_END
        if (any(n, "stone", "brick", "sandstone", "slab", "stairs", "_wall", "prismarine", "quartz", "deepslate", "tuff",
                "cobble", "granite", "diorite", "andesite", "obsidian", "glass", "calcite", "basalt", "mud_brick", "resin") &&
            !any(n, "furnace", "stonecutter", "grindstone", "button", "pressure", "infested", "lantern", "moss_"))
            return Category.BUILDING
        if (any(n, "grass", "dirt", "sand", "gravel", "clay", "snow", "ice", "leaves", "sapling", "flower", "tulip",
                "orchid", "allium", "poppy", "dandelion", "daisy", "mushroom", "vine", "kelp", "seagrass", "coral",
                "water", "lava", "moss", "mud", "podzol", "mycelium", "fern", "bush", "cactus", "bamboo", "wheat",
                "carrot", "potato", "beetroot", "melon", "pumpkin", "hay_block", "sponge", "slime", "honey", "bee",
                "dripstone", "sculk", "egg", "farmland", "azalea", "dripleaf", "lichen", "lily", "petals", "bedrock",
                "peony", "lilac", "rose", "sunflower", "pitcher", "torchflower", "cornflower", "spore", "reeds", "deadbush",
                "cocoa", "berry", "froglight", "frog", "turtle", "grass_path", "eyeblossom", "wildflowers", "leaf_litter"))
            return Category.NATURE
        return Category.DECOR
    }
}
