package com.bedrockbuilder.core

/**
 * Vanilla Bedrock block identifiers (best-effort, Bedrock 1.21 naming), grouped by category.
 * Anything missing can be added in the app as a custom identifier.
 */
object BlockRegistry {
    enum class Category(val label: String) {
        BUILDING("Building"), WOOD("Wood"), COLOR("Colored"), ORE("Ores & metals"),
        NATURE("Nature"), NETHER_END("Nether & End"), REDSTONE("Redstone"),
        DECOR("Decor & utility"), TECHNICAL("Technical"),
    }

    val colors = listOf(
        "white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
        "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black",
    )
    val overworldWoods = listOf("oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry", "pale_oak")
    val netherWoods = listOf("crimson", "warped")

    private val byName = LinkedHashMap<String, Category>()

    private fun add(cat: Category, names: String) {
        for (n in names.split(Regex("\\s+"))) {
            if (n.isEmpty()) continue
            byName.putIfAbsent("minecraft:$n", cat)
        }
    }

    private fun woodName(w: String, kind: String): String {
        if (w == "oak") when (kind) {
            "door" -> return "wooden_door"
            "trapdoor" -> return "trapdoor"
            "button" -> return "wooden_button"
            "pressure_plate" -> return "wooden_pressure_plate"
            "fence_gate" -> return "fence_gate"
            "fence" -> return "fence"
            "standing_sign" -> return "standing_sign"
            "wall_sign" -> return "wall_sign"
        }
        return "${w}_$kind"
    }

    init {
        for (w in overworldWoods) {
            for (k in listOf("planks", "log", "wood", "stripped_log", "stripped_wood", "slab", "stairs", "fence",
                "fence_gate", "door", "trapdoor", "button", "pressure_plate", "standing_sign", "wall_sign"))
                add(Category.WOOD, woodName(w, k))
            add(Category.NATURE, "${w}_leaves ${w}_sapling")
        }
        add(Category.WOOD, """bamboo_planks bamboo_mosaic bamboo_block stripped_bamboo_block bamboo_slab bamboo_stairs
            bamboo_mosaic_slab bamboo_mosaic_stairs bamboo_fence bamboo_fence_gate bamboo_door bamboo_trapdoor
            bamboo_button bamboo_pressure_plate""")
        for (w in netherWoods) {
            add(Category.WOOD, """${w}_planks ${w}_stem stripped_${w}_stem ${w}_hyphae stripped_${w}_hyphae ${w}_slab
                ${w}_stairs ${w}_fence ${w}_fence_gate ${w}_door ${w}_trapdoor ${w}_button ${w}_pressure_plate
                ${w}_standing_sign ${w}_wall_sign""")
        }
        add(Category.WOOD, "bookshelf chiseled_bookshelf crafting_table barrel composter ladder scaffolding lectern loom fletching_table cartography_table smithing_table")

        for (c in colors) {
            val glaze = if (c == "light_gray") "silver" else c
            add(Category.COLOR, "${c}_wool ${c}_carpet ${c}_concrete ${c}_concrete_powder ${c}_terracotta ${glaze}_glazed_terracotta " +
                "${c}_stained_glass ${c}_stained_glass_pane ${c}_shulker_box ${c}_candle")
        }
        add(Category.COLOR, "hardened_clay undyed_shulker_box candle")

        add(Category.BUILDING, """stone granite polished_granite diorite polished_diorite andesite polished_andesite cobblestone
            mossy_cobblestone stone_bricks mossy_stone_bricks cracked_stone_bricks chiseled_stone_bricks smooth_stone
            bricks sandstone chiseled_sandstone cut_sandstone smooth_sandstone red_sandstone chiseled_red_sandstone
            cut_red_sandstone smooth_red_sandstone quartz_block chiseled_quartz_block quartz_pillar quartz_bricks smooth_quartz
            purpur_block purpur_pillar prismarine prismarine_bricks dark_prismarine nether_bricks red_nether_bricks
            chiseled_nether_bricks cracked_nether_bricks end_stone_bricks mud_bricks packed_mud
            deepslate cobbled_deepslate polished_deepslate deepslate_bricks cracked_deepslate_bricks deepslate_tiles
            cracked_deepslate_tiles chiseled_deepslate reinforced_deepslate tuff polished_tuff tuff_bricks chiseled_tuff
            chiseled_tuff_bricks blackstone polished_blackstone polished_blackstone_bricks cracked_polished_blackstone_bricks
            chiseled_polished_blackstone gilded_blackstone calcite smooth_basalt basalt polished_basalt
            obsidian crying_obsidian glass tinted_glass glass_pane iron_bars chain""")
        val stairBases = """cobblestone mossy_cobblestone stone_brick mossy_stone_brick granite polished_granite diorite
            polished_diorite andesite polished_andesite brick sandstone smooth_sandstone red_sandstone smooth_red_sandstone
            nether_brick red_nether_brick quartz smooth_quartz purpur prismarine prismarine_brick dark_prismarine end_stone_brick
            blackstone polished_blackstone polished_blackstone_brick cobbled_deepslate polished_deepslate deepslate_brick
            deepslate_tile mud_brick tuff polished_tuff tuff_brick""".split(Regex("\\s+")).filter { it.isNotEmpty() }
        for (s in stairBases) {
            val stairId = when (s) { "cobblestone" -> "stone_stairs"; else -> "${s}_stairs" }
            add(Category.BUILDING, "$stairId ${s}_slab")
        }
        add(Category.BUILDING, "normal_stone_stairs stone_slab smooth_stone_slab cut_sandstone_slab cut_red_sandstone_slab")
        for (s in listOf("cobblestone", "mossy_cobblestone", "stone_brick", "mossy_stone_brick", "granite", "diorite", "andesite",
            "brick", "sandstone", "red_sandstone", "nether_brick", "red_nether_brick", "prismarine", "end_stone_brick",
            "blackstone", "polished_blackstone", "polished_blackstone_brick", "cobbled_deepslate", "polished_deepslate",
            "deepslate_brick", "deepslate_tile", "mud_brick", "tuff", "polished_tuff", "tuff_brick"))
            add(Category.BUILDING, "${s}_wall")

        // Copper
        val tiers = listOf("", "exposed_", "weathered_", "oxidized_")
        for (wax in listOf("", "waxed_")) for (t in tiers) {
            val p = wax + t
            add(Category.ORE, "${p}copper ${p}cut_copper ${p}chiseled_copper ${p}copper_grate ${p}copper_bulb " +
                "${p}cut_copper_stairs ${p}cut_copper_slab ${p}copper_door ${p}copper_trapdoor")
        }
        add(Category.ORE, "copper_block exposed_copper weathered_copper oxidized_copper waxed_copper_block waxed_exposed_copper waxed_weathered_copper waxed_oxidized_copper")

        add(Category.ORE, """coal_ore iron_ore copper_ore gold_ore redstone_ore lit_redstone_ore lapis_ore diamond_ore emerald_ore
            deepslate_coal_ore deepslate_iron_ore deepslate_copper_ore deepslate_gold_ore deepslate_redstone_ore
            lit_deepslate_redstone_ore deepslate_lapis_ore deepslate_diamond_ore deepslate_emerald_ore nether_gold_ore
            quartz_ore ancient_debris coal_block iron_block gold_block redstone_block lapis_block diamond_block emerald_block
            netherite_block raw_iron_block raw_copper_block raw_gold_block amethyst_block budding_amethyst small_amethyst_bud
            medium_amethyst_bud large_amethyst_bud amethyst_cluster""")

        add(Category.NATURE, """grass_block dirt coarse_dirt dirt_with_roots podzol mycelium grass_path farmland mud
            muddy_mangrove_roots mangrove_roots mangrove_propagule clay gravel sand red_sand suspicious_sand suspicious_gravel
            snow snow_layer ice packed_ice blue_ice frosted_ice powder_snow bedrock moss_block moss_carpet pale_moss_block
            pale_moss_carpet hanging_roots sculk sculk_catalyst sculk_sensor calibrated_sculk_sensor sculk_shrieker sculk_vein
            dripstone_block pointed_dripstone short_grass tall_grass fern large_fern dandelion poppy blue_orchid allium
            azure_bluet red_tulip orange_tulip white_tulip pink_tulip oxeye_daisy cornflower lily_of_the_valley wither_rose
            torchflower sunflower lilac rose_bush peony pitcher_plant pitcher_crop spore_blossom azalea flowering_azalea
            azalea_leaves flowering_azalea_leaves big_dripleaf small_dripleaf_block glow_lichen vine waterlily
            brown_mushroom red_mushroom brown_mushroom_block red_mushroom_block mushroom_stem dead_bush wheat carrots
            potatoes beetroot melon_stem pumpkin_stem sweet_berry_bush cave_vines cave_vines_head_with_berries cocoa
            torchflower_crop bamboo bamboo_sapling cactus reeds pumpkin carved_pumpkin lit_pumpkin melon_block hay_block
            kelp seagrass sea_pickle sponge wet_sponge water flowing_water lava flowing_lava bee_nest beehive
            honey_block honeycomb_block slime tube_coral_block brain_coral_block bubble_coral_block fire_coral_block
            horn_coral_block dead_tube_coral_block dead_brain_coral_block dead_bubble_coral_block dead_fire_coral_block
            dead_horn_coral_block tube_coral brain_coral bubble_coral fire_coral horn_coral cherry_leaves turtle_egg
            frog_spawn sniffer_egg open_eyeblossom closed_eyeblossom firefly_bush leaf_litter wildflowers cactus_flower""")

        add(Category.NETHER_END, """netherrack warped_nylium crimson_nylium soul_sand soul_soil magma glowstone shroomlight
            nether_wart_block warped_wart_block nether_wart nether_sprouts warped_roots crimson_roots warped_fungus crimson_fungus
            weeping_vines twisting_vines bone_block respawn_anchor end_stone end_rod end_portal_frame end_portal end_gateway
            dragon_egg chorus_plant chorus_flower sea_lantern netherite_block lodestone crimson_roots basalt soul_fire fire soul_torch""")

        add(Category.REDSTONE, """redstone_wire unpowered_repeater powered_repeater unpowered_comparator powered_comparator observer
            piston sticky_piston dispenser dropper hopper lever stone_button polished_blackstone_button stone_pressure_plate
            polished_blackstone_pressure_plate light_weighted_pressure_plate heavy_weighted_pressure_plate tripwire_hook tripwire
            daylight_detector redstone_lamp lit_redstone_lamp rail golden_rail detector_rail activator_rail crafter target
            lightning_rod tnt trapped_chest redstone_torch unlit_redstone_torch iron_door iron_trapdoor note_block noteblock
            jukebox bell""")

        add(Category.DECOR, """torch lantern soul_lantern campfire soul_campfire flower_pot decorated_pot chest ender_chest
            furnace lit_furnace blast_furnace lit_blast_furnace smoker lit_smoker stonecutter_block grindstone anvil
            enchanting_table brewing_stand cauldron beacon conduit cake web light_blue_candle_cake end_rod
            sea_lantern coral_fan bed trial_spawner vault spawner mob_spawner heavy_core creaking_heart
            copper_chest""")

        add(Category.TECHNICAL, """air barrier light_block structure_void structure_block command_block repeating_command_block
            chain_command_block jigsaw allow deny border_block moving_block
            invisible_bedrock""")
        add(Category.DECOR, "iron_bars")
    }

    val all: List<String> = byName.keys.sortedBy { it.substringAfter(':') }

    fun category(name: String): Category? = byName[name]

    fun inCategory(c: Category): List<String> = all.filter { byName[it] == c }
}
