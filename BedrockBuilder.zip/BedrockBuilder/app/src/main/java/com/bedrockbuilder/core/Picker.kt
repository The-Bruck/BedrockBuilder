package com.bedrockbuilder.core

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sqrt

class PickResult(
    val hit: Boolean, val bx: Int, val by: Int, val bz: Int,
    val nx: Int, val ny: Int, val nz: Int,
    val hasPlane: Boolean, val px: Int, val py: Int, val pz: Int,
)

object Picker {
    /**
     * Casts a ray through screen point (sx, sy). Finds the first block hit and/or the cell on the
     * active layer plane (y = layerY). planeMargin allows plane cells outside the grid (for auto-expand).
     */
    fun pick(
        model: BuildModel, cam: Camera, w: Float, h: Float, sx: Float, sy: Float,
        layerY: Int, hideAbove: Boolean, planeMargin: Int,
    ): PickResult? {
        val b = cam.basis()
        val f = cam.focal(w, h)
        val a = (sx - w / 2f) / f
        val c = -(sy - h / 2f) / f
        var dx = (b.rx * a + b.ux * c + b.fx).toDouble()
        var dy = (b.ry * a + b.uy * c + b.fy).toDouble()
        var dz = (b.rz * a + b.uz * c + b.fz).toDouble()
        val len = sqrt(dx * dx + dy * dy + dz * dz)
        dx /= len; dy /= len; dz /= len
        val ox = b.px.toDouble(); val oy = b.py.toDouble(); val oz = b.pz.toDouble()

        var hit = false
        var bx = 0; var by = 0; var bz = 0; var nx = 0; var ny = 0; var nz = 0
        var tHit = Double.MAX_VALUE

        // ray vs grid AABB
        val lo = doubleArrayOf(model.minX.toDouble(), model.minY.toDouble(), model.minZ.toDouble())
        val hi = doubleArrayOf(model.maxX + 1.0, model.maxY + 1.0, model.maxZ + 1.0)
        val o = doubleArrayOf(ox, oy, oz); val d = doubleArrayOf(dx, dy, dz)
        var tmin = 0.0; var tmax = Double.MAX_VALUE
        var entryAxis = -1
        var ok = true
        for (i in 0..2) {
            if (abs(d[i]) < 1e-12) {
                if (o[i] < lo[i] || o[i] > hi[i]) { ok = false; break }
            } else {
                var t1 = (lo[i] - o[i]) / d[i]; var t2 = (hi[i] - o[i]) / d[i]
                if (t1 > t2) { val t = t1; t1 = t2; t2 = t }
                if (t1 > tmin) { tmin = t1; entryAxis = i }
                if (t2 < tmax) tmax = t2
                if (tmin > tmax) { ok = false; break }
            }
        }
        if (ok && tmax > 0) {
            val t0 = tmin + 1e-7
            var cx = floor(ox + dx * t0).toInt().coerceIn(model.minX, model.maxX)
            var cy = floor(oy + dy * t0).toInt().coerceIn(model.minY, model.maxY)
            var cz = floor(oz + dz * t0).toInt().coerceIn(model.minZ, model.maxZ)
            val step = intArrayOf(if (dx > 0) 1 else -1, if (dy > 0) 1 else -1, if (dz > 0) 1 else -1)
            val cell = intArrayOf(cx, cy, cz)
            val tMax = DoubleArray(3); val tDelta = DoubleArray(3)
            for (i in 0..2) {
                if (abs(d[i]) < 1e-12) { tMax[i] = Double.MAX_VALUE; tDelta[i] = Double.MAX_VALUE }
                else {
                    val next = if (step[i] > 0) cell[i] + 1.0 else cell[i].toDouble()
                    tMax[i] = (next - o[i]) / d[i]
                    tDelta[i] = abs(1.0 / d[i])
                }
            }
            val nrm = IntArray(3)
            if (entryAxis >= 0) nrm[entryAxis] = -step[entryAxis]
            var t = t0
            val maxSteps = model.sizeX + model.sizeY + model.sizeZ + 4
            var n = 0
            while (n++ < maxSteps) {
                cx = cell[0]; cy = cell[1]; cz = cell[2]
                if (!model.inBounds(cx, cy, cz)) break
                if (model.has(cx, cy, cz) && !(hideAbove && cy > layerY)) {
                    hit = true; bx = cx; by = cy; bz = cz
                    nx = nrm[0]; ny = nrm[1]; nz = nrm[2]; tHit = t
                    break
                }
                var ax = 0
                if (tMax[1] < tMax[ax]) ax = 1
                if (tMax[2] < tMax[ax]) ax = 2
                t = tMax[ax]; tMax[ax] += tDelta[ax]
                cell[ax] += step[ax]
                nrm[0] = 0; nrm[1] = 0; nrm[2] = 0; nrm[ax] = -step[ax]
            }
        }

        var hasPlane = false; var px = 0; var pz = 0; var tp = Double.MAX_VALUE
        if (abs(dy) > 1e-9) {
            val t = (layerY - oy) / dy
            if (t > 0) {
                val hx = floor(ox + dx * t).toInt(); val hz = floor(oz + dz * t).toInt()
                if (hx in (model.minX - planeMargin)..(model.maxX + planeMargin) &&
                    hz in (model.minZ - planeMargin)..(model.maxZ + planeMargin)) {
                    hasPlane = true; px = hx; pz = hz; tp = t
                }
            }
        }
        if (hit && hasPlane && tp < tHit - 1e-4) hit = false
        if (!hit && !hasPlane) return null
        return PickResult(hit, bx, by, bz, nx, ny, nz, hasPlane, px, layerY, pz)
    }
}
