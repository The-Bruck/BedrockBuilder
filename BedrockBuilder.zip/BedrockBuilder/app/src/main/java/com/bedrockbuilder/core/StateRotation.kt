package com.bedrockbuilder.core

/** Rotates block orientation states by 90° steps clockwise (seen from above; +X east, +Z south). */
object StateRotation {
    // clockwise cycles
    private val STAIRS = mapOf(0 to 2, 2 to 1, 1 to 3, 3 to 0)            // E->S->W->N
    private val FACING = mapOf(2 to 5, 5 to 3, 3 to 4, 4 to 2)            // N->E->S->W
    private val CARDINAL = mapOf("north" to "east", "east" to "south", "south" to "west", "west" to "north")
    private val RAIL = mapOf(0 to 1, 1 to 0, 2 to 5, 5 to 3, 3 to 4, 4 to 2, 6 to 7, 7 to 8, 8 to 9, 9 to 6)

    /** Returns the block rotated by [steps] quarter turns (negative = counter-clockwise), or the same block if nothing rotates. */
    fun rotate(s: BlockState, steps: Int): BlockState {
        var r = ((steps % 4) + 4) % 4
        var cur = s
        while (r-- > 0) cur = once(cur)
        return cur
    }

    private fun once(s: BlockState): BlockState {
        if (s.states.isEmpty()) return s
        val n = s.shortName
        var out = s
        for ((k, v) in s.states) {
            val nv: Any? = when (k) {
                "weirdo_direction" -> (v as? Int)?.let { STAIRS[it] }
                "facing_direction", "minecraft:facing_direction" -> (v as? Int)?.let { FACING[it] }
                "direction" -> (v as? Int)?.let {
                    if (n.endsWith("trapdoor")) STAIRS[it] else (it + 1) % 4
                }
                "pillar_axis" -> when (v) { "x" -> "z"; "z" -> "x"; else -> null }
                "minecraft:cardinal_direction", "minecraft:facing_direction_cardinal" -> CARDINAL[v as? String]
                "torch_facing_direction" -> CARDINAL[v as? String]
                "rail_direction" -> (v as? Int)?.let { RAIL[it] }
                else -> null
            }
            if (nv != null && nv != v) out = out.withState(k, nv)
        }
        return out
    }
}
