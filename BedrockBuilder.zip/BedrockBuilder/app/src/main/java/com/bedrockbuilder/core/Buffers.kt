package com.bedrockbuilder.core

class LongBuf(cap: Int = 1024) {
    var data = LongArray(cap)
    var size = 0
    fun add(v: Long) {
        if (size == data.size) data = data.copyOf(data.size * 2)
        data[size++] = v
    }
}

class FloatBuf(cap: Int = 1024) {
    var data = FloatArray(cap)
    var size = 0
    fun add(v: Float) {
        if (size == data.size) data = data.copyOf(data.size * 2)
        data[size++] = v
    }
    fun add4(a: Float, b: Float, c: Float, d: Float) { add(a); add(b); add(c); add(d) }
}

class IntBuf(cap: Int = 1024) {
    var data = IntArray(cap)
    var size = 0
    fun add(v: Int) {
        if (size == data.size) data = data.copyOf(data.size * 2)
        data[size++] = v
    }
}
