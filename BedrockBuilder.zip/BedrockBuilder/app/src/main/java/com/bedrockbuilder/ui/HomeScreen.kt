package com.bedrockbuilder.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.bedrockbuilder.data.StructureStore
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: HomeViewModel, onOpen: (String) -> Unit) {
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var showNew by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<String?>(null) }
    var exporting by remember { mutableStateOf<String?>(null) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importUri(uri) { onOpen(it) }
    }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri -> val n = exporting; if (uri != null && n != null) vm.exportTo(n, uri); exporting = null }

    LaunchedEffect(vm.message) { vm.message?.let { snackbar.showSnackbar(it); vm.message = null } }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Bedrock Builder") },
                actions = {
                    TextButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) { Text("Import") }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showNew = true }, icon = { Icon(Icons.Default.Add, null) }, text = { Text("New structure") })
        },
    ) { padding ->
        if (vm.entries.isEmpty()) {
            Column(Modifier.padding(padding).fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally) {
                Text("No structures yet", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text("Create a new one or import an existing .mcstructure file. Everything works offline.",
                    style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(12.dp, 8.dp, 12.dp, 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.entries, key = { it.name }) { e ->
                    StructureCard(
                        e, onOpen = { if (e.error == null) onOpen(e.name) },
                        onRename = { renaming = e.name }, onDuplicate = { vm.duplicate(e.name) },
                        onExport = { exporting = e.name; exportLauncher.launch("${e.name}.mcstructure") },
                        onShare = { vm.shareFile(e.name) { shareStructureFile(context, it) } },
                        onDelete = { deleting = e.name },
                    )
                }
            }
        }
    }

    if (showNew) NewStructureDialog(vm.suggestName(), onDismiss = { showNew = false }) { n, x, y, z ->
        showNew = false; vm.create(n, x, y, z) { onOpen(it) }
    }
    renaming?.let { old ->
        TextInputDialog("Rename", old, onDismiss = { renaming = null }) { vm.rename(old, it); renaming = null }
    }
    deleting?.let { n ->
        AlertDialog(
            onDismissRequest = { deleting = null }, title = { Text("Delete \"$n\"?") },
            text = { Text("This removes it from the app. Exported copies are not affected.") },
            confirmButton = { TextButton(onClick = { vm.delete(n); deleting = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun StructureCard(
    e: StructureStore.Entry, onOpen: () -> Unit, onRename: () -> Unit, onDuplicate: () -> Unit,
    onExport: () -> Unit, onShare: () -> Unit, onDelete: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().clickable(onClick = onOpen)) {
        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(e.name, style = MaterialTheme.typography.titleMedium)
                if (e.error != null) Text("Unreadable: ${e.error}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                else Text("${e.sx}×${e.sy}×${e.sz} · ${e.blocks} blocks · " +
                    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(e.modified)),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Options") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (e.error == null) {
                        DropdownMenuItem(text = { Text("Export .mcstructure") }, onClick = { menu = false; onExport() })
                        DropdownMenuItem(text = { Text("Share…") }, onClick = { menu = false; onShare() })
                        DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menu = false; onDuplicate() })
                    }
                    DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; onRename() })
                    DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() })
                }
            }
        }
    }
}

@Composable
private fun NewStructureDialog(defaultName: String, onDismiss: () -> Unit, onCreate: (String, Int, Int, Int) -> Unit) {
    var name by remember { mutableStateOf(defaultName) }
    var x by remember { mutableStateOf("16") }
    var y by remember { mutableStateOf("16") }
    var z by remember { mutableStateOf("16") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New structure") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Name") })
                Text("Starting grid size (you can expand it anytime)", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(Triple("X", x, { v: String -> x = v }), Triple("Y", y, { v: String -> y = v }), Triple("Z", z, { v: String -> z = v }))
                        .forEach { (l, v, set) ->
                            OutlinedTextField(v, { set(it.filter(Char::isDigit).take(3)) }, Modifier.weight(1f), singleLine = true,
                                label = { Text(l) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onCreate(name, x.toIntOrNull() ?: 0, y.toIntOrNull() ?: 0, z.toIntOrNull() ?: 0) }) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun TextInputDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true) },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onOk(text) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
