package com.bedrockbuilder.core

class Mesh(
    val count: Int,
    val corners: FloatArray,   // 12 floats per face (4 xyz corners)
    val centers: FloatArray,   // 3 floats per face
    val colors: IntArray,      // shaded/tinted ARGB per face (modulates the texture)
    val dirs: ByteArray,       // 0:+X 1:-X 2:+Y 3:-Y 4:+Z 5:-Z, 6: double-sided sprite, 7: model face (uses normals)
    val uvs: FloatArray,       // 8 floats per face: atlas pixel coordinates for each corner
    val normals: FloatArray,   // 3 floats per face (only meaningful for dirs == 7)
)

object MeshBuilder {
    private val SHADE = floatArrayOf(0.80f, 0.68f, 1.0f, 0.50f, 0.88f, 0.60f)
    private val DX = intArrayOf(1, -1, 0, 0, 0, 0)
    private val DY = intArrayOf(0, 0, 1, -1, 0, 0)
    private val DZ = intArrayOf(0, 0, 0, 0, 1, -1)
    private val WHITE = intArrayOf(0, 0, 16, 16)

    fun build(model: BuildModel, hideAbove: Boolean, layerY: Int, textures: TextureMap? = null): Mesh {
        val pal = model.palette
        val tex = Array(pal.size) { textures?.entry(pal[it].name) }
        val geo = Array(pal.size) { textures?.model(pal[it].name) }
        val boxes = Array(pal.size) { BlockVisuals.boxes(pal[it]) }
        val base = IntArray(pal.size) { BlockVisuals.color(pal[it].name) }
        val trans = BooleanArray(pal.size) { BlockVisuals.isTranslucent(pal[it].name) }
        val occl = BooleanArray(pal.size) { BlockVisuals.occludes(pal[it]) && geo[it] == null }
        val sprite = BooleanArray(pal.size) { BlockVisuals.isSprite(pal[it]) && geo[it] == null }
        val glassy = BooleanArray(pal.size) { pal[it].shortName.contains("glass") }

        val corners = FloatBuf(1 shl 14); val centers = FloatBuf(1 shl 13)
        val colors = IntBuf(1 shl 12); val uvs = FloatBuf(1 shl 13); val normals = FloatBuf(1 shl 13)
        var count = 0
        var dirArr = ByteArray(1 shl 12)

        fun rectOf(id: Int): IntArray = textures?.rect(id) ?: WHITE

        fun pushFace(d: Int) {
            if (count == dirArr.size) dirArr = dirArr.copyOf(dirArr.size * 2)
            dirArr[count] = d.toByte()
            count++
            val o = corners.size - 12
            centers.add((corners.data[o] + corners.data[o + 6]) / 2f)
            centers.add((corners.data[o + 1] + corners.data[o + 7]) / 2f)
            centers.add((corners.data[o + 2] + corners.data[o + 8]) / 2f)
        }

        /** Regular block face: fractional UVs (0..1) derived from the corner positions inside the cell. */
        fun addFace(d: Int, color: Int, texId: Int, ox: Int, oy: Int, oz: Int) {
            pushFace(d)
            colors.add(color)
            normals.add(0f); normals.add(0f); normals.add(0f)
            val r = rectOf(texId)
            val o = corners.size - 12
            for (j in 0 until 4) {
                val lx = corners.data[o + 3 * j] - ox; val ly = corners.data[o + 3 * j + 1] - oy; val lz = corners.data[o + 3 * j + 2] - oz
                val u: Float; val v: Float
                when (d) {
                    0 -> { u = 1f - lz; v = 1f - ly }
                    1 -> { u = lz; v = 1f - ly }
                    2, 3 -> { u = lx; v = lz }
                    4 -> { u = lx; v = 1f - ly }
                    5 -> { u = 1f - lx; v = 1f - ly }
                    else -> { u = if (j == 0 || j == 3) 0f else 1f; v = if (j < 2) 1f else 0f }
                }
                uvs.add(r[0] + 0.02f + u.coerceIn(0f, 1f) * (r[2] - 0.04f))
                uvs.add(r[1] + 0.02f + v.coerceIn(0f, 1f) * (r[3] - 0.04f))
            }
        }

        fun shaded(c0: Int, s: Float, alpha: Int, tint: Int, textured: Boolean): Int {
            val rgb = if (textured) TextureMap.TINTS[tint] else c0
            val r = (((rgb shr 16) and 255) * s).toInt(); val g = (((rgb shr 8) and 255) * s).toInt(); val b = ((rgb and 255) * s).toInt()
            return (alpha shl 24) or (r shl 16) or (g shl 8) or b
        }

        fun normalShade(n: FloatArray): Float {
            val ax = Math.abs(n[0]); val ay = Math.abs(n[1]); val az = Math.abs(n[2])
            val sum = ax + ay + az
            if (sum < 1e-6f) return 0.8f
            val sx = if (n[0] >= 0) SHADE[0] else SHADE[1]
            val sy = if (n[1] >= 0) SHADE[2] else SHADE[3]
            val sz = if (n[2] >= 0) SHADE[4] else SHADE[5]
            return (sx * ax + sy * ay + sz * az) / sum
        }

        for ((key, id) in model.blocks) {
            val x = BuildModel.kx(key); val y = BuildModel.ky(key); val z = BuildModel.kz(key)
            if (hideAbove && y > layerY) continue
            val st = pal[id]
            val te = tex[id]
            val alpha = if (trans[id] && !glassy[id]) 0xB0 else 0xFF
            val axis = st.states["pillar_axis"] as? String

            val me = geo[id]
            if (me != null) {
                // custom 3D model from an imported pack
                for (f in me.model.faces) {
                    val tid = me.texIds[f.bone] ?: me.defaultId
                    val textured = tid > 0
                    val r = rectOf(if (textured) tid else 0)
                    for (j in 0 until 4) {
                        corners.add(x + f.corners[3 * j]); corners.add(y + f.corners[3 * j + 1]); corners.add(z + f.corners[3 * j + 2])
                    }
                    pushFace(7)
                    colors.add(shaded(base[id], normalShade(f.normal), 0xFF, 0, textured))
                    normals.add(f.normal[0]); normals.add(f.normal[1]); normals.add(f.normal[2])
                    for (j in 0 until 4) {
                        val u = (f.uv[2 * j] / me.model.texW).coerceIn(0f, 1f); val v = (f.uv[2 * j + 1] / me.model.texH).coerceIn(0f, 1f)
                        uvs.add(r[0] + 0.02f + u * (r[2] - 0.04f)); uvs.add(r[1] + 0.02f + v * (r[3] - 0.04f))
                    }
                }
                continue
            }

            if (sprite[id]) {
                // two crossed double-sided quads
                val c = te?.cells?.get(5) ?: -1
                val tint = te?.tints?.get(5) ?: 0
                val col = shaded(base[id], 0.9f, 0xFF, tint, c > 0)
                for (flip in 0..1) {
                    val fx0 = x + 0.05f; val fx1 = x + 0.95f
                    if (flip == 0) corners.add4Quad(fx0, y.toFloat(), z + 0.05f, fx1, y + 1f, z + 0.95f)
                    else corners.add4Quad(fx0, y.toFloat(), z + 0.95f, fx1, y + 1f, z + 0.05f)
                    addFace(6, col, if (c > 0) c else 0, x, y, z)
                }
                continue
            }

            val cull = BooleanArray(6)
            for (d in 0 until 6) {
                val ny = y + DY[d]
                if (hideAbove && ny > layerY) continue
                val nid = model.blocks[BuildModel.key(x + DX[d], ny, z + DZ[d])] ?: continue
                cull[d] = occl[nid] || (trans[id] && nid == id)
            }
            val c0 = base[id]
            for (b in boxes[id]) {
                val x0 = x + b[0]; val y0 = y + b[1]; val z0 = z + b[2]
                val x1 = x + b[3]; val y1 = y + b[4]; val z1 = z + b[5]
                for (d in 0 until 6) {
                    val onEdge = when (d) {
                        0 -> b[3] >= 0.9999f; 1 -> b[0] <= 0.0001f
                        2 -> b[4] >= 0.9999f; 3 -> b[1] <= 0.0001f
                        4 -> b[5] >= 0.9999f; else -> b[2] <= 0.0001f
                    }
                    if (onEdge && cull[d]) continue
                    when (d) {
                        0 -> quad(corners, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1)
                        1 -> quad(corners, x0, y0, z0, x0, y1, z0, x0, y1, z1, x0, y0, z1)
                        2 -> quad(corners, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1)
                        3 -> quad(corners, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1)
                        4 -> quad(corners, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1)
                        else -> quad(corners, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0)
                    }
                    // texture face (pillar blocks rotate their top/bottom texture onto the axis faces)
                    var td = d
                    if (axis == "x" && d <= 1) td = 2 else if (axis == "x" && (d == 2 || d == 3)) td = 4
                    else if (axis == "z" && d >= 4) td = 2 else if (axis == "z" && (d == 2 || d == 3)) td = 0
                    val c = te?.cells?.get(td) ?: -1
                    val textured = c > 0
                    val tint = if (textured) te!!.tints[td] else 0
                    addFace(d, shaded(c0, SHADE[d], alpha, tint, textured), if (textured) c else 0, x, y, z)
                }
            }
        }
        return Mesh(count, corners.data, centers.data, colors.data, dirArr, uvs.data, normals.data)
    }

    private fun FloatBuf.add4Quad(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float) {
        add(x0); add(y0); add(z0); add(x1); add(y0); add(z1); add(x1); add(y1); add(z1); add(x0); add(y1); add(z0)
    }

    private fun quad(b: FloatBuf, a0: Float, a1: Float, a2: Float, b0: Float, b1: Float, b2: Float,
                     c0: Float, c1: Float, c2: Float, d0: Float, d1: Float, d2: Float) {
        b.add(a0); b.add(a1); b.add(a2); b.add(b0); b.add(b1); b.add(b2)
        b.add(c0); b.add(c1); b.add(c2); b.add(d0); b.add(d1); b.add(d2)
    }
}

/** Projects, depth-sorts (painter's algorithm) and batches mesh faces into quads for drawing. */
class FrameRenderer {
    companion object { const val CHUNK_QUADS = 8192 }

    val verts = FloatArray(CHUNK_QUADS * 8)
    val texs = FloatArray(CHUNK_QUADS * 8)
    val colors = IntArray(CHUNK_QUADS * 4)
    val indices = ShortArray(CHUNK_QUADS * 6).also {
        for (q in 0 until CHUNK_QUADS) {
            val v = q * 4; val i = q * 6
            it[i] = v.toShort(); it[i + 1] = (v + 1).toShort(); it[i + 2] = (v + 2).toShort()
            it[i + 3] = v.toShort(); it[i + 4] = (v + 2).toShort(); it[i + 5] = (v + 3).toShort()
        }
    }
    private var keys = LongArray(0)

    /** Calls flush(quadCount) whenever the verts/texs/colors/indices arrays are full or at the end. Returns faces drawn. */
    fun render(mesh: Mesh, cam: Camera, w: Float, h: Float, outline: Boolean, flush: (Int) -> Unit): Int {
        val b = cam.basis()
        val f = Projection.focal(w, h)
        if (keys.size < mesh.count) keys = LongArray(mesh.count)
        var m = 0
        val c = mesh.centers
        for (i in 0 until mesh.count) {
            val vx = b.px - c[3 * i]; val vy = b.py - c[3 * i + 1]; val vz = b.pz - c[3 * i + 2]
            val d = mesh.dirs[i].toInt()
            val facing = when (d) {
                0 -> vx; 1 -> -vx; 2 -> vy; 3 -> -vy; 4 -> vz; 5 -> -vz
                7 -> vx * mesh.normals[3 * i] + vy * mesh.normals[3 * i + 1] + vz * mesh.normals[3 * i + 2]
                else -> 1f
            }
            if (facing <= 0f) continue
            val d2 = vx * vx + vy * vy + vz * vz
            keys[m++] = ((Int.MAX_VALUE - d2.toRawBits()).toLong() shl 32) or i.toLong()
        }
        java.util.Arrays.sort(keys, 0, m)

        val cx = w / 2f; val cy = h / 2f
        val sx = FloatArray(4); val sy = FloatArray(4)
        var quads = 0
        var drawn = 0
        val corners = mesh.corners
        val near = 0.05f
        for (k in 0 until m) {
            val i = (keys[k] and 0xFFFFFFFFL).toInt()
            var ok = true
            for (j in 0 until 4) {
                val o = 12 * i + 3 * j
                val vx = corners[o] - b.px; val vy = corners[o + 1] - b.py; val vz = corners[o + 2] - b.pz
                val zc = vx * b.fx + vy * b.fy + vz * b.fz
                if (zc < near) { ok = false; break }
                sx[j] = cx + f * (vx * b.rx + vy * b.ry + vz * b.rz) / zc
                sy[j] = cy - f * (vx * b.ux + vy * b.uy + vz * b.uz) / zc
            }
            if (!ok) continue
            val minx = minOf(minOf(sx[0], sx[1]), minOf(sx[2], sx[3])); val maxx = maxOf(maxOf(sx[0], sx[1]), maxOf(sx[2], sx[3]))
            val miny = minOf(minOf(sy[0], sy[1]), minOf(sy[2], sy[3])); val maxy = maxOf(maxOf(sy[0], sy[1]), maxOf(sy[2], sy[3]))
            if (maxx < 0f || minx > w || maxy < 0f || miny > h) continue
            val col = mesh.colors[i]
            val d = mesh.dirs[i].toInt()
            val opaque = (col ushr 24) == 0xFF && d < 6
            val two = outline && opaque
            if (quads + 2 > CHUNK_QUADS) { flush(quads); quads = 0 }
            if (two) {
                val mx = (sx[0] + sx[1] + sx[2] + sx[3]) / 4f; val my = (sy[0] + sy[1] + sy[2] + sy[3]) / 4f
                putPos(quads, sx, sy, 1f, 0f, 0f)
                for (j in 0 until 4) { texs[quads * 8 + j * 2] = 8f; texs[quads * 8 + j * 2 + 1] = 8f; colors[quads * 4 + j] = 0xFF202020.toInt() }
                quads++
                putPos(quads, sx, sy, 0.88f, mx, my)
                System.arraycopy(mesh.uvs, i * 8, texs, quads * 8, 8)
                for (j in 0 until 4) colors[quads * 4 + j] = col
                quads++
            } else {
                putPos(quads, sx, sy, 1f, 0f, 0f)
                System.arraycopy(mesh.uvs, i * 8, texs, quads * 8, 8)
                for (j in 0 until 4) colors[quads * 4 + j] = col
                quads++
            }
            drawn++
        }
        if (quads > 0) flush(quads)
        return drawn
    }

    private fun putPos(q: Int, sx: FloatArray, sy: FloatArray, scale: Float, mx: Float, my: Float) {
        for (j in 0 until 4) {
            verts[q * 8 + j * 2] = if (scale == 1f) sx[j] else mx + (sx[j] - mx) * scale
            verts[q * 8 + j * 2 + 1] = if (scale == 1f) sy[j] else my + (sy[j] - my) * scale
        }
    }
}
