package com.bedrockbuilder.core

class Mesh(
    val count: Int,
    val corners: FloatArray,   // 12 floats per face (4 xyz corners)
    val centers: FloatArray,   // 3 floats per face
    val colors: IntArray,      // shaded ARGB per face
    val dirs: ByteArray,       // 0:+X 1:-X 2:+Y 3:-Y 4:+Z 5:-Z
)

object MeshBuilder {
    private val SHADE = floatArrayOf(0.80f, 0.68f, 1.0f, 0.50f, 0.88f, 0.60f)
    private val DX = intArrayOf(1, -1, 0, 0, 0, 0)
    private val DY = intArrayOf(0, 0, 1, -1, 0, 0)
    private val DZ = intArrayOf(0, 0, 0, 0, 1, -1)

    fun build(model: BuildModel, hideAbove: Boolean, layerY: Int): Mesh {
        val pal = model.palette
        val boxes = Array(pal.size) { BlockVisuals.boxes(pal[it]) }
        val base = IntArray(pal.size) { BlockVisuals.color(pal[it].name) }
        val trans = BooleanArray(pal.size) { BlockVisuals.isTranslucent(pal[it].name) }
        val occl = BooleanArray(pal.size) { BlockVisuals.occludes(pal[it]) }

        val corners = FloatBuf(1 shl 14); val centers = FloatBuf(1 shl 13)
        val colors = IntBuf(1 shl 12)
        var count = 0
        var dirArr = ByteArray(1 shl 12)

        for ((key, id) in model.blocks) {
            val x = BuildModel.kx(key); val y = BuildModel.ky(key); val z = BuildModel.kz(key)
            if (hideAbove && y > layerY) continue
            // neighbour culling info
            val cull = BooleanArray(6)
            for (d in 0 until 6) {
                val ny = y + DY[d]
                if (hideAbove && ny > layerY) continue
                val nid = model.blocks[BuildModel.key(x + DX[d], ny, z + DZ[d])] ?: continue
                cull[d] = occl[nid] || (trans[id] && nid == id)
            }
            val c0 = base[id]
            val alpha = if (trans[id]) 0xA0 else 0xFF
            for (b in boxes[id]) {
                val x0 = x + b[0]; val y0 = y + b[1]; val z0 = z + b[2]
                val x1 = x + b[3]; val y1 = y + b[4]; val z1 = z + b[5]
                for (d in 0 until 6) {
                    val onEdge = when (d) {
                        0 -> b[3] >= 0.9999f; 1 -> b[0] <= 0.0001f
                        2 -> b[4] >= 0.9999f; 3 -> b[1] <= 0.0001f
                        4 -> b[5] >= 0.9999f; else -> b[2] <= 0.0001f
                    }
                    if (onEdge && cull[d]) continue
                    when (d) {
                        0 -> quad(corners, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1)
                        1 -> quad(corners, x0, y0, z0, x0, y1, z0, x0, y1, z1, x0, y0, z1)
                        2 -> quad(corners, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1)
                        3 -> quad(corners, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1)
                        4 -> quad(corners, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1)
                        else -> quad(corners, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0)
                    }
                    val o = corners.size - 12
                    centers.add((corners.data[o] + corners.data[o + 6]) / 2f)
                    centers.add((corners.data[o + 1] + corners.data[o + 7]) / 2f)
                    centers.add((corners.data[o + 2] + corners.data[o + 8]) / 2f)
                    val s = SHADE[d]
                    val r = (((c0 shr 16) and 255) * s).toInt(); val g = (((c0 shr 8) and 255) * s).toInt(); val bl = ((c0 and 255) * s).toInt()
                    colors.add((alpha shl 24) or (r shl 16) or (g shl 8) or bl)
                    if (count == dirArr.size) dirArr = dirArr.copyOf(dirArr.size * 2)
                    dirArr[count] = d.toByte()
                    count++
                }
            }
        }
        return Mesh(count, corners.data, centers.data, colors.data, dirArr)
    }

    private fun quad(b: FloatBuf, a0: Float, a1: Float, a2: Float, b0: Float, b1: Float, b2: Float,
                     c0: Float, c1: Float, c2: Float, d0: Float, d1: Float, d2: Float) {
        b.add(a0); b.add(a1); b.add(a2); b.add(b0); b.add(b1); b.add(b2)
        b.add(c0); b.add(c1); b.add(c2); b.add(d0); b.add(d1); b.add(d2)
    }
}

/** Projects, depth-sorts (painter's algorithm) and batches mesh faces into quads for drawing. */
class FrameRenderer {
    companion object { const val CHUNK_QUADS = 8192 }

    val verts = FloatArray(CHUNK_QUADS * 8)
    val colors = IntArray(CHUNK_QUADS * 4)
    val indices = ShortArray(CHUNK_QUADS * 6).also {
        for (q in 0 until CHUNK_QUADS) {
            val v = q * 4; val i = q * 6
            it[i] = v.toShort(); it[i + 1] = (v + 1).toShort(); it[i + 2] = (v + 2).toShort()
            it[i + 3] = v.toShort(); it[i + 4] = (v + 2).toShort(); it[i + 5] = (v + 3).toShort()
        }
    }
    private var keys = LongArray(0)

    /** Calls flush(quadCount) whenever the verts/colors/indices arrays are full or at the end. Returns faces drawn. */
    fun render(mesh: Mesh, cam: Camera, w: Float, h: Float, outline: Boolean, flush: (Int) -> Unit): Int {
        val b = cam.basis()
        val f = Projection.focal(w, h)
        if (keys.size < mesh.count) keys = LongArray(mesh.count)
        var m = 0
        val c = mesh.centers
        for (i in 0 until mesh.count) {
            val vx = b.px - c[3 * i]; val vy = b.py - c[3 * i + 1]; val vz = b.pz - c[3 * i + 2]
            val facing = when (mesh.dirs[i].toInt()) {
                0 -> vx; 1 -> -vx; 2 -> vy; 3 -> -vy; 4 -> vz; else -> -vz
            }
            if (facing <= 0f) continue
            val d2 = vx * vx + vy * vy + vz * vz
            keys[m++] = ((Int.MAX_VALUE - d2.toRawBits()).toLong() shl 32) or i.toLong()
        }
        java.util.Arrays.sort(keys, 0, m)

        val cx = w / 2f; val cy = h / 2f
        val sx = FloatArray(4); val sy = FloatArray(4)
        var quads = 0
        var drawn = 0
        val corners = mesh.corners
        val near = 0.05f
        for (k in 0 until m) {
            val i = (keys[k] and 0xFFFFFFFFL).toInt()
            var ok = true
            for (j in 0 until 4) {
                val o = 12 * i + 3 * j
                val vx = corners[o] - b.px; val vy = corners[o + 1] - b.py; val vz = corners[o + 2] - b.pz
                val zc = vx * b.fx + vy * b.fy + vz * b.fz
                if (zc < near) { ok = false; break }
                sx[j] = cx + f * (vx * b.rx + vy * b.ry + vz * b.rz) / zc
                sy[j] = cy - f * (vx * b.ux + vy * b.uy + vz * b.uz) / zc
            }
            if (!ok) continue
            val minx = minOf(minOf(sx[0], sx[1]), minOf(sx[2], sx[3])); val maxx = maxOf(maxOf(sx[0], sx[1]), maxOf(sx[2], sx[3]))
            val miny = minOf(minOf(sy[0], sy[1]), minOf(sy[2], sy[3])); val maxy = maxOf(maxOf(sy[0], sy[1]), maxOf(sy[2], sy[3]))
            if (maxx < 0f || minx > w || maxy < 0f || miny > h) continue
            val col = mesh.colors[i]
            val opaque = (col ushr 24) == 0xFF
            val two = outline && opaque
            if (quads + 2 > CHUNK_QUADS) { flush(quads); quads = 0 }
            if (two) {
                val edge = darken(col)
                put(quads++, sx, sy, edge, 1f, 0f, 0f)
                val mx = (sx[0] + sx[1] + sx[2] + sx[3]) / 4f; val my = (sy[0] + sy[1] + sy[2] + sy[3]) / 4f
                put(quads++, sx, sy, col, 0.86f, mx, my)
            } else put(quads++, sx, sy, col, 1f, 0f, 0f)
            drawn++
        }
        if (quads > 0) flush(quads)
        return drawn
    }

    private fun put(q: Int, sx: FloatArray, sy: FloatArray, color: Int, scale: Float, mx: Float, my: Float) {
        for (j in 0 until 4) {
            val x = if (scale == 1f) sx[j] else mx + (sx[j] - mx) * scale
            val y = if (scale == 1f) sy[j] else my + (sy[j] - my) * scale
            verts[q * 8 + j * 2] = x; verts[q * 8 + j * 2 + 1] = y
            colors[q * 4 + j] = color
        }
    }

    private fun darken(c: Int): Int {
        val r = (((c shr 16) and 255) * 0.6f).toInt(); val g = (((c shr 8) and 255) * 0.6f).toInt(); val b = ((c and 255) * 0.6f).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }
}
