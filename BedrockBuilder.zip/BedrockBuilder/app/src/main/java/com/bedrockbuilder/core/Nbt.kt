package com.bedrockbuilder.core

import java.nio.charset.StandardCharsets

/** Little-endian NBT as used by Minecraft Bedrock Edition. */
class NbtException(message: String) : Exception(message)

sealed class Tag { abstract val typeId: Int }
data class ByteTag(val value: Byte) : Tag() { override val typeId = 1 }
data class ShortTag(val value: Short) : Tag() { override val typeId = 2 }
data class IntTag(val value: Int) : Tag() { override val typeId = 3 }
data class LongTag(val value: Long) : Tag() { override val typeId = 4 }
data class FloatTag(val value: Float) : Tag() { override val typeId = 5 }
data class DoubleTag(val value: Double) : Tag() { override val typeId = 6 }
class ByteArrayTag(val value: ByteArray) : Tag() { override val typeId = 7 }
data class StringTag(val value: String) : Tag() { override val typeId = 8 }
class ListTag(val elementType: Int, val items: List<Tag>) : Tag() { override val typeId = 9 }
/** A TAG_List of TAG_Int stored compactly (avoids millions of boxed tags). */
class IntListTag(val values: IntArray) : Tag() { override val typeId = 9 }
class CompoundTag(val map: LinkedHashMap<String, Tag> = LinkedHashMap()) : Tag() {
    override val typeId = 10
    operator fun get(key: String): Tag? = map[key]
    operator fun set(key: String, tag: Tag) { map[key] = tag }
    fun compound(key: String): CompoundTag? = map[key] as? CompoundTag
    fun list(key: String): Tag? = map[key]?.takeIf { it is ListTag || it is IntListTag }
    fun string(key: String): String? = (map[key] as? StringTag)?.value
    fun int(key: String): Int? = when (val t = map[key]) {
        is IntTag -> t.value
        is ShortTag -> t.value.toInt()
        is ByteTag -> t.value.toInt()
        is LongTag -> t.value.toInt()
        else -> null
    }
}
class IntArrayTag(val value: IntArray) : Tag() { override val typeId = 11 }
class LongArrayTag(val value: LongArray) : Tag() { override val typeId = 12 }

fun Tag?.intsOrNull(): IntArray? = when (this) {
    is IntListTag -> values
    is ListTag -> if (elementType == 3 || items.isEmpty()) IntArray(items.size) { (items[it] as IntTag).value } else null
    else -> null
}

fun Tag?.listItems(): List<Tag> = when (this) {
    is ListTag -> items
    is IntListTag -> values.map { IntTag(it) }
    else -> emptyList()
}

object Nbt {
    private const val MAX_DEPTH = 64

    fun readRoot(data: ByteArray, offset: Int = 0): CompoundTag {
        val r = Reader(data, offset)
        val type = r.u8()
        if (type != 10) throw NbtException("Not an NBT compound (first byte $type)")
        r.string()
        return r.compound(0)
    }

    fun writeRoot(root: CompoundTag, name: String = ""): ByteArray {
        val w = Writer()
        w.u8(10); w.string(name); w.compound(root)
        return w.toByteArray()
    }

    private class Reader(val b: ByteArray, var p: Int) {
        fun need(n: Int) { if (n < 0 || p + n > b.size) throw NbtException("Unexpected end of data") }
        fun u8(): Int { need(1); return b[p++].toInt() and 0xFF }
        fun u16(): Int { need(2); val v = (b[p].toInt() and 0xFF) or ((b[p + 1].toInt() and 0xFF) shl 8); p += 2; return v }
        fun i16(): Int = u16().toShort().toInt()
        fun i32(): Int {
            need(4)
            val v = (b[p].toInt() and 0xFF) or ((b[p + 1].toInt() and 0xFF) shl 8) or
                ((b[p + 2].toInt() and 0xFF) shl 16) or ((b[p + 3].toInt() and 0xFF) shl 24)
            p += 4
            return v
        }
        fun i64(): Long {
            val lo = i32().toLong() and 0xFFFFFFFFL
            val hi = i32().toLong()
            return lo or (hi shl 32)
        }
        fun string(): String {
            val n = u16(); need(n)
            val s = String(b, p, n, StandardCharsets.UTF_8); p += n; return s
        }
        fun compound(depth: Int): CompoundTag {
            if (depth > MAX_DEPTH) throw NbtException("NBT nesting too deep")
            val c = CompoundTag()
            while (true) {
                val t = u8()
                if (t == 0) break
                val name = string()
                c.map[name] = tag(t, depth + 1)
            }
            return c
        }
        fun tag(type: Int, depth: Int): Tag {
            if (depth > MAX_DEPTH) throw NbtException("NBT nesting too deep")
            return when (type) {
                1 -> ByteTag(u8().toByte())
                2 -> ShortTag(i16().toShort())
                3 -> IntTag(i32())
                4 -> LongTag(i64())
                5 -> FloatTag(Float.fromBits(i32()))
                6 -> DoubleTag(Double.fromBits(i64()))
                7 -> { val n = i32(); need(n); val a = b.copyOfRange(p, p + n); p += n; ByteArrayTag(a) }
                8 -> StringTag(string())
                9 -> list(depth)
                10 -> compound(depth)
                11 -> { val n = i32(); if (n < 0 || n > (b.size - p) / 4) throw NbtException("Bad int array"); IntArrayTag(IntArray(n) { i32() }) }
                12 -> { val n = i32(); if (n < 0 || n > (b.size - p) / 8) throw NbtException("Bad long array"); LongArrayTag(LongArray(n) { i64() }) }
                else -> throw NbtException("Unknown tag type $type")
            }
        }
        fun list(depth: Int): Tag {
            val et = u8()
            val n = i32()
            if (n <= 0) return ListTag(et, emptyList())
            if (et == 0) throw NbtException("Invalid list element type")
            if (n > b.size - p) throw NbtException("Bad list length")
            if (et == 3) return IntListTag(IntArray(n) { i32() })
            val items = ArrayList<Tag>(n)
            repeat(n) { items.add(tag(et, depth + 1)) }
            return ListTag(et, items)
        }
    }

    private class Writer {
        var buf = ByteArray(1 shl 16)
        var n = 0
        fun ensure(extra: Int) { if (n + extra > buf.size) buf = buf.copyOf(maxOf(buf.size * 2, n + extra)) }
        fun u8(v: Int) { ensure(1); buf[n++] = v.toByte() }
        fun i16(v: Int) { ensure(2); buf[n++] = v.toByte(); buf[n++] = (v shr 8).toByte() }
        fun i32(v: Int) {
            ensure(4)
            buf[n++] = v.toByte(); buf[n++] = (v shr 8).toByte(); buf[n++] = (v shr 16).toByte(); buf[n++] = (v shr 24).toByte()
        }
        fun i64(v: Long) { i32(v.toInt()); i32((v shr 32).toInt()) }
        fun string(s: String) {
            val bytes = s.toByteArray(StandardCharsets.UTF_8)
            if (bytes.size > 65535) throw NbtException("String too long")
            i16(bytes.size); ensure(bytes.size)
            System.arraycopy(bytes, 0, buf, n, bytes.size); n += bytes.size
        }
        fun compound(c: CompoundTag) {
            for ((k, v) in c.map) { u8(v.typeId); string(k); tag(v) }
            u8(0)
        }
        fun tag(t: Tag) {
            when (t) {
                is ByteTag -> u8(t.value.toInt())
                is ShortTag -> i16(t.value.toInt())
                is IntTag -> i32(t.value)
                is LongTag -> i64(t.value)
                is FloatTag -> i32(t.value.toRawBits())
                is DoubleTag -> i64(t.value.toRawBits())
                is ByteArrayTag -> { i32(t.value.size); ensure(t.value.size); System.arraycopy(t.value, 0, buf, n, t.value.size); n += t.value.size }
                is StringTag -> string(t.value)
                is ListTag -> { u8(t.elementType); i32(t.items.size); for (i in t.items) tag(i) }
                is IntListTag -> { u8(3); i32(t.values.size); ensure(t.values.size * 4); for (v in t.values) i32(v) }
                is CompoundTag -> compound(t)
                is IntArrayTag -> { i32(t.value.size); for (v in t.value) i32(v) }
                is LongArrayTag -> { i32(t.value.size); for (v in t.value) i64(v) }
            }
        }
        fun toByteArray(): ByteArray = buf.copyOf(n)
    }
}
