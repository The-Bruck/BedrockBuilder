package com.bedrockbuilder.core

class StateHint(val key: String, val label: String, val options: List<Pair<String, Any>>)

/** Helpful quick-pick block states (rotation, half, axis...) for common block families. */
object StateHints {
    private val OFF_ON = listOf("Off" to (false as Any), "On" to (true as Any))
    private fun ints(vararg p: Pair<String, Int>): List<Pair<String, Any>> = p.map { it.first to (it.second as Any) }
    private fun strs(vararg s: String): List<Pair<String, Any>> = s.map { it to (it as Any) }
    private val N4 = ints("0" to 0, "1" to 1, "2" to 2, "3" to 3)
    private val FACING6 = ints("Down" to 0, "Up" to 1, "North" to 2, "South" to 3, "West" to 4, "East" to 5)
    private val FACING4 = ints("North" to 2, "South" to 3, "West" to 4, "East" to 5)
    private val AXIS_BLOCKS = listOf("hay_block", "bone_block", "basalt", "polished_basalt", "purpur_pillar",
        "quartz_pillar", "bamboo_block", "chain", "deepslate", "muddy_mangrove_roots")

    fun forBlock(name: String): List<StateHint> {
        val n = name.substringAfter(':')
        val out = ArrayList<StateHint>()
        when {
            n.endsWith("_stairs") -> {
                out += StateHint("weirdo_direction", "Facing", ints("East" to 0, "West" to 1, "South" to 2, "North" to 3))
                out += StateHint("upside_down_bit", "Upside down", OFF_ON)
            }
            n.endsWith("_slab") && !n.contains("double") ->
                out += StateHint("minecraft:vertical_half", "Half", strs("bottom", "top"))
            n.endsWith("_door") -> {
                out += StateHint("direction", "Direction", N4)
                out += StateHint("door_hinge_bit", "Hinge right", OFF_ON)
                out += StateHint("open_bit", "Open", OFF_ON)
                out += StateHint("upper_block_bit", "Upper half", OFF_ON)
            }
            n.endsWith("trapdoor") -> {
                out += StateHint("direction", "Direction", N4)
                out += StateHint("open_bit", "Open", OFF_ON)
                out += StateHint("upside_down_bit", "Top half", OFF_ON)
            }
            n.endsWith("fence_gate") -> {
                out += StateHint("direction", "Direction", N4)
                out += StateHint("open_bit", "Open", OFF_ON)
                out += StateHint("in_wall_bit", "In wall", OFF_ON)
            }
            n.endsWith("_log") || n.endsWith("_wood") || n.endsWith("_stem") || n.endsWith("_hyphae") ||
                n in AXIS_BLOCKS ->
                out += StateHint("pillar_axis", "Axis", strs("y", "x", "z"))
            n.endsWith("glazed_terracotta") || n == "chest" || n == "trapped_chest" || n == "ender_chest" ||
                n == "furnace" || n == "lit_furnace" || n == "blast_furnace" || n == "smoker" || n == "ladder" ->
                out += StateHint("facing_direction", "Facing", FACING4)
            n == "piston" || n == "sticky_piston" || n == "observer" || n == "dispenser" || n == "dropper" ||
                n == "hopper" || n == "end_rod" || n == "barrel" || n == "lightning_rod" ->
                out += StateHint("facing_direction", "Facing", FACING6)
            n.endsWith("_button") -> out += StateHint("facing_direction", "Facing", FACING6)
            n == "carved_pumpkin" || n == "lit_pumpkin" ->
                out += StateHint("minecraft:cardinal_direction", "Facing", strs("south", "west", "north", "east"))
            n.endsWith("torch") ->
                out += StateHint("torch_facing_direction", "Attached", strs("top", "west", "east", "north", "south"))
            n == "snow_layer" -> out += StateHint("height", "Height", ints("1" to 0, "2" to 1, "3" to 2, "4" to 3, "5" to 4, "6" to 5, "7" to 6, "8" to 7))
            n == "water" || n == "lava" -> out += StateHint("liquid_depth", "Depth", ints("Source" to 0, "1" to 1, "2" to 2, "3" to 3, "4" to 4, "5" to 5, "6" to 6, "7" to 7))
            n.endsWith("_leaves") -> out += StateHint("persistent_bit", "Persistent", OFF_ON)
            n.endsWith("_candle") || n == "candle" -> {
                out += StateHint("candles", "Count", ints("1" to 0, "2" to 1, "3" to 2, "4" to 3))
                out += StateHint("lit", "Lit", OFF_ON)
            }
            n == "lantern" || n == "soul_lantern" -> out += StateHint("hanging", "Hanging", OFF_ON)
        }
        return out
    }
}
