package com.bedrockbuilder.core

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

enum class Op(val label: String) { PLACE("Place"), DESTROY("Destroy"), REPLACE("Replace"), ROTATE("Rotate"), PICK("Pick") }

enum class ShapeKind(val label: String, val twoPoints: Boolean, val hollowable: Boolean) {
    SINGLE("Single", false, false),
    BOX("Box", true, true),
    SPHERE("Sphere", true, true),
    DOME("Dome", true, true),
    CYLINDER("Cylinder", true, true),
    PYRAMID("Pyramid", true, true),
    LINE("Line", true, false),
    FLOOD("Flood fill", false, false),
}

object Shapes {
    const val MAX_SCAN = 16_000_000L
    const val MAX_CELLS = 3_000_000
    const val MAX_RADIUS = 120

    /** Generates the cell keys for a shape defined by points a and b. Throws IllegalArgumentException if too large. */
    fun generate(kind: ShapeKind, a: IntArray, b: IntArray, hollow: Boolean, out: LongBuf) {
        val x0 = min(a[0], b[0]); val x1 = max(a[0], b[0])
        val y0 = min(a[1], b[1]); val y1 = max(a[1], b[1])
        val z0 = min(a[2], b[2]); val z1 = max(a[2], b[2])
        when (kind) {
            ShapeKind.SINGLE, ShapeKind.FLOOD -> out.add(BuildModel.key(a[0], a[1], a[2]))
            ShapeKind.BOX -> scan(x0, y0, z0, x1, y1, z1, hollow, out,
                { x, y, z -> x in x0..x1 && y in y0..y1 && z in z0..z1 }, { _, _, _ -> true })
            ShapeKind.SPHERE, ShapeKind.DOME -> {
                val r = radius3(a, b)
                val lim = (r + 0.5) * (r + 0.5)
                val cx = a[0]; val cy = a[1]; val cz = a[2]
                val inside = { x: Int, y: Int, z: Int ->
                    val dx = (x - cx).toDouble(); val dy = (y - cy).toDouble(); val dz = (z - cz).toDouble()
                    dx * dx + dy * dy + dz * dz <= lim
                }
                val dome = kind == ShapeKind.DOME
                scan(cx - r, if (dome) cy else cy - r, cz - r, cx + r, cy + r, cz + r, hollow, out,
                    inside, { _, y, _ -> !dome || y >= cy })
            }
            ShapeKind.CYLINDER -> {
                val dx = (a[0] - b[0]).toDouble(); val dz = (a[2] - b[2]).toDouble()
                val r = min(MAX_RADIUS, sqrt(dx * dx + dz * dz).roundToInt())
                val lim = (r + 0.5) * (r + 0.5)
                val cx = a[0]; val cz = a[2]
                scan(cx - r, y0, cz - r, cx + r, y1, cz + r, hollow, out,
                    { x, y, z ->
                        val ddx = (x - cx).toDouble(); val ddz = (z - cz).toDouble()
                        y in y0..y1 && ddx * ddx + ddz * ddz <= lim
                    }, { _, _, _ -> true })
            }
            ShapeKind.PYRAMID -> {
                val h = y1 - y0 + 1
                val maxInset = (min(x1 - x0, z1 - z0)) / 2
                scan(x0, y0, z0, x1, y1, z1, hollow, out,
                    { x, y, z ->
                        if (y < y0 || y > y1) false else {
                            val ins = if (h <= 1) 0 else (y - y0) * maxInset / (h - 1)
                            x >= x0 + ins && x <= x1 - ins && z >= z0 + ins && z <= z1 - ins
                        }
                    }, { _, _, _ -> true })
            }
            ShapeKind.LINE -> {
                val n = max(abs(b[0] - a[0]), max(abs(b[1] - a[1]), abs(b[2] - a[2])))
                require(n < MAX_CELLS) { "Line is too long" }
                for (i in 0..n) {
                    val t = if (n == 0) 0.0 else i.toDouble() / n
                    out.add(BuildModel.key(
                        a[0] + ((b[0] - a[0]) * t).roundToInt(),
                        a[1] + ((b[1] - a[1]) * t).roundToInt(),
                        a[2] + ((b[2] - a[2]) * t).roundToInt()))
                }
            }
        }
    }

    private fun radius3(a: IntArray, b: IntArray): Int {
        val dx = (a[0] - b[0]).toDouble(); val dy = (a[1] - b[1]).toDouble(); val dz = (a[2] - b[2]).toDouble()
        return min(MAX_RADIUS, sqrt(dx * dx + dy * dy + dz * dz).roundToInt())
    }

    private inline fun scan(
        x0: Int, y0: Int, z0: Int, x1: Int, y1: Int, z1: Int, hollow: Boolean, out: LongBuf,
        inside: (Int, Int, Int) -> Boolean, clip: (Int, Int, Int) -> Boolean,
    ) {
        val vol = (x1 - x0 + 1).toLong() * (y1 - y0 + 1) * (z1 - z0 + 1)
        require(vol <= MAX_SCAN) { "Shape is too large" }
        for (x in x0..x1) for (y in y0..y1) for (z in z0..z1) {
            if (!inside(x, y, z) || !clip(x, y, z)) continue
            if (hollow && inside(x + 1, y, z) && inside(x - 1, y, z) && inside(x, y + 1, z) &&
                inside(x, y - 1, z) && inside(x, y, z + 1) && inside(x, y, z - 1)) continue
            out.add(BuildModel.key(x, y, z))
            require(out.size <= MAX_CELLS) { "Shape is too large" }
        }
    }
}
