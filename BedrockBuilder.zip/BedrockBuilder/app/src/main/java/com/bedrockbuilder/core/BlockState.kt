package com.bedrockbuilder.core

/** Block data version written to exported structures (1.21.0.3). Older files keep their own versions. */
const val BLOCK_VERSION = 18153475

data class BlockState(
    val name: String,
    val states: Map<String, Any> = emptyMap(),
    val version: Int = BLOCK_VERSION,
) {
    val shortName: String get() = name.substringAfter(':')

    fun withState(key: String, value: Any?): BlockState {
        val m = LinkedHashMap(states)
        if (value == null) m.remove(key) else m[key] = value
        return copy(states = m)
    }

    fun statesText(): String = states.entries.sortedBy { it.key }.joinToString(",") { "${it.key}=${it.value}" }

    fun serialize(): String = "$name|${statesText()}"

    companion object {
        val AIR = BlockState("minecraft:air")
        private val NAME_RE = Regex("^[a-z0-9_.\\-]+:[a-z0-9_./\\-]+$")
        private val INT_RE = Regex("^-?\\d{1,9}$")

        fun normalizeName(raw: String): String {
            val s = raw.trim().lowercase().replace(' ', '_')
            return if (':' in s) s else "minecraft:$s"
        }

        fun isValidName(n: String) = NAME_RE.matches(n)

        fun parseValue(raw: String): Any {
            val s = raw.trim()
            if (s.length >= 2 && s.startsWith("\"") && s.endsWith("\"")) return s.substring(1, s.length - 1)
            if (s.equals("true", true)) return true
            if (s.equals("false", true)) return false
            if (INT_RE.matches(s)) return s.toInt()
            return s
        }

        /** "key=value, key2=value2" -> map, or null if malformed. */
        fun parseStates(text: String): Map<String, Any>? {
            if (text.isBlank()) return emptyMap()
            val m = LinkedHashMap<String, Any>()
            for (part in text.split(',')) {
                if (part.isBlank()) continue
                val i = part.indexOf('=')
                if (i <= 0) return null
                val k = part.substring(0, i).trim()
                val v = part.substring(i + 1).trim()
                if (k.isEmpty() || v.isEmpty()) return null
                m[k] = parseValue(v)
            }
            return m
        }

        fun deserialize(s: String): BlockState? {
            val i = s.indexOf('|')
            val name = if (i < 0) s else s.substring(0, i)
            if (!isValidName(name)) return null
            val states = if (i < 0) emptyMap() else (parseStates(s.substring(i + 1)) ?: return null)
            return BlockState(name, states)
        }
    }
}
