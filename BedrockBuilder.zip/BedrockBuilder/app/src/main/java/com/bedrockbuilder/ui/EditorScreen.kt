package com.bedrockbuilder.ui

import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.bedrockbuilder.core.BuildModel
import com.bedrockbuilder.core.Op
import com.bedrockbuilder.core.ShapeKind
import com.bedrockbuilder.data.HudElement
import java.io.File

fun shareStructureFile(context: Context, file: File) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "application/octet-stream"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(send, "Share ${file.name}"))
}

private val OP_HELP = mapOf(
    Op.PLACE to "Tap to add blocks onto the tapped face.",
    Op.DESTROY to "Tap to remove blocks.",
    Op.REPLACE to "Swap existing blocks only; empty cells stay empty.",
    Op.ROTATE to "Turn the facing of stairs, logs, doors, chests and similar blocks by 90°.",
    Op.PICK to "Tap a block to copy it into the selected hotbar slot.",
)

private val DOCK_TABS = listOf("Tool", "Shape", "Blocks", "View")

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EditorScreen(vm: EditorViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var menuOpen by remember { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }
    var showStructure by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var showPalette by remember { mutableStateOf(false) }
    var showPaletteAdd by remember { mutableStateOf(false) }
    var showPacks by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri -> if (uri != null) vm.exportTo(uri) }

    val packLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importPack(uri)
    }

    LaunchedEffect(vm.message) {
        vm.message?.let { snackbar.showSnackbar(it); vm.message = null }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (vm.hud) TopAppBar(
                title = {
                    Column {
                        Text(vm.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                        if (vm.loaded) Text("${vm.model.sizeX}×${vm.model.sizeY}×${vm.model.sizeZ} · ${vm.model.blockCount} blocks",
                            style = MaterialTheme.typography.bodySmall)
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    TextButton(onClick = { vm.undo() }, enabled = vm.canUndo) { Text("↶", style = MaterialTheme.typography.titleLarge) }
                    TextButton(onClick = { vm.redo() }, enabled = vm.canRedo) { Text("↷", style = MaterialTheme.typography.titleLarge) }
                    TextButton(onClick = { vm.hud = false }) { Text("Hide UI") }
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("Save") }, onClick = { menuOpen = false; vm.manualSave() })
                            DropdownMenuItem(text = { Text("Export .mcstructure") }, onClick = {
                                menuOpen = false; vm.saveNow(); exportLauncher.launch("${vm.name}.mcstructure")
                            })
                            DropdownMenuItem(text = { Text("Share…") }, onClick = {
                                menuOpen = false; vm.shareFile { shareStructureFile(context, it) }
                            })
                            HorizontalDivider()
                            DropdownMenuItem(text = { Text("Structure settings…") }, onClick = { menuOpen = false; showStructure = true })
                            DropdownMenuItem(text = { Text("Rotate structure ↻ 90°") }, onClick = { menuOpen = false; vm.rotateStructure(true) })
                            DropdownMenuItem(text = { Text("Rotate structure ↺ 90°") }, onClick = { menuOpen = false; vm.rotateStructure(false) })
                            DropdownMenuItem(text = { Text("Clear all blocks") }, onClick = { menuOpen = false; confirmClear = true })
                            HorizontalDivider()
                            DropdownMenuItem(text = { Text("Packs (.mcpack / .mcaddon)…") }, onClick = { menuOpen = false; showPacks = true })
                            DropdownMenuItem(text = { Text("Customize UI layout…") }, onClick = { menuOpen = false; vm.hudEdit = true })
                            DropdownMenuItem(text = { Text("Settings…") }, onClick = { menuOpen = false; showSettings = true })
                        }
                    }
                },
            )
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (vm.loadError != null) {
                Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Could not open this structure", style = MaterialTheme.typography.titleMedium)
                    Text(vm.loadError ?: "", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(12.dp)); Button(onClick = onBack) { Text("Back") }
                }
            } else if (!vm.loaded) {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            } else {
                BuildCanvas(vm)

                if (!vm.hud) {
                    Surface(
                        Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp).clickable { vm.hud = true },
                        shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.secondaryContainer, tonalElevation = 4.dp,
                    ) { Text("Show UI", Modifier.padding(horizontal = 14.dp, vertical = 8.dp), style = MaterialTheme.typography.labelLarge) }
                } else {
                    // hint line
                    val hint = when {
                        vm.op == Op.PICK -> "Tap a block to pick its type"
                        vm.op == Op.ROTATE && !vm.shape.twoPoints -> "Tap a block to rotate it ${if (vm.rotateCcw) "↺" else "↻"}"
                        vm.anchor != null -> "Tap the second point (${vm.shape.label.lowercase()})"
                        vm.shape.twoPoints -> "Tap the first point (${vm.shape.label.lowercase()})"
                        else -> null
                    }
                    if (hint != null) Surface(
                        Modifier.align(Alignment.TopCenter).padding(8.dp), shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                    ) {
                        Row(Modifier.padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(hint, style = MaterialTheme.typography.labelLarge)
                            if (vm.anchor != null) TextButton(onClick = { vm.cancelAnchor() }) { Text("Cancel") }
                        }
                    }

                    // compact layer stepper (the layer plane is where new blocks land)
                    HudBox(vm, HudElement.LAYER, Modifier.align(Alignment.CenterEnd).padding(end = 8.dp, bottom = 120.dp)) {
                        Surface(shape = RoundedCornerShape(16.dp), tonalElevation = 4.dp) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(2.dp)) {
                                TextButton(onClick = { vm.setLayer(vm.layerY + 1) }) { Text("▲") }
                                Text("Y ${vm.layerY - vm.model.minY}", style = MaterialTheme.typography.labelLarge)
                                TextButton(onClick = { vm.setLayer(vm.layerY - 1) }) { Text("▼") }
                            }
                        }
                    }

                    Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        HudBox(vm, HudElement.HOTBAR, Modifier.padding(bottom = 4.dp)) {
                            Hotbar(vm, onEditSlot = { showPicker = true })
                        }
                        HudBox(vm, HudElement.DOCK, Modifier.fillMaxWidth()) {
                            Dock(
                                vm, Modifier,
                                onPickBlock = { showPicker = true }, onPalette = { showPalette = true },
                                onPacks = { showPacks = true }, onStructure = { showStructure = true },
                            )
                        }
                    }

                    if (vm.hudEdit) HudEditPanel(vm, Modifier.align(Alignment.TopCenter).padding(top = 56.dp, start = 12.dp, end = 12.dp))
                }
            }
        }
    }

    if (showPicker) BlockPickerSheet(vm, onImportPack = { packLauncher.launch(arrayOf("*/*")) }, onDismiss = { showPicker = false })
    if (showPalette) PaletteSheet(vm, onAddBlocks = { showPaletteAdd = true }, onDismiss = { showPalette = false })
    if (showPaletteAdd) BlockPickerSheet(vm, addToPalette = true, onDismiss = { showPaletteAdd = false })
    if (showPacks) PacksDialog(vm, onImport = { packLauncher.launch(arrayOf("*/*")) }, onDismiss = { showPacks = false })
    if (showStructure) StructureDialog(vm, onDismiss = { showStructure = false })
    if (showSettings) SettingsDialog(vm, onCustomizeUi = { showSettings = false; vm.hudEdit = true }, onDismiss = { showSettings = false })
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Clear all blocks?") },
        text = { Text("You can undo this.") },
        confirmButton = { TextButton(onClick = { confirmClear = false; vm.clearAll() }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
    )
}

/** Bottom dock: always-visible hotbar, then four category tabs (Tool / Shape / Blocks / View) that share one panel. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Dock(vm: EditorViewModel, modifier: Modifier, onPickBlock: () -> Unit, onPalette: () -> Unit,
                 onPacks: () -> Unit, onStructure: () -> Unit) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp), tonalElevation = 6.dp) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                DOCK_TABS.forEachIndexed { i, label ->
                    val selected = vm.dockOpen && vm.dockTab == i
                    Surface(
                        Modifier.clickable { if (selected) vm.dockOpen = false else { vm.dockTab = i; vm.dockOpen = true } },
                        shape = RoundedCornerShape(14.dp),
                        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                    ) { Text(label, Modifier.padding(horizontal = 12.dp, vertical = 6.dp), style = MaterialTheme.typography.labelLarge) }
                }
                Spacer(Modifier.weight(1f))
                val status = buildString {
                    append(vm.op.label)
                    if (vm.op != Op.PICK) append(" · ").append(vm.shape.label)
                    if (vm.hollow && vm.shape.hollowable && vm.op != Op.ROTATE) append(" (hollow)")
                    if (vm.paletteMode && (vm.op == Op.PLACE || vm.op == Op.REPLACE)) append(" · palette")
                    if (vm.locked) append(" · locked")
                }
                Text(status, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }

            if (vm.dockOpen) when (vm.dockTab) {
                0 -> ToolPanel(vm)
                1 -> ShapePanel(vm)
                2 -> BlocksPanel(vm, onPickBlock, onPalette, onPacks)
                else -> ViewPanel(vm, onStructure)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ToolPanel(vm: EditorViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Op.values().forEach { o ->
                FilterChip(selected = vm.op == o, onClick = { vm.selectOp(o) }, label = { Text(o.label) })
            }
        }
        if (vm.op == Op.ROTATE) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = !vm.rotateCcw, onClick = { vm.rotateCcw = false }, label = { Text("↻ Clockwise") })
            FilterChip(selected = vm.rotateCcw, onClick = { vm.rotateCcw = true }, label = { Text("↺ Counter-clockwise") })
        }
        Text(OP_HELP[vm.op] ?: "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ShapePanel(vm: EditorViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ShapeKind.values().forEach { s ->
                FilterChip(selected = vm.shape == s, onClick = { vm.selectShape(s) }, label = { Text(s.label) })
            }
            FilterChip(
                selected = vm.hollow && vm.shape.hollowable, enabled = vm.shape.hollowable && vm.op != Op.ROTATE,
                onClick = { vm.hollow = !vm.hollow }, label = { Text("Hollow") },
            )
        }
        Text(
            if (vm.shape.twoPoints) "Tap the first point, then the second. Sphere/dome radius = distance; cylinder = radius + height."
            else if (vm.shape == ShapeKind.FLOOD) "Tap a block (or empty space) to fill the connected region."
            else "One block per tap. Turn on Lock to drag-paint.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun BlocksPanel(vm: EditorViewModel, onPickBlock: () -> Unit, onPalette: () -> Unit, onPacks: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onPickBlock, modifier = Modifier.weight(1f)) {
                BlockIcon(vm.textures, vm.current.name, 20)
                Spacer(Modifier.width(8.dp))
                Text("Slot ${vm.slot + 1}: ${vm.current.shortName}", maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            OutlinedButton(onClick = onPacks) { Text("Packs") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = vm.paletteMode, onCheckedChange = {
                vm.paletteMode = it
                if (it && vm.palette.isEmpty()) onPalette()
            })
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("Random palette", style = MaterialTheme.typography.labelLarge)
                Text("${vm.palette.size} blocks" + if (vm.textures?.packBlocks?.isNotEmpty() == true) " · ${vm.textures?.packBlocks?.size} pack blocks" else "",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onPalette) { Text("Edit palette") }
        }
        if (vm.palette.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            vm.palette.forEach { BlockIcon(vm.textures, it.block.name, 20) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ViewPanel(vm: EditorViewModel, onStructure: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            listOf(
                "Isometric" to (35f to 30f), "Top" to (0f to 89f), "Front" to (0f to 0f),
                "Back" to (180f to 0f), "Left" to (-90f to 0f), "Right" to (90f to 0f),
            ).forEach { (label, v) ->
                AssistChip(onClick = { vm.setView(v.first, v.second) }, label = { Text(label) })
            }
            AssistChip(onClick = { vm.fitView() }, label = { Text("Fit") })
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { vm.zoomBy(1 / 1.3f) }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("−") }
            OutlinedButton(onClick = { vm.zoomBy(1.3f) }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("+") }
            FilterChip(
                selected = vm.locked, onClick = { vm.locked = !vm.locked },
                label = { Text("Lock view") }, leadingIcon = { Icon(Icons.Default.Lock, null, Modifier.size(16.dp)) },
            )
            FilterChip(selected = vm.hideAbove, onClick = { vm.hideAbove = !vm.hideAbove }, label = { Text("Slice") })
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onStructure) { Text("Structure…") }
        }
        Text(
            if (vm.locked) "View locked: drag to paint with Single, pinch to zoom." else "Drag to rotate · pinch to zoom · two fingers to pan. Slice hides blocks above the layer.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
