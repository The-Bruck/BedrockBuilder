package com.bedrockbuilder.ui

import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.bedrockbuilder.core.BuildModel
import com.bedrockbuilder.core.Op
import com.bedrockbuilder.core.ShapeKind
import java.io.File

fun shareStructureFile(context: Context, file: File) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "application/octet-stream"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(send, "Share ${file.name}"))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: EditorViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var menuOpen by remember { mutableStateOf(false) }
    var viewMenu by remember { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }
    var showGrid by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri -> if (uri != null) vm.exportTo(uri) }

    LaunchedEffect(vm.message) {
        vm.message?.let { snackbar.showSnackbar(it); vm.message = null }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(vm.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                        if (vm.loaded) Text("${vm.model.sizeX}×${vm.model.sizeY}×${vm.model.sizeZ} · ${vm.model.blockCount} blocks",
                            style = MaterialTheme.typography.bodySmall)
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    TextButton(onClick = { vm.undo() }, enabled = vm.canUndo) { Text("↶", style = MaterialTheme.typography.titleLarge) }
                    TextButton(onClick = { vm.redo() }, enabled = vm.canRedo) { Text("↷", style = MaterialTheme.typography.titleLarge) }
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("Save") }, onClick = { menuOpen = false; vm.manualSave() })
                            DropdownMenuItem(text = { Text("Export .mcstructure") }, onClick = {
                                menuOpen = false; vm.saveNow(); exportLauncher.launch("${vm.name}.mcstructure")
                            })
                            DropdownMenuItem(text = { Text("Share…") }, onClick = {
                                menuOpen = false; vm.shareFile { shareStructureFile(context, it) }
                            })
                            DropdownMenuItem(text = { Text("Grid size…") }, onClick = { menuOpen = false; showGrid = true })
                            DropdownMenuItem(text = { Text("Settings…") }, onClick = { menuOpen = false; showSettings = true })
                            DropdownMenuItem(text = { Text("Clear all blocks") }, onClick = { menuOpen = false; confirmClear = true })
                        }
                    }
                },
            )
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (vm.loadError != null) {
                Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Could not open this structure", style = MaterialTheme.typography.titleMedium)
                    Text(vm.loadError ?: "", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(12.dp)); Button(onClick = onBack) { Text("Back") }
                }
            } else if (!vm.loaded) {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            } else {
                BuildCanvas(vm)

                // hint line
                val hint = when {
                    vm.op == Op.PICK -> "Tap a block to pick its type"
                    vm.anchor != null -> "Tap the second point (${vm.shape.label.lowercase()})"
                    vm.shape.twoPoints -> "Tap the first point (${vm.shape.label.lowercase()})"
                    else -> null
                }
                if (hint != null) Surface(
                    Modifier.align(Alignment.TopCenter).padding(8.dp), shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer,
                ) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(hint, style = MaterialTheme.typography.labelLarge)
                        if (vm.anchor != null) TextButton(onClick = { vm.cancelAnchor() }) { Text("Cancel") }
                    }
                }

                // layer control
                Surface(
                    Modifier.align(Alignment.CenterEnd).padding(end = 8.dp, bottom = 120.dp),
                    shape = RoundedCornerShape(16.dp), tonalElevation = 4.dp,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(4.dp)) {
                        TextButton(onClick = { vm.setLayer(vm.layerY + 1) }) { Text("▲") }
                        Text("Y ${vm.layerY - vm.model.minY}", style = MaterialTheme.typography.labelLarge)
                        TextButton(onClick = { vm.setLayer(vm.layerY - 1) }) { Text("▼") }
                        FilterChip(selected = vm.hideAbove, onClick = { vm.hideAbove = !vm.hideAbove }, label = { Text("Slice") })
                    }
                }

                // bottom tools
                Surface(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp), tonalElevation = 6.dp,
                ) {
                    Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Op.values().forEach { o ->
                                FilterChip(selected = vm.op == o, onClick = { vm.selectOp(o) }, label = { Text(o.label) })
                            }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            ShapeKind.values().forEach { s ->
                                FilterChip(selected = vm.shape == s, onClick = { vm.selectShape(s) }, label = { Text(s.label) })
                            }
                            FilterChip(
                                selected = vm.hollow && vm.shape.hollowable, enabled = vm.shape.hollowable,
                                onClick = { vm.hollow = !vm.hollow }, label = { Text("Hollow") },
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.weight(1f)) {
                                BlockSwatch(vm.current.name, 20)
                                Spacer(Modifier.width(8.dp))
                                Text(vm.current.shortName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            TextButton(onClick = { vm.zoomBy(1 / 1.3f) }) { Text("−", style = MaterialTheme.typography.titleLarge) }
                            TextButton(onClick = { vm.zoomBy(1.3f) }) { Text("+", style = MaterialTheme.typography.titleLarge) }
                            FilterChip(
                                selected = vm.locked, onClick = { vm.locked = !vm.locked },
                                label = { Text("Lock") }, leadingIcon = { Icon(Icons.Default.Lock, null, Modifier.size(16.dp)) },
                            )
                            Box {
                                TextButton(onClick = { viewMenu = true }) { Text("View") }
                                DropdownMenu(expanded = viewMenu, onDismissRequest = { viewMenu = false }) {
                                    listOf(
                                        "Isometric" to (35f to 30f), "Top" to (0f to 89f), "Front (north)" to (0f to 0f),
                                        "Back (south)" to (180f to 0f), "Left (west)" to (-90f to 0f), "Right (east)" to (90f to 0f),
                                    ).forEach { (label, v) ->
                                        DropdownMenuItem(text = { Text(label) }, onClick = { viewMenu = false; vm.setView(v.first, v.second) })
                                    }
                                    DropdownMenuItem(text = { Text("Fit to structure") }, onClick = { viewMenu = false; vm.fitView() })
                                }
                            }
                        }
                        if (vm.locked) Text(
                            "View locked: drag to paint with Single, pinch to zoom.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }

    if (showPicker) BlockPickerSheet(vm, onDismiss = { showPicker = false })
    if (showGrid) GridDialog(vm, onDismiss = { showGrid = false })
    if (showSettings) SettingsDialog(vm, onDismiss = { showSettings = false })
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Clear all blocks?") },
        text = { Text("You can undo this.") },
        confirmButton = { TextButton(onClick = { confirmClear = false; vm.clearAll() }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
    )
}

@Composable
private fun GridDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val m = vm.model
    var sx by remember { mutableStateOf(m.sizeX.toString()) }
    var sy by remember { mutableStateOf(m.sizeY.toString()) }
    var sz by remember { mutableStateOf(m.sizeZ.toString()) }
    // re-read size after +/- presses
    val rev = vm.revision
    LaunchedEffect(rev) { sx = m.sizeX.toString(); sy = m.sizeY.toString(); sz = m.sizeZ.toString() }

    @Composable
    fun sideRow(label: String, axis: Int, high: Boolean) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f))
            OutlinedButton(onClick = { vm.resizeSide(axis, high, -1) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("−1") }
            Spacer(Modifier.width(6.dp))
            Button(onClick = { vm.resizeSide(axis, high, 1) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("+1") }
            Spacer(Modifier.width(6.dp))
            Button(onClick = { vm.resizeSide(axis, high, 8) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("+8") }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Grid size  ${m.sizeX}×${m.sizeY}×${m.sizeZ}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                Text("Grow or shrink each side. Shrinking never removes blocks. Max ${BuildModel.MAX_AXIS} per axis.",
                    style = MaterialTheme.typography.bodySmall)
                sideRow("West  (−X)", 0, false); sideRow("East  (+X)", 0, true)
                sideRow("Down  (−Y)", 1, false); sideRow("Up  (+Y)", 1, true)
                sideRow("North (−Z)", 2, false); sideRow("South (+Z)", 2, true)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(Triple("X", sx, { v: String -> sx = v }), Triple("Y", sy, { v: String -> sy = v }), Triple("Z", sz, { v: String -> sz = v }))
                        .forEach { (l, v, set) ->
                            OutlinedTextField(v, { set(it.filter(Char::isDigit).take(3)) }, Modifier.width(88.dp), singleLine = true,
                                label = { Text(l) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.setGridSize(sx.toIntOrNull() ?: 1, sy.toIntOrNull() ?: 1, sz.toIntOrNull() ?: 1) }) { Text("Apply size") }
                    OutlinedButton(onClick = { vm.fitGridToBlocks() }) { Text("Fit to blocks") }
                }
                if (m.sizeX > 64 || m.sizeY > 64 || m.sizeZ > 64)
                    Text("Note: in-game structure blocks only handle up to 64 per axis.", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.tertiary)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

@Composable
private fun SettingsDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Settings") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SettingRow("Auto-expand grid", "Growing the grid when you build outside it", vm.autoExpand) { vm.setAutoExpand(it) }
                SettingRow("Block outlines", "Draw edges on blocks when zoomed in", vm.showOutlines) { vm.setShowOutlines(it) }
                SettingRow("Empty cells as air", "On: loading the structure clears existing blocks in its area. Off: keeps them.",
                    vm.emptyAsAir) { vm.setEmptyAsAir(it) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

@Composable
private fun SettingRow(title: String, sub: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = value, onCheckedChange = onChange)
    }
}
