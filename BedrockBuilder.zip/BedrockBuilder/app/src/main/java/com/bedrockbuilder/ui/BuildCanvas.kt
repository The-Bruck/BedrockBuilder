package com.bedrockbuilder.ui

import android.graphics.BitmapShader
import android.graphics.Paint
import android.graphics.Shader
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import com.bedrockbuilder.core.*

@Composable
fun BuildCanvas(vm: EditorViewModel, modifier: Modifier = Modifier) {
    val renderer = remember { FrameRenderer() }
    val facePaint = remember { Paint().apply { isAntiAlias = false; style = Paint.Style.FILL } }
    val gridPaint = remember { Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = 2f } }
    val textPaint = remember { Paint().apply { isAntiAlias = true; textSize = 34f; isFakeBoldText = true } }

    val revision = vm.revision
    val hide = vm.hideAbove
    val layerKey = if (hide) vm.layerY else 0
    val textures = vm.textures
    val mesh = remember(revision, hide, layerKey, textures) { MeshBuilder.build(vm.model, hide, vm.layerY, textures?.map) }
    remember(textures) {
        facePaint.shader = textures?.let { BitmapShader(it.bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
        facePaint.isFilterBitmap = false
        0
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(vm) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val slop = viewConfiguration.touchSlop
                    var moved = Offset.Zero
                    var dragging = false
                    var multi = false
                    vm.onGestureStart()
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Main)
                        val pressed = event.changes.count { it.pressed }
                        if (pressed == 0) break
                        if (pressed >= 2) {
                            multi = true
                            val zoom = event.calculateZoom()
                            val pan = event.calculatePan()
                            if (zoom != 1f || pan != Offset.Zero) vm.onTransform(zoom, pan, size.width.toFloat(), size.height.toFloat())
                            event.changes.forEach { it.consume() }
                        } else if (!multi) {
                            val c = event.changes.firstOrNull { it.pressed } ?: break
                            val d = c.position - c.previousPosition
                            moved += d
                            if (!dragging && moved.getDistance() > slop) dragging = true
                            if (dragging) {
                                vm.onDrag(c.position.x, c.position.y, d.x, d.y, size.width.toFloat(), size.height.toFloat())
                                c.consume()
                            }
                        }
                    }
                    vm.onGestureEnd()
                    if (!dragging && !multi) vm.onTap(down.position.x, down.position.y, size.width.toFloat(), size.height.toFloat())
                }
            },
    ) {
        val w = size.width
        val h = size.height
        val bg = vm.background
        drawRect(Color(bg))
        val bgLum = (0.299f * ((bg shr 16) and 255) + 0.587f * ((bg shr 8) and 255) + 0.114f * (bg and 255)) / 255f
        val lightBg = bgLum > 0.55f
        val boundsColor = if (lightBg) 0x66203040 else 0x55AAC4FF
        val gridColor = if (lightBg) 0x55000000 else 0x70FFFFFF
        val cam = vm.camera
        val model = vm.model
        val layerY = vm.layerY
        val anchor = vm.anchor
        val outline = vm.showOutlines && !cam.fp && (cam.focal(w, h) / cam.dist) > 14f

        drawIntoCanvas { canvas ->
            val nc = canvas.nativeCanvas
            val pj = Projector(cam, w, h)
            val seg = FloatArray(4)
            val lines = FloatBuf(2048)

            fun line(ax: Float, ay: Float, az: Float, bx: Float, by: Float, bz: Float) {
                if (pj.segment(ax, ay, az, bx, by, bz, seg, 0)) lines.add4(seg[0], seg[1], seg[2], seg[3])
            }
            fun flushLines(color: Int, width: Float) {
                if (lines.size == 0) return
                gridPaint.color = color; gridPaint.strokeWidth = width
                nc.drawLines(lines.data, 0, lines.size, gridPaint)
                lines.size = 0
            }
            fun wireBox(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float) {
                line(x0, y0, z0, x1, y0, z0); line(x0, y0, z1, x1, y0, z1); line(x0, y1, z0, x1, y1, z0); line(x0, y1, z1, x1, y1, z1)
                line(x0, y0, z0, x0, y1, z0); line(x1, y0, z0, x1, y1, z0); line(x0, y0, z1, x0, y1, z1); line(x1, y0, z1, x1, y1, z1)
                line(x0, y0, z0, x0, y0, z1); line(x1, y0, z0, x1, y0, z1); line(x0, y1, z0, x0, y1, z1); line(x1, y1, z0, x1, y1, z1)
            }

            val x0 = model.minX.toFloat(); val x1 = model.maxX + 1f
            val y0 = model.minY.toFloat(); val y1 = model.maxY + 1f
            val z0 = model.minZ.toFloat(); val z1 = model.maxZ + 1f

            // grid bounds
            wireBox(x0, y0, z0, x1, y1, z1)
            flushLines(boundsColor, 2f)

            // active layer grid
            val ly = layerY.toFloat()
            for (x in model.minX..model.maxX + 1) line(x.toFloat(), ly, z0, x.toFloat(), ly, z1)
            for (z in model.minZ..model.maxZ + 1) line(x0, ly, z.toFloat(), x1, ly, z.toFloat())
            flushLines(gridColor, 1.5f)
            line(x0, ly, z0, x1, ly, z0); line(x0, ly, z1, x1, ly, z1); line(x0, ly, z0, x0, ly, z1); line(x1, ly, z0, x1, ly, z1)
            flushLines(0xFFFFD166.toInt(), 3f)

            // blocks
            renderer.render(mesh, cam, w, h, outline) { quads ->
                nc.drawVertices(
                    android.graphics.Canvas.VertexMode.TRIANGLES, quads * 8, renderer.verts, 0,
                    renderer.texs, 0, renderer.colors, 0, renderer.indices, 0, quads * 6, facePaint,
                )
            }

            // anchor marker
            if (anchor != null) {
                val ax = anchor[0].toFloat(); val ay = anchor[1].toFloat(); val az = anchor[2].toFloat()
                wireBox(ax, ay, az, ax + 1, ay + 1, az + 1)
                flushLines(0xFFFFD166.toInt(), 5f)
            }

            // axis gizmo at the grid origin corner
            val o = FloatArray(2); val e = FloatArray(2)
            fun axis(dx: Float, dy: Float, dz: Float, color: Int, label: String) {
                val len = 2f
                if (pj.project(x0, y0, z0, o, 0) && pj.project(x0 + dx * len, y0 + dy * len, z0 + dz * len, e, 0)) {
                    gridPaint.color = color; gridPaint.strokeWidth = 5f
                    nc.drawLine(o[0], o[1], e[0], e[1], gridPaint)
                    textPaint.color = color
                    nc.drawText(label, e[0] + 6f, e[1] - 6f, textPaint)
                }
            }
            axis(1f, 0f, 0f, 0xFFFF5555.toInt(), "X+")
            axis(0f, 1f, 0f, 0xFF55DD66.toInt(), "Y+")
            axis(0f, 0f, 1f, 0xFF5599FF.toInt(), "Z+")
        }
    }
}
