package com.bedrockbuilder

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.bedrockbuilder.ui.*

class MainActivity : ComponentActivity() {
    private val home: HomeViewModel by viewModels()
    private val editor: EditorViewModel by viewModels()
    private var openRequest by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            AppTheme {
                var current by rememberSaveable { mutableStateOf<String?>(null) }
                val request = openRequest
                LaunchedEffect(request) {
                    if (request != null) { current = request; openRequest = null }
                }

                val owner = LocalLifecycleOwner.current
                DisposableEffect(owner) {
                    val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) editor.saveNow() }
                    owner.lifecycle.addObserver(obs)
                    onDispose { owner.lifecycle.removeObserver(obs) }
                }

                val name = current
                if (name == null) {
                    HomeScreen(home, onOpen = { current = it })
                } else {
                    LaunchedEffect(name) { editor.open(name) }
                    BackHandler { editor.close(); current = null; home.refresh() }
                    EditorScreen(editor, onBack = { editor.close(); current = null; home.refresh() })
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val uri = i?.data ?: return
        if (i.action != Intent.ACTION_VIEW) return
        home.importUri(uri) { openRequest = it }
    }
}
