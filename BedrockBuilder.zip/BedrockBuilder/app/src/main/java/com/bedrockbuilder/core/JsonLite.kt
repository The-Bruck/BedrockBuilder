package com.bedrockbuilder.core

/** Tolerant JSON parser (Bedrock pack files may contain comments and trailing commas). */
object JsonLite {
    class JsonException(message: String) : Exception(message)

    fun parse(text: String): Any? {
        val p = Parser(text.removePrefix("\uFEFF"))
        val v = p.value(0)
        p.ws()
        return v
    }

    @Suppress("UNCHECKED_CAST")
    fun obj(v: Any?): Map<String, Any?>? = v as? Map<String, Any?>

    @Suppress("UNCHECKED_CAST")
    fun arr(v: Any?): List<Any?>? = v as? List<Any?>

    private class Parser(val s: String) {
        var i = 0

        fun ws() {
            while (i < s.length) {
                val c = s[i]
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t') i++
                else if (c == '/' && i + 1 < s.length && s[i + 1] == '/') { while (i < s.length && s[i] != '\n') i++ }
                else if (c == '/' && i + 1 < s.length && s[i + 1] == '*') {
                    val e = s.indexOf("*/", i + 2); i = if (e < 0) s.length else e + 2
                } else break
            }
        }

        fun value(depth: Int): Any? {
            if (depth > 64) throw JsonException("too deep")
            ws()
            if (i >= s.length) throw JsonException("unexpected end")
            return when (val c = s[i]) {
                '{' -> {
                    i++
                    val m = LinkedHashMap<String, Any?>()
                    while (true) {
                        ws()
                        if (i < s.length && s[i] == '}') { i++; break }
                        if (i >= s.length || s[i] != '"') throw JsonException("expected key at $i")
                        val k = string()
                        ws(); if (i >= s.length || s[i] != ':') throw JsonException("expected ':' at $i"); i++
                        m[k] = value(depth + 1)
                        ws()
                        if (i < s.length && s[i] == ',') { i++; continue }
                        if (i < s.length && s[i] == '}') { i++; break }
                        throw JsonException("expected ',' or '}' at $i")
                    }
                    m
                }
                '[' -> {
                    i++
                    val l = ArrayList<Any?>()
                    while (true) {
                        ws()
                        if (i < s.length && s[i] == ']') { i++; break }
                        l.add(value(depth + 1))
                        ws()
                        if (i < s.length && s[i] == ',') { i++; continue }
                        if (i < s.length && s[i] == ']') { i++; break }
                        throw JsonException("expected ',' or ']' at $i")
                    }
                    l
                }
                '"' -> string()
                't' -> { expect("true"); true }
                'f' -> { expect("false"); false }
                'n' -> { expect("null"); null }
                else -> if (c == '-' || c.isDigit()) number() else throw JsonException("unexpected '$c' at $i")
            }
        }

        fun expect(w: String) { if (!s.startsWith(w, i)) throw JsonException("bad literal at $i"); i += w.length }

        fun number(): Any {
            val st = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] in ".eE+-")) i++
            val t = s.substring(st, i)
            return t.toLongOrNull() ?: t.toDoubleOrNull() ?: throw JsonException("bad number '$t'")
        }

        fun string(): String {
            i++ // opening quote
            val sb = StringBuilder()
            while (i < s.length) {
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (i >= s.length) throw JsonException("bad escape")
                        when (val e = s[i++]) {
                            'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r')
                            'b' -> sb.append('\b'); 'f' -> sb.append('\u000C')
                            'u' -> { sb.append(s.substring(i, minOf(i + 4, s.length)).toInt(16).toChar()); i += 4 }
                            else -> sb.append(e)
                        }
                    }
                    else -> sb.append(c)
                }
            }
            throw JsonException("unterminated string")
        }
    }
}
