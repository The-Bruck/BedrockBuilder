package com.bedrockbuilder.core

class TgaImage(val width: Int, val height: Int, val argb: IntArray)

/** Minimal TGA reader (uncompressed and RLE true-colour, 24/32 bit) - Bedrock packs use .tga textures. */
object TgaDecoder {
    fun decode(b: ByteArray): TgaImage? {
        if (b.size < 18) return null
        val idLen = b[0].toInt() and 255
        val type = b[2].toInt() and 255
        val w = (b[12].toInt() and 255) or ((b[13].toInt() and 255) shl 8)
        val h = (b[14].toInt() and 255) or ((b[15].toInt() and 255) shl 8)
        val bpp = b[16].toInt() and 255
        val desc = b[17].toInt() and 255
        if ((type != 2 && type != 10) || (bpp != 24 && bpp != 32) || w <= 0 || h <= 0 || w > 4096 || h > 4096) return null
        val bytes = bpp / 8
        var p = 18 + idLen + (if ((b[1].toInt() and 255) != 0) {
            val cmLen = (b[5].toInt() and 255) or ((b[6].toInt() and 255) shl 8)
            cmLen * ((b[7].toInt() and 255) / 8)
        } else 0)
        val n = w * h
        val px = IntArray(n)
        fun read(at: Int): Int {
            val bl = b[at].toInt() and 255; val g = b[at + 1].toInt() and 255; val r = b[at + 2].toInt() and 255
            val a = if (bytes == 4) b[at + 3].toInt() and 255 else 255
            return (a shl 24) or (r shl 16) or (g shl 8) or bl
        }
        var i = 0
        try {
            if (type == 2) {
                while (i < n) { px[i++] = read(p); p += bytes }
            } else {
                while (i < n) {
                    val hdr = b[p++].toInt() and 255
                    val count = (hdr and 127) + 1
                    if (hdr >= 128) { val c = read(p); p += bytes; repeat(count) { if (i < n) px[i++] = c } }
                    else repeat(count) { if (i < n) { px[i++] = read(p); p += bytes } }
                }
            }
        } catch (e: IndexOutOfBoundsException) { return null }
        val topDown = (desc and 0x20) != 0
        if (!topDown) {
            val flipped = IntArray(n)
            for (y in 0 until h) System.arraycopy(px, y * w, flipped, (h - 1 - y) * w, w)
            return TgaImage(w, h, flipped)
        }
        return TgaImage(w, h, px)
    }
}
