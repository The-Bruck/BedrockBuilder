package com.bedrockbuilder.core

/** Maps block names to atlas cells per face. Cell 0 is a solid white cell. */
class TextureMap(val cols: Int, val cellSize: Int) {
    class Entry(val cells: IntArray, val tints: IntArray)

    private val map = HashMap<String, Entry>()
    val size get() = map.size

    private val aliases = mapOf(
        "grass_block" to "grass", "sea_lantern" to "seaLantern", "tripwire" to "tripWire",
        "invisible_bedrock" to "invisibleBedrock", "moving_block" to "movingBlock",
    )

    fun entry(name: String): Entry? {
        val n = if (name.startsWith("minecraft:")) name.substring(10) else name
        return map[n] ?: aliases[n]?.let { map[it] }
    }

    /** Adds all entries of [other], shifting its (non-white) cell indices by [cellOffset]. Later entries win. */
    fun merge(other: TextureMap, cellOffset: Int) {
        for ((k, e) in other.map) {
            map[k] = Entry(IntArray(6) { if (e.cells[it] > 0) e.cells[it] + cellOffset else e.cells[it] }, e.tints)
        }
    }

    fun names(): Set<String> = map.keys

    companion object {
        /** Tint colours (RGB) indexed by the tint code stored in block_textures.txt. */
        val TINTS = intArrayOf(0xFFFFFF, 0x79C05A, 0x77AB2F, 0x3F76E4, 0x619961, 0x80A755, 0x208030)

        /** Lines: "name east west up down south north", each "cell" or "cell:tint" or "-1". */
        fun parse(text: String, cols: Int = 64, cellSize: Int = 16): TextureMap {
            val tm = TextureMap(cols, cellSize)
            for (line in text.lineSequence()) {
                val p = line.trim().split(' ')
                if (p.size != 7) continue
                val cells = IntArray(6); val tints = IntArray(6)
                for (i in 0 until 6) {
                    val f = p[i + 1].split(':')
                    cells[i] = f[0].toIntOrNull() ?: -1
                    tints[i] = f.getOrNull(1)?.toIntOrNull() ?: 0
                }
                tm.map[p[0]] = Entry(cells, tints)
            }
            return tm
        }
    }
}
