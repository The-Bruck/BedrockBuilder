package com.bedrockbuilder.core

/**
 * Maps block names to atlas textures per face. Vanilla textures are cell indices in a 16px grid; textures from
 * imported packs are registered as arbitrary pixel rectangles (ids >= PACK_BASE). Id 0 is a solid white cell.
 */
class TextureMap(val cols: Int, val cellSize: Int) {
    class Entry(val cells: IntArray, val tints: IntArray)
    class ModelEntry(val model: GeoModel, val texIds: Map<String, Int>, val defaultId: Int)

    private val map = HashMap<String, Entry>()
    private val models = HashMap<String, ModelEntry>()
    private val packRects = ArrayList<IntArray>()
    val size get() = map.size

    private val aliases = mapOf(
        "grass_block" to "grass", "sea_lantern" to "seaLantern", "tripwire" to "tripWire",
        "invisible_bedrock" to "invisibleBedrock", "moving_block" to "movingBlock",
    )

    private fun key(name: String) = if (name.startsWith("minecraft:")) name.substring(10) else name

    fun entry(name: String): Entry? { val n = key(name); return map[n] ?: aliases[n]?.let { map[it] } }
    fun model(name: String): ModelEntry? = models[key(name)]
    fun putModel(name: String, e: ModelEntry) { models[key(name)] = e }
    fun names(): Set<String> = map.keys

    /** Registers a pixel rectangle of the atlas and returns its texture id. */
    fun addPackRect(x: Int, y: Int, w: Int, h: Int): Int {
        packRects.add(intArrayOf(x, y, w, h))
        return PACK_BASE + packRects.size - 1
    }

    /** Atlas rectangle [x, y, w, h] of a texture id. */
    fun rect(id: Int): IntArray =
        if (id >= PACK_BASE) packRects.getOrNull(id - PACK_BASE) ?: intArrayOf(0, 0, cellSize, cellSize)
        else intArrayOf((id % cols) * cellSize, (id / cols) * cellSize, cellSize, cellSize)

    /** Adds all entries of [other] (its ids must already be final). Later entries win. */
    fun merge(other: TextureMap) { map.putAll(other.map) }

    companion object {
        const val PACK_BASE = 1_000_000

        /** Tint colours (RGB) indexed by the tint code stored in block_textures.txt. */
        val TINTS = intArrayOf(0xFFFFFF, 0x79C05A, 0x77AB2F, 0x3F76E4, 0x619961, 0x80A755, 0x208030)

        /** Lines: "name east west up down south north", each "cell" or "cell:tint" or "-1". */
        fun parse(text: String, cols: Int = 64, cellSize: Int = 16): TextureMap {
            val tm = TextureMap(cols, cellSize)
            for (line in text.lineSequence()) {
                val p = line.trim().split(' ')
                if (p.size != 7) continue
                val cells = IntArray(6); val tints = IntArray(6)
                for (i in 0 until 6) {
                    val f = p[i + 1].split(':')
                    cells[i] = f[0].toIntOrNull() ?: -1
                    tints[i] = f.getOrNull(1)?.toIntOrNull() ?: 0
                }
                tm.map[p[0]] = Entry(cells, tints)
            }
            return tm
        }
    }
}
