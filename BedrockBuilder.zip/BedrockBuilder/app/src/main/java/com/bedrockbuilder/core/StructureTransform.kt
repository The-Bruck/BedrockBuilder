package com.bedrockbuilder.core

object StructureTransform {
    /** Rotates the whole structure 90° about the vertical axis (clockwise seen from above) and re-orients block states. */
    fun rotateY(m: BuildModel, clockwise: Boolean) {
        val sx = m.sizeX; val sz = m.sizeZ
        val nb = HashMap<Long, Int>(m.blocks.size * 2)
        val ns = HashMap<Long, Int>(); val ne = HashMap<Long, CompoundTag>()
        val remap = HashMap<Int, Int>()
        val steps = if (clockwise) 1 else -1
        fun rid(id: Int) = remap.getOrPut(id) { m.idFor(StateRotation.rotate(m.palette[id], steps)) }
        for ((k, id) in m.blocks) {
            val dx = BuildModel.kx(k) - m.minX; val dz = BuildModel.kz(k) - m.minZ
            val ndx = if (clockwise) sz - 1 - dz else dz
            val ndz = if (clockwise) dx else sx - 1 - dx
            val nk = BuildModel.key(m.minX + ndx, BuildModel.ky(k), m.minZ + ndz)
            nb[nk] = rid(id)
            m.secondary[k]?.let { ns[nk] = rid(it) }
            m.blockEntities[k]?.let { ne[nk] = it }
        }
        m.blocks.clear(); m.blocks.putAll(nb)
        m.secondary.clear(); m.secondary.putAll(ns)
        m.blockEntities.clear(); m.blockEntities.putAll(ne)
        m.entities = emptyList()
        m.maxX = m.minX + sz - 1; m.maxZ = m.minZ + sx - 1
    }
}
