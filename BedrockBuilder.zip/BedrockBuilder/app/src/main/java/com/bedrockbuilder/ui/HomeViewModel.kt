package com.bedrockbuilder.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bedrockbuilder.core.BuildModel
import com.bedrockbuilder.core.McStructure
import com.bedrockbuilder.data.StructureStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val store = StructureStore(app)
    var entries by mutableStateOf<List<StructureStore.Entry>>(emptyList())
        private set
    var message by mutableStateOf<String?>(null)

    init { refresh() }

    fun refresh() {
        viewModelScope.launch { entries = withContext(Dispatchers.IO) { store.list() } }
    }

    fun suggestName(): String = store.uniqueName("My structure")

    fun create(name: String, sx: Int, sy: Int, sz: Int, onDone: (String) -> Unit) {
        if (sx < 1 || sy < 1 || sz < 1 || sx > BuildModel.MAX_AXIS || sy > BuildModel.MAX_AXIS || sz > BuildModel.MAX_AXIS ||
            sx.toLong() * sy * sz > BuildModel.MAX_VOLUME) {
            message = "Size must be 1–${BuildModel.MAX_AXIS} per axis"; return
        }
        viewModelScope.launch {
            val n = withContext(Dispatchers.IO) {
                val u = store.uniqueName(name)
                store.write(u, McStructure.write(BuildModel.create(sx, sy, sz), false))
                u
            }
            refresh(); onDone(n)
        }
    }

    fun delete(name: String) {
        viewModelScope.launch { withContext(Dispatchers.IO) { store.delete(name) }; refresh() }
    }

    fun rename(old: String, new: String) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { store.rename(old, new) } }
            r.onFailure { message = "Rename failed: ${it.message}" }
            refresh()
        }
    }

    fun duplicate(name: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { runCatching { store.duplicate(name) } }
            refresh()
        }
    }

    fun importUri(uri: Uri, onDone: (String) -> Unit) {
        val resolver = getApplication<Application>().contentResolver
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Could not open file")
                    if (bytes.size > 64 * 1024 * 1024) error("File is too large")
                    val model = McStructure.read(bytes) // validates
                    var display = "Imported"
                    resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getString(0)?.let { display = it }
                    }
                    val name = store.uniqueName(display.removeSuffix(".mcstructure").removeSuffix(".MCSTRUCTURE"))
                    store.write(name, McStructure.write(model))
                    name
                }
            }
            r.onSuccess { refresh(); message = "Imported \"$it\""; onDone(it) }
            r.onFailure { message = "Import failed: ${it.message}" }
        }
    }

    fun exportTo(name: String, uri: Uri) {
        val resolver = getApplication<Application>().contentResolver
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    resolver.openOutputStream(uri, "wt")?.use { it.write(store.file(name).readBytes()) } ?: error("Could not write")
                }
            }
            message = if (r.isSuccess) "Exported \"$name.mcstructure\"" else "Export failed: ${r.exceptionOrNull()?.message}"
        }
    }

    fun shareFile(name: String, onReady: (File) -> Unit) {
        viewModelScope.launch {
            val f = withContext(Dispatchers.IO) { runCatching { store.shareFile(name) } }
            f.onSuccess(onReady).onFailure { message = "Share failed: ${it.message}" }
        }
    }
}
