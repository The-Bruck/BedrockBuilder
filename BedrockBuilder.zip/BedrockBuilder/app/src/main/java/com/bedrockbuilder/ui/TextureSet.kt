package com.bedrockbuilder.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.bedrockbuilder.core.PackBlock
import com.bedrockbuilder.core.PackScanner
import com.bedrockbuilder.core.TextureMap
import com.bedrockbuilder.core.TgaDecoder

/**
 * Texture atlas + face map for one structure: vanilla textures (16px cells) plus the textures of its imported packs
 * (64px cells below them), and the 3D models those packs define for their custom blocks.
 */
class TextureSet(
    val bitmap: Bitmap, val map: TextureMap,
    val packBlocks: List<PackBlock>, val packNames: List<String>, val hasVanilla: Boolean,
) {
    val image: ImageBitmap by lazy { bitmap.asImageBitmap() }

    companion object {
        private const val COLS = 64
        private const val CELL = 16
        private const val PACK_CELL = 64
        private const val PACK_COLS = (COLS * CELL) / PACK_CELL
        private var vanillaBitmap: Bitmap? = null
        private var vanillaText: String? = null
        private var vanillaLoaded = false

        @Synchronized
        private fun loadVanilla(context: Context) {
            if (vanillaLoaded) return
            vanillaLoaded = true
            try {
                val opts = BitmapFactory.Options().apply { inScaled = false; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                vanillaBitmap = context.assets.open("atlas.png").use { BitmapFactory.decodeStream(it, null, opts) }
                vanillaText = context.assets.open("block_textures.txt").use { it.readBytes().toString(Charsets.UTF_8) }
            } catch (e: Exception) {
                vanillaBitmap = null; vanillaText = null
            }
        }

        /** Builds the texture set; archives are the raw bytes of the structure's imported packs. Bad packs are skipped. */
        fun build(context: Context, archives: List<ByteArray>): TextureSet {
            loadVanilla(context)
            val vb = vanillaBitmap
            val hasVanilla = vb != null && vanillaText != null
            val vanillaRows = if (hasVanilla) vb!!.height / CELL else 1
            val map = if (hasVanilla) TextureMap.parse(vanillaText!!, COLS, CELL) else TextureMap(COLS, CELL)
            val packTop = vanillaRows * CELL

            var packNames: List<String> = emptyList()
            var packBlocks: List<PackBlock> = emptyList()
            val textures = ArrayList<Bitmap>()
            if (archives.isNotEmpty()) {
                try {
                    val set = PackScanner.scanAll(archives)
                    packNames = set.packNames; packBlocks = set.blocks
                    // textures used by 3D models keep their whole image (UV maps cover the full sheet)
                    val modelTextures = set.blocks.filter { it.model != null }.flatMap { it.boneTextures.values }.toSet()
                    val ids = HashMap<String, Int>()
                    for ((path, t) in set.textures) {
                        val bmp = decode(t.ext, t.bytes, cropToSquare = path !in modelTextures) ?: continue
                        val i = textures.size
                        textures.add(bmp)
                        ids[path] = map.addPackRect((i % PACK_COLS) * PACK_CELL, packTop + (i / PACK_COLS) * PACK_CELL, PACK_CELL, PACK_CELL)
                    }
                    map.merge(TextureMap.parse(set.mapText { ids[it] }, COLS, CELL))
                    for (pb in set.blocks) {
                        val model = pb.model ?: continue
                        val texIds = pb.boneTextures.mapNotNull { (bone, path) -> ids[path]?.let { bone to it } }.toMap()
                        map.putModel(pb.id, TextureMap.ModelEntry(model, texIds, texIds["*"] ?: 0))
                    }
                } catch (e: Exception) {
                    // ignore unreadable packs; the structure still opens
                }
            }
            val packRows = (textures.size + PACK_COLS - 1) / PACK_COLS
            val out = Bitmap.createBitmap(COLS * CELL, packTop + packRows * PACK_CELL, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            if (hasVanilla) canvas.drawBitmap(vb!!, 0f, 0f, null)
            else { val p = Paint().apply { color = 0xFFFFFFFF.toInt() }; canvas.drawRect(0f, 0f, CELL.toFloat(), CELL.toFloat(), p) }
            textures.forEachIndexed { i, bmp ->
                canvas.drawBitmap(bmp, ((i % PACK_COLS) * PACK_CELL).toFloat(), (packTop + (i / PACK_COLS) * PACK_CELL).toFloat(), null)
            }
            return TextureSet(out, map, packBlocks, packNames, hasVanilla)
        }

        private fun decode(ext: String, bytes: ByteArray, cropToSquare: Boolean): Bitmap? {
            val src: Bitmap = if (ext == "tga") {
                val t = TgaDecoder.decode(bytes) ?: return null
                Bitmap.createBitmap(t.argb, t.width, t.height, Bitmap.Config.ARGB_8888)
            } else {
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inScaled = false }) ?: return null
            }
            val square = if (cropToSquare && src.height > src.width) Bitmap.createBitmap(src, 0, 0, src.width, src.width) else src
            if (square.width == PACK_CELL && square.height == PACK_CELL) return square
            // upscale small textures with nearest-neighbour (keeps the pixel look), average when shrinking
            val shrinking = square.width > PACK_CELL || square.height > PACK_CELL
            return Bitmap.createScaledBitmap(square, PACK_CELL, PACK_CELL, shrinking)
        }
    }
}
