package com.bedrockbuilder.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.bedrockbuilder.core.PackBlock
import com.bedrockbuilder.core.PackScanner
import com.bedrockbuilder.core.TextureMap
import com.bedrockbuilder.core.TgaDecoder

/** Texture atlas + face map for one structure: vanilla textures plus textures of its imported packs. */
class TextureSet(
    val bitmap: Bitmap, val map: TextureMap,
    val packBlocks: List<PackBlock>, val packNames: List<String>, val hasVanilla: Boolean,
) {
    val image: ImageBitmap by lazy { bitmap.asImageBitmap() }
    val cols get() = map.cols
    val cellSize get() = map.cellSize

    companion object {
        private const val COLS = 64
        private const val CELL = 16
        private var vanillaBitmap: Bitmap? = null
        private var vanillaText: String? = null
        private var vanillaLoaded = false

        @Synchronized
        private fun loadVanilla(context: Context) {
            if (vanillaLoaded) return
            vanillaLoaded = true
            try {
                val opts = BitmapFactory.Options().apply { inScaled = false; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                vanillaBitmap = context.assets.open("atlas.png").use { BitmapFactory.decodeStream(it, null, opts) }
                vanillaText = context.assets.open("block_textures.txt").use { it.readBytes().toString(Charsets.UTF_8) }
            } catch (e: Exception) {
                vanillaBitmap = null; vanillaText = null
            }
        }

        /** Builds the texture set; archives are the raw bytes of the structure's imported packs. Throws nothing - bad packs are skipped. */
        fun build(context: Context, archives: List<ByteArray>): TextureSet {
            loadVanilla(context)
            val vb = vanillaBitmap
            val hasVanilla = vb != null && vanillaText != null
            val vanillaRows = if (hasVanilla) vb!!.height / CELL else 1
            val map = if (hasVanilla) TextureMap.parse(vanillaText!!, COLS, CELL) else TextureMap(COLS, CELL)

            var packNames: List<String> = emptyList()
            var packBlocks: List<PackBlock> = emptyList()
            val textures = ArrayList<Pair<String, Bitmap>>()
            if (archives.isNotEmpty()) {
                try {
                    val set = PackScanner.scanAll(archives)
                    packNames = set.packNames; packBlocks = set.blocks
                    for ((path, t) in set.textures) {
                        val bmp = decode(t.ext, t.bytes) ?: continue
                        textures.add(path to bmp)
                    }
                    val index = HashMap<String, Int>()
                    textures.forEachIndexed { i, (p, _) -> index[p] = i + 1 }
                    val offset = vanillaRows * COLS
                    map.merge(TextureMap.parse(set.mapText { index[it] }, COLS, CELL), offset)
                } catch (e: Exception) {
                    // ignore unreadable packs; the structure still opens
                }
            }
            val packRows = if (textures.isEmpty()) 0 else (textures.size + 1 + COLS - 1) / COLS
            val out = Bitmap.createBitmap(COLS * CELL, (vanillaRows + packRows) * CELL, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            if (hasVanilla) canvas.drawBitmap(vb!!, 0f, 0f, null)
            else { val p = Paint().apply { color = 0xFFFFFFFF.toInt() }; canvas.drawRect(0f, 0f, CELL.toFloat(), CELL.toFloat(), p) }
            textures.forEachIndexed { i, (_, bmp) ->
                val cell = vanillaRows * COLS + i + 1
                canvas.drawBitmap(bmp, ((cell % COLS) * CELL).toFloat(), ((cell / COLS) * CELL).toFloat(), null)
            }
            return TextureSet(out, map, packBlocks, packNames, hasVanilla)
        }

        private fun decode(ext: String, bytes: ByteArray): Bitmap? {
            val src: Bitmap = if (ext == "tga") {
                val t = TgaDecoder.decode(bytes) ?: return null
                Bitmap.createBitmap(t.argb, t.width, t.height, Bitmap.Config.ARGB_8888)
            } else {
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inScaled = false }) ?: return null
            }
            val square = if (src.height > src.width) Bitmap.createBitmap(src, 0, 0, src.width, src.width) else src
            return if (square.width == CELL && square.height == CELL) square else Bitmap.createScaledBitmap(square, CELL, CELL, true)
        }
    }
}
