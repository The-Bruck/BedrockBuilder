package com.bedrockbuilder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bedrockbuilder.core.BlockRegistry
import com.bedrockbuilder.core.BlockState
import com.bedrockbuilder.core.BlockVisuals
import com.bedrockbuilder.core.StateHints

fun swatch(name: String): Color = Color(BlockVisuals.color(name))

@Composable
fun BlockSwatch(name: String, size: Int = 28) {
    Box(
        Modifier.size(size.dp).background(swatch(name), RoundedCornerShape(5.dp))
    )
}

private const val TAB_ALL = "All"
private const val TAB_RECENT = "Recent"
private const val TAB_CUSTOM = "Custom"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlockPickerSheet(vm: EditorViewModel, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(TAB_ALL) }
    var showCustom by remember { mutableStateOf(false) }
    val tabs = remember { listOf(TAB_ALL, TAB_RECENT, TAB_CUSTOM) + BlockRegistry.Category.values().map { it.label } }

    val list: List<BlockState> = remember(query, tab, vm.recents, vm.customs) {
        val base: List<BlockState> = when (tab) {
            TAB_RECENT -> vm.recents
            TAB_CUSTOM -> vm.customs
            TAB_ALL -> BlockRegistry.all.map { BlockState(it) }
            else -> {
                val cat = BlockRegistry.Category.values().first { it.label == tab }
                BlockRegistry.inCategory(cat).map { BlockState(it) }
            }
        }
        val q = query.trim().lowercase().replace(' ', '_')
        if (q.isEmpty()) base else base.filter { it.name.contains(q) }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxHeight(0.92f).padding(horizontal = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BlockSwatch(vm.current.name, 36)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(vm.current.shortName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(vm.current.name + if (vm.current.states.isNotEmpty()) "  [" + vm.current.statesText() + "]" else "",
                        style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                Button(onClick = onDismiss) { Text("Done") }
            }
            StateEditor(vm)
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                singleLine = true, label = { Text("Search ${BlockRegistry.all.size} blocks") },
                trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, "Clear") } },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            )
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                tabs.forEach { t -> FilterChip(selected = tab == t, onClick = { tab = t }, label = { Text(t) }) }
            }
            LazyColumn(Modifier.weight(1f)) {
                if (tab == TAB_CUSTOM || query.isNotEmpty() && list.isEmpty()) {
                    item {
                        OutlinedButton(onClick = { showCustom = true }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Add custom block identifier")
                        }
                    }
                }
                items(list, key = { it.serialize() }) { b ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.selectBlock(b) }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        BlockSwatch(b.name)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(b.shortName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(b.name + if (b.states.isNotEmpty()) "  [" + b.statesText() + "]" else "",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (tab == TAB_CUSTOM) IconButton(onClick = { vm.removeCustomBlock(b) }) { Icon(Icons.Default.Close, "Remove") }
                        if (b.name == vm.current.name) Text("●", color = MaterialTheme.colorScheme.primary)
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
            TextButton(onClick = { showCustom = true }) { Text("+ Custom block (identifier)") }
        }
    }

    if (showCustom) CustomBlockDialog(
        initial = query,
        onDismiss = { showCustom = false },
        onAdd = { vm.addCustomBlock(it); showCustom = false },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StateEditor(vm: EditorViewModel) {
    val cur = vm.current
    val hints = remember(cur.name) { StateHints.forBlock(cur.name) }
    var raw by remember { mutableStateOf(cur.statesText()) }
    var rawError by remember { mutableStateOf(false) }
    LaunchedEffect(cur.name, cur.states) {
        if (BlockState.parseStates(raw) != cur.states) { raw = cur.statesText(); rawError = false }
    }
    Column {
        hints.forEach { h ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(h.label, Modifier.width(92.dp), style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    h.options.forEach { (label, value) ->
                        FilterChip(
                            selected = cur.states[h.key] == value,
                            onClick = { vm.selectBlock(cur.withState(h.key, if (cur.states[h.key] == value) null else value)) },
                            label = { Text(label) },
                        )
                    }
                }
            }
        }
        OutlinedTextField(
            value = raw,
            onValueChange = {
                raw = it
                val parsed = BlockState.parseStates(it)
                rawError = parsed == null
                if (parsed != null) vm.selectBlock(cur.copy(states = parsed))
            },
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            singleLine = true, isError = rawError,
            label = { Text("Block states (key=value, …)") },
            supportingText = { if (rawError) Text("Use key=value pairs separated by commas") },
        )
    }
}

@Composable
fun CustomBlockDialog(initial: String, onDismiss: () -> Unit, onAdd: (BlockState) -> Unit) {
    var id by remember { mutableStateOf(initial) }
    var states by remember { mutableStateOf("") }
    val name = BlockState.normalizeName(id)
    val parsed = BlockState.parseStates(states)
    val valid = id.isNotBlank() && BlockState.isValidName(name) && parsed != null
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom block") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(id, { id = it }, singleLine = true, label = { Text("Identifier") },
                    placeholder = { Text("minecraft:cut_copper or my_pack:ruby_block") },
                    supportingText = { Text(if (id.isBlank()) "\"minecraft:\" is added if you leave out the namespace" else name) })
                OutlinedTextField(states, { states = it }, singleLine = true, label = { Text("States (optional)") },
                    placeholder = { Text("facing_direction=2, open_bit=true") }, isError = parsed == null)
            }
        },
        confirmButton = { TextButton(enabled = valid, onClick = { onAdd(BlockState(name, parsed ?: emptyMap())) }) { Text("Add & use") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
