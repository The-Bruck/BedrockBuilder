package com.bedrockbuilder.core

/** Approximate colours and simple shapes used to draw blocks (no textures are shipped). */
object BlockVisuals {
    private val colorCache = HashMap<String, Int>()

    private val dyes = listOf(
        "light_blue" to 0x3AAFD9, "light_gray" to 0x8E8E86, "silver" to 0x8E8E86, "white" to 0xE9ECEC,
        "orange" to 0xF07613, "magenta" to 0xBD44B3, "yellow" to 0xF8C527, "lime" to 0x70B919, "pink" to 0xED8DAC,
        "gray" to 0x3E4447, "cyan" to 0x158991, "purple" to 0x792AAC, "blue" to 0x35399D, "brown" to 0x724728,
        "green" to 0x546D1B, "red" to 0xA12722, "black" to 0x141519,
    )

    // Most specific keywords first.
    private val materials = listOf(
        "blue_ice" to 0x74A8FD, "packed_ice" to 0x8DB4F0, "frosted_ice" to 0xA5C8F2, "ice" to 0xA5C8F2,
        "red_sandstone" to 0xB5622F, "red_sand" to 0xB5622F, "sandstone" to 0xD8CB9B, "sand" to 0xDBCFA3,
        "red_nether_brick" to 0x4F1B1E, "nether_brick" to 0x2C161B, "netherrack" to 0x6F3636, "nether_wart_block" to 0x730D0D,
        "warped_wart" to 0x167E86, "crimson" to 0x7B2B40, "warped" to 0x1E7B73, "soul_s" to 0x514034, "magma" to 0x8E3A12,
        "glowstone" to 0xF2C464, "shroomlight" to 0xF19B4A, "sea_lantern" to 0xCFE8E0, "end_stone" to 0xDEE2A8,
        "purpur" to 0xA97CA9, "chorus" to 0x8A5F8A, "obsidian" to 0x14111F, "bedrock" to 0x4A4A4A,
        "deepslate" to 0x4B4B50, "blackstone" to 0x2A252B, "basalt" to 0x4D4D52, "tuff" to 0x6B6D62, "calcite" to 0xE0E0DA,
        "dripstone" to 0x7F6555, "granite" to 0x9A6B58, "diorite" to 0xBDBDBD, "andesite" to 0x888888,
        "mossy" to 0x6B8A55, "moss" to 0x5D7A2A, "cobblestone" to 0x7A7A7A, "stone" to 0x7D7D7D,
        "mud" to 0x3B3A3E, "podzol" to 0x5B4125, "mycelium" to 0x6F6265, "grass_block" to 0x5D9C3A, "grass_path" to 0x948A4A,
        "dirt" to 0x866043, "farmland" to 0x6A4528, "gravel" to 0x837F7E, "clay" to 0x9EA4B0, "snow" to 0xF8FEFE,
        "sculk" to 0x0D2531, "amethyst" to 0x8F65C2, "prismarine" to 0x63A38F, "sponge" to 0xCFCB4A,
        "slime" to 0x77C25B, "honey" to 0xE3A21F, "hay" to 0xC9A227, "pumpkin" to 0xD58516, "melon" to 0x7CA024,
        "tnt" to 0xC8472E, "bookshelf" to 0x8B6B3B, "bricks" to 0x96604F, "brick" to 0x96604F,
        "quartz" to 0xEBE5DE, "coal" to 0x2B2B2B, "raw_iron" to 0xA6805F, "iron" to 0xD8D8D8, "raw_copper" to 0xA66A4A,
        "oxidized" to 0x52A387, "weathered" to 0x6BA380, "exposed" to 0x9E7A68, "copper" to 0xC16B4F,
        "raw_gold" to 0xD6A83A, "gold" to 0xF5D13D, "redstone" to 0xB01E10, "lapis" to 0x1D4BA3, "diamond" to 0x5ADBD2,
        "emerald" to 0x20C45D, "netherite" to 0x4C4448, "ancient_debris" to 0x5E4339, "water" to 0x3B5FCF, "lava" to 0xE8601C,
        "glass" to 0xC6E3EA, "leaves" to 0x3B7A25, "azalea" to 0x5E8C32, "cactus" to 0x2F7A2A, "bamboo" to 0xC8B24A,
        "cherry" to 0xE2B2AD, "pale_oak" to 0xE8DDD0, "dark_oak" to 0x4B3621, "mangrove" to 0x7A3A3A, "spruce" to 0x735B35,
        "birch" to 0xD7C98B, "jungle" to 0xA5734D, "acacia" to 0xA95A32, "oak" to 0xA2814F,
        "terracotta" to 0x9A5C42, "hardened_clay" to 0x9A5C42, "wool" to 0xE9ECEC, "torch" to 0xF4B63A, "lantern" to 0xE8A33A,
        "fire" to 0xF08A24, "web" to 0xE6E6E6, "chain" to 0x4A5059, "bars" to 0x8A8F95, "cake" to 0xF1E6D6,
        "barrier" to 0xD12B2B, "structure" to 0xA56ACF, "command" to 0xC27A3A, "light_block" to 0xF3E58A,
        "furnace" to 0x6E6E6E, "smoker" to 0x6E6E6E, "table" to 0x8A6A3A, "chest" to 0x9A6B2A, "barrel" to 0x7A5A32,
        "piston" to 0x9A8760, "observer" to 0x6B6B6B, "dropper" to 0x727272, "dispenser" to 0x727272, "hopper" to 0x4A4A4A,
        "rail" to 0x8A7A5A, "lever" to 0x7A7A7A, "button" to 0x8A8A8A,
    )

    private val translucentWords = listOf("glass", "ice", "water", "slime", "honey_block", "barrier", "light_block", "powder_snow")

    fun isTranslucent(name: String): Boolean {
        val n = name.substringAfter(':')
        if (n == "packed_ice" || n == "blue_ice") return false
        return translucentWords.any { n.contains(it) }
    }

    fun color(name: String): Int = colorCache.getOrPut(name) { computeColor(name.substringAfter(':')) }

    private fun computeColor(n: String): Int {
        // Dyed families: the colour word wins ("light_blue_wool"), except for ice-like materials.
        if (!n.contains("ice") && !n.contains("sandstone") && !n.contains("nether") && !n.contains("netherite")) {
            for ((k, c) in dyes) {
                if (n.startsWith("${k}_") && (n.contains("wool") || n.contains("carpet") || n.contains("concrete") ||
                        n.contains("terracotta") || n.contains("glass") || n.contains("shulker") || n.contains("candle") ||
                        n.contains("bed") || n.contains("banner"))) {
                    var rgb = c
                    if (n.contains("terracotta") && !n.contains("glazed")) rgb = mix(c, 0x8A5A44, 0.55f)
                    if (n.contains("powder")) rgb = mix(rgb, 0xFFFFFF, 0.15f)
                    return 0xFF000000.toInt() or rgb
                }
            }
        }
        for ((k, c) in materials) if (n.contains(k)) return 0xFF000000.toInt() or c
        for ((k, c) in dyes) if (n.contains(k)) return 0xFF000000.toInt() or c
        // deterministic fallback colour
        val h = (n.hashCode() and 0x7FFFFFFF) % 360
        return hsv(h.toFloat(), 0.35f, 0.75f)
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(s: Int) = (((a shr s) and 255) * (1 - t) + ((b shr s) and 255) * t).toInt()
        return (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    private fun hsv(h: Float, s: Float, v: Float): Int {
        val c = v * s; val x = c * (1 - kotlin.math.abs((h / 60f) % 2 - 1)); val m = v - c
        val (r, g, b) = when {
            h < 60 -> Triple(c, x, 0f); h < 120 -> Triple(x, c, 0f); h < 180 -> Triple(0f, c, x)
            h < 240 -> Triple(0f, x, c); h < 300 -> Triple(x, 0f, c); else -> Triple(c, 0f, x)
        }
        return (0xFF shl 24) or (((r + m) * 255).toInt() shl 16) or (((g + m) * 255).toInt() shl 8) or ((b + m) * 255).toInt()
    }

    private val FULL = listOf(floatArrayOf(0f, 0f, 0f, 1f, 1f, 1f))
    private val PLANTS = listOf("sapling", "tulip", "dandelion", "poppy", "orchid", "allium", "azure_bluet", "daisy",
        "cornflower", "lily_of_the_valley", "wither_rose", "torchflower", "pitcher", "spore_blossom", "fern", "tall_grass",
        "short_grass", "dead_bush", "sunflower", "lilac", "rose_bush", "peony", "sweet_berry", "waterlily", "vine", "roots",
        "sprouts", "fungus", "wheat", "carrots", "potatoes", "beetroot", "stem", "reeds", "kelp", "seagrass", "coral",
        "flower_pot", "mushroom", "cocoa", "propagule", "sea_pickle", "lichen", "dripleaf", "eyeblossom", "wildflowers", "leaf_litter",
        "_bud", "cluster", "nether_wart", "fire", "web", "redstone_wire", "tripwire", "bamboo")

    fun boxes(s: BlockState): List<FloatArray> {
        val n = s.shortName
        val top = s.states["minecraft:vertical_half"] == "top" || s.states["top_slot_bit"] == true
        return when {
            n.endsWith("_slab") && !n.contains("double") ->
                listOf(if (top) floatArrayOf(0f, .5f, 0f, 1f, 1f, 1f) else floatArrayOf(0f, 0f, 0f, 1f, .5f, 1f))
            n.endsWith("_stairs") -> stairBoxes(s)
            n.endsWith("_carpet") -> listOf(floatArrayOf(0f, 0f, 0f, 1f, .0625f, 1f))
            n == "snow_layer" -> {
                val h = ((s.states["height"] as? Int) ?: 0) + 1
                listOf(floatArrayOf(0f, 0f, 0f, 1f, h / 8f, 1f))
            }
            n.contains("pressure_plate") -> listOf(floatArrayOf(.06f, 0f, .06f, .94f, .08f, .94f))
            n.contains("rail") && !n.contains("trail") -> listOf(floatArrayOf(0f, 0f, 0f, 1f, .08f, 1f))
            n.endsWith("torch") -> listOf(floatArrayOf(.43f, 0f, .43f, .57f, .65f, .57f))
            n.endsWith("lantern") -> listOf(floatArrayOf(.31f, 0f, .31f, .69f, .56f, .69f))
            n.endsWith("fence") -> listOf(floatArrayOf(.375f, 0f, .375f, .625f, 1f, .625f))
            n.endsWith("_wall") -> listOf(floatArrayOf(.25f, 0f, .25f, .75f, 1f, .75f))
            n.endsWith("fence_gate") -> listOf(floatArrayOf(0f, 0f, .375f, 1f, .9f, .625f))
            n.endsWith("glass_pane") || n == "iron_bars" || n == "chain" -> listOf(floatArrayOf(.44f, 0f, .44f, .56f, 1f, .56f))
            n.endsWith("_door") -> listOf(floatArrayOf(0f, 0f, 0f, 1f, 1f, .19f))
            n.endsWith("trapdoor") -> {
                val up = s.states["upside_down_bit"] == true
                listOf(if (up) floatArrayOf(0f, .81f, 0f, 1f, 1f, 1f) else floatArrayOf(0f, 0f, 0f, 1f, .19f, 1f))
            }
            n.endsWith("_button") -> listOf(floatArrayOf(.3f, 0f, .35f, .7f, .15f, .65f))
            n == "ladder" -> listOf(floatArrayOf(0f, 0f, .88f, 1f, 1f, 1f))
            n == "chest" || n == "trapped_chest" || n == "ender_chest" -> listOf(floatArrayOf(.06f, 0f, .06f, .94f, .88f, .94f))
            n == "end_rod" || n == "lightning_rod" -> listOf(floatArrayOf(.4f, 0f, .4f, .6f, 1f, .6f))
            n == "cake" -> listOf(floatArrayOf(.06f, 0f, .06f, .94f, .5f, .94f))
            n == "bed" -> listOf(floatArrayOf(0f, 0f, 0f, 1f, .56f, 1f))
            n.contains("campfire") -> listOf(floatArrayOf(0f, 0f, 0f, 1f, .44f, 1f))
            n == "barrier" || n == "light_block" || n == "structure_void" || n == "allow" || n == "deny" ->
                listOf(floatArrayOf(.25f, .25f, .25f, .75f, .75f, .75f))
            isPlant(n) -> listOf(floatArrayOf(.2f, 0f, .2f, .8f, .7f, .8f))
            else -> FULL
        }
    }

    private fun isPlant(n: String): Boolean {
        if (n.endsWith("_block") || n.endsWith("leaves") || n.endsWith("_planks") || n.endsWith("_nylium") ||
            n.contains("stairs") || n.contains("slab") || n.contains("fence") || n.contains("door") ||
            n.contains("button") || n.contains("plate") || n.contains("sign") || n.contains("bamboo_mosaic") ||
            n == "muddy_mangrove_roots" || n == "dirt_with_roots" || n == "budding_amethyst" ||
            n == "mushroom_stem" || n.contains("shroomlight")
        ) return false
        if (n.endsWith("_stem") && (n.startsWith("crimson") || n.startsWith("warped") || n.startsWith("stripped"))) return false
        if (n.endsWith("_hyphae")) return false
        return PLANTS.any { n.contains(it) }
    }

    private fun stairBoxes(s: BlockState): List<FloatArray> {
        val dir = (s.states["weirdo_direction"] as? Int) ?: 0
        val up = s.states["upside_down_bit"] == true
        val base = if (up) floatArrayOf(0f, .5f, 0f, 1f, 1f, 1f) else floatArrayOf(0f, 0f, 0f, 1f, .5f, 1f)
        val y0 = if (up) 0f else .5f; val y1 = if (up) .5f else 1f
        val step = when (dir) {
            0 -> floatArrayOf(.5f, y0, 0f, 1f, y1, 1f)
            1 -> floatArrayOf(0f, y0, 0f, .5f, y1, 1f)
            2 -> floatArrayOf(0f, y0, .5f, 1f, y1, 1f)
            else -> floatArrayOf(0f, y0, 0f, 1f, y1, .5f)
        }
        return listOf(base, step)
    }

    fun occludes(s: BlockState): Boolean {
        val n = s.shortName
        if (isTranslucent(s.name)) return false
        val b = boxes(s)
        return b.size == 1 && b[0] === FULL[0] && n != "air"
    }
}
