package com.bedrockbuilder.data

import android.content.Context
import com.bedrockbuilder.core.BlockState

class PaletteEntry(val block: BlockState, val weight: Int)

/** Movable / resizable on-screen controls. */
enum class HudElement(val label: String, val minScale: Float, val maxScale: Float) {
    HOTBAR("Hotbar", 0.6f, 2.5f), DOCK("Tool panel", 0.6f, 1.3f), LAYER("Layer control", 0.6f, 2.0f)
}

/** Offset in pixels from the default position, plus a size multiplier. */
data class HudConfig(val dx: Float = 0f, val dy: Float = 0f, val scale: Float = 1f)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("bedrock_builder", Context.MODE_PRIVATE)

    var showOutlines: Boolean
        get() = sp.getBoolean("outlines", false)
        set(v) { sp.edit().putBoolean("outlines", v).apply() }

    var background: Int
        get() = sp.getInt("background", 0xFF1C2532.toInt())
        set(v) { sp.edit().putInt("background", v).apply() }

    private fun readList(key: String): List<BlockState> =
        (sp.getString(key, "") ?: "").split('\n').mapNotNull { if (it.isBlank()) null else BlockState.deserialize(it) }

    private fun writeList(key: String, list: List<BlockState>) {
        sp.edit().putString(key, list.joinToString("\n") { it.serialize() }).apply()
    }

    fun recents(): List<BlockState> = readList("recents")
    fun pushRecent(b: BlockState): List<BlockState> {
        val l = (listOf(b) + recents().filter { it != b }).take(24)
        writeList("recents", l); return l
    }

    fun customs(): List<BlockState> = readList("customs")
    fun addCustom(b: BlockState): List<BlockState> {
        val l = (customs().filter { it != b } + b)
        writeList("customs", l); return l
    }
    fun removeCustom(b: BlockState): List<BlockState> {
        val l = customs().filter { it != b }
        writeList("customs", l); return l
    }

    // ---- hotbar (9 slots, empty slot = blank line) ---------------------------------------------
    fun hotbar(): List<BlockState?> {
        val raw = sp.getString("hotbar", null)
        val defaults = listOf("stone", "dirt", "cobblestone", "oak_planks", "glass", "white_wool", "sand", "oak_log", "brick_block")
            .map { BlockState("minecraft:$it") }
        if (raw == null) return defaults
        val parts = raw.split('\n')
        return List(9) { i -> parts.getOrNull(i)?.takeIf { it.isNotBlank() }?.let { BlockState.deserialize(it) } }
    }

    fun saveHotbar(h: List<BlockState?>) {
        sp.edit().putString("hotbar", h.joinToString("\n") { it?.serialize() ?: "" }).apply()
    }

    var hotbarSlot: Int
        get() = sp.getInt("hotbarSlot", 0).coerceIn(0, 8)
        set(v) { sp.edit().putInt("hotbarSlot", v).apply() }

    // ---- palette ---------------------------------------------------------------------------------
    fun palette(): List<PaletteEntry> =
        (sp.getString("palette", "") ?: "").split('\n').mapNotNull { line ->
            val i = line.indexOf('#')
            if (i <= 0) null else {
                val w = line.substring(0, i).toIntOrNull() ?: 1
                BlockState.deserialize(line.substring(i + 1))?.let { PaletteEntry(it, w.coerceIn(1, 20)) }
            }
        }

    fun savePalette(p: List<PaletteEntry>) {
        sp.edit().putString("palette", p.joinToString("\n") { "${it.weight}#${it.block.serialize()}" }).apply()
    }

    // ---- HUD layout ----------------------------------------------------------------------------------
    fun hudConfig(): Map<HudElement, HudConfig> = HudElement.values().associateWith {
        HudConfig(sp.getFloat("hud_${it.name}_dx", 0f), sp.getFloat("hud_${it.name}_dy", 0f), sp.getFloat("hud_${it.name}_s", 1f))
    }

    fun saveHud(e: HudElement, c: HudConfig) {
        sp.edit().putFloat("hud_${e.name}_dx", c.dx).putFloat("hud_${e.name}_dy", c.dy).putFloat("hud_${e.name}_s", c.scale).apply()
    }
}
