package com.bedrockbuilder.data

import android.content.Context
import com.bedrockbuilder.core.BlockState

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("bedrock_builder", Context.MODE_PRIVATE)

    var autoExpand: Boolean
        get() = sp.getBoolean("autoExpand", true)
        set(v) { sp.edit().putBoolean("autoExpand", v).apply() }

    var showOutlines: Boolean
        get() = sp.getBoolean("outlines", true)
        set(v) { sp.edit().putBoolean("outlines", v).apply() }

    private fun readList(key: String): List<BlockState> =
        (sp.getString(key, "") ?: "").split('\n').mapNotNull { if (it.isBlank()) null else BlockState.deserialize(it) }

    private fun writeList(key: String, list: List<BlockState>) {
        sp.edit().putString(key, list.joinToString("\n") { it.serialize() }).apply()
    }

    fun recents(): List<BlockState> = readList("recents")
    fun pushRecent(b: BlockState): List<BlockState> {
        val l = (listOf(b) + recents().filter { it != b }).take(24)
        writeList("recents", l); return l
    }

    fun customs(): List<BlockState> = readList("customs")
    fun addCustom(b: BlockState): List<BlockState> {
        val l = (customs().filter { it != b } + b)
        writeList("customs", l); return l
    }
    fun removeCustom(b: BlockState): List<BlockState> {
        val l = customs().filter { it != b }
        writeList("customs", l); return l
    }
}
