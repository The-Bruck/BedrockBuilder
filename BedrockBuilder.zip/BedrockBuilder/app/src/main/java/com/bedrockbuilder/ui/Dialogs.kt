package com.bedrockbuilder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import com.bedrockbuilder.core.BuildModel
import com.bedrockbuilder.data.HudConfig
import com.bedrockbuilder.data.HudElement
import kotlin.math.roundToInt
import androidx.compose.ui.unit.dp
import java.io.File

@Composable
fun SettingRow(title: String, sub: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = value, onCheckedChange = onChange)
    }
}

private val BG_PRESETS = listOf(
    0xFF1C2532, 0xFF000000, 0xFF2B2B2B, 0xFF6B7280, 0xFFD9DEE5, 0xFFFFFFFF,
    0xFF87CEEB, 0xFF3B6E2E, 0xFF3A2A5C, 0xFF5A3A22,
).map { it.toInt() }

@Composable
fun ColorPicker(color: Int, onChange: (Int) -> Unit) {
    val r = (color shr 16) and 255; val g = (color shr 8) and 255; val b = color and 255
    fun make(rr: Int, gg: Int, bb: Int) = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BG_PRESETS.forEach { c ->
                Box(
                    Modifier.size(28.dp).background(Color(c), CircleShape)
                        .border(if (c == color) 3.dp else 1.dp, if (c == color) MaterialTheme.colorScheme.primary else Color(0x66888888), CircleShape)
                        .clickable { onChange(c) }
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        listOf(Triple("R", r, 0), Triple("G", g, 1), Triple("B", b, 2)).forEach { (label, v, ch) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, Modifier.width(18.dp))
                Slider(
                    value = v.toFloat(), valueRange = 0f..255f,
                    onValueChange = {
                        val n = it.toInt()
                        onChange(when (ch) { 0 -> make(n, g, b); 1 -> make(r, n, b); else -> make(r, g, n) })
                    },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
fun SettingsDialog(vm: EditorViewModel, onCustomizeUi: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SettingRow("Block outlines", "Draw edges on blocks when zoomed in", vm.showOutlines) { vm.updateShowOutlines(it) }
                Text("Background colour", style = MaterialTheme.typography.titleSmall)
                ColorPicker(vm.background) { vm.updateBackground(it) }
                Text("On-screen controls", style = MaterialTheme.typography.titleSmall)
                OutlinedButton(onClick = onCustomizeUi) { Text("Customize UI layout (move / resize)") }
                Text(
                    if (vm.textures?.hasVanilla == true) "Block textures: all assets are owned by Mojang."
                    else "Vanilla textures are not installed in this build, so blocks use flat colours. All Minecraft assets are owned by Mojang.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

/** Structure settings: the grid only changes size when you press a button here. */
@Composable
fun StructureDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val m = vm.model
    var sx by remember { mutableStateOf(m.sizeX.toString()) }
    var sy by remember { mutableStateOf(m.sizeY.toString()) }
    var sz by remember { mutableStateOf(m.sizeZ.toString()) }
    val rev = vm.revision
    LaunchedEffect(rev) { sx = m.sizeX.toString(); sy = m.sizeY.toString(); sz = m.sizeZ.toString() }

    @Composable
    fun sideRow(label: String, axis: Int, high: Boolean) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f))
            OutlinedButton(onClick = { vm.resizeSide(axis, high, -1) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("−1") }
            Spacer(Modifier.width(6.dp))
            Button(onClick = { vm.resizeSide(axis, high, 1) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("+1") }
            Spacer(Modifier.width(6.dp))
            Button(onClick = { vm.resizeSide(axis, high, 8) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("+8") }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Structure settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Size: ${m.sizeX} × ${m.sizeY} × ${m.sizeZ} (X × Y × Z)", style = MaterialTheme.typography.titleSmall)
                Text("The grid never resizes by itself. Set the size you want and press Apply. Max ${BuildModel.MAX_AXIS} per axis. " +
                    "Shrinking never removes blocks.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(Triple("X", sx, { v: String -> sx = v }), Triple("Y", sy, { v: String -> sy = v }), Triple("Z", sz, { v: String -> sz = v }))
                        .forEach { (l, v, set) ->
                            OutlinedTextField(v, { set(it.filter(Char::isDigit).take(3)) }, Modifier.weight(1f), singleLine = true,
                                label = { Text(l) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.setGridSize(sx.toIntOrNull() ?: 1, sy.toIntOrNull() ?: 1, sz.toIntOrNull() ?: 1) }) { Text("Apply size") }
                    OutlinedButton(onClick = { vm.fitGridToBlocks() }) { Text("Fit to blocks") }
                }
                if (m.sizeX > 64 || m.sizeY > 64 || m.sizeZ > 64)
                    Text("Note: in-game structure blocks only handle up to 64 per axis.", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.tertiary)
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                Text("Resize one side", style = MaterialTheme.typography.titleSmall)
                sideRow("West  (−X)", 0, false); sideRow("East  (+X)", 0, true)
                sideRow("Down  (−Y)", 1, false); sideRow("Up  (+Y)", 1, true)
                sideRow("North (−Z)", 2, false); sideRow("South (+Z)", 2, true)
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                SettingRow("Empty cells as air", "On: loading the structure clears existing blocks in its area. Off: keeps them.",
                    vm.emptyAsAir) { vm.updateEmptyAsAir(it) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.rotateStructure(true) }) { Text("Rotate ↻ 90°") }
                    OutlinedButton(onClick = { vm.rotateStructure(false) }) { Text("Rotate ↺ 90°") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

/** Shown while customising the HUD: pick an element, drag it on screen to move it, use the slider to resize it. */
@Composable
fun HudEditPanel(vm: EditorViewModel, modifier: Modifier = Modifier) {
    val el = vm.hudSelected
    val cfg = vm.hudConfig[el] ?: HudConfig()
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), tonalElevation = 8.dp) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Customize UI", style = MaterialTheme.typography.titleMedium)
            Text("Drag a highlighted element to move it. Choose one below to resize it.", style = MaterialTheme.typography.bodySmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                HudElement.values().forEach { e ->
                    FilterChip(selected = el == e, onClick = { vm.hudSelected = e }, label = { Text(e.label) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Size ${(cfg.scale * 100).roundToInt()}%", Modifier.width(88.dp), style = MaterialTheme.typography.labelLarge)
                Slider(
                    value = cfg.scale.coerceIn(el.minScale, el.maxScale), onValueChange = { vm.scaleHud(el, it) },
                    valueRange = el.minScale..el.maxScale, modifier = Modifier.weight(1f),
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.resetHud() }) { Text("Reset layout") }
                Button(onClick = { vm.hudEdit = false }) { Text("Done") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaletteSheet(vm: EditorViewModel, onAddBlocks: () -> Unit, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxHeight(0.85f).padding(horizontal = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Palette", style = MaterialTheme.typography.titleMedium)
                    Text("Each placed block is picked at random from this list. Higher weight = more often.",
                        style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = vm.paletteMode, onCheckedChange = { vm.paletteMode = it })
            }
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onAddBlocks) { Text("Add blocks") }
                OutlinedButton(onClick = { vm.addHotbarToPalette() }) { Text("Add hotbar") }
                TextButton(onClick = { vm.clearPalette() }, enabled = vm.palette.isNotEmpty()) { Text("Clear") }
            }
            if (vm.palette.isEmpty()) Text("The palette is empty. Add some blocks, then turn the palette on.", Modifier.padding(8.dp))
            val total = vm.palette.sumOf { it.weight }.coerceAtLeast(1)
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(vm.palette) { i, e ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        BlockIcon(vm.textures, e.block.name)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(e.block.shortName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${e.weight * 100 / total}%", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        OutlinedButton(onClick = { vm.setPaletteWeight(i, e.weight - 1) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("−") }
                        Text("${e.weight}", Modifier.padding(horizontal = 10.dp))
                        OutlinedButton(onClick = { vm.setPaletteWeight(i, e.weight + 1) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("+") }
                        IconButton(onClick = { vm.removeFromPalette(i) }) { Icon(Icons.Default.Close, "Remove") }
                    }
                }
            }
            Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) { Text("Done") }
        }
    }
}

@Composable
fun PacksDialog(vm: EditorViewModel, onImport: () -> Unit, onDismiss: () -> Unit) {
    val ts = vm.textures
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Packs for this structure") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Import .mcpack / .mcaddon files. Custom blocks they define, with their textures, can be used in this structure only. " +
                    "Packs are removed when the structure is deleted.", style = MaterialTheme.typography.bodySmall)
                Button(onClick = onImport) { Text("Import .mcpack / .mcaddon") }
                if (vm.packFiles.isEmpty()) Text("No packs imported yet.")
                vm.packFiles.forEach { f: File ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(f.name.substringAfter('_'), Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        TextButton(onClick = { vm.removePack(f) }) { Text("Remove") }
                    }
                }
                if (ts != null && ts.packBlocks.isNotEmpty()) {
                    Text("${ts.packBlocks.size} custom blocks: " + ts.packBlocks.take(12).joinToString(", ") { it.id.substringAfter(':') } +
                        if (ts.packBlocks.size > 12) " …" else "", style = MaterialTheme.typography.bodySmall)
                    Text("Find them in the block picker under \"Packs\".", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}
