# Bedrock Builder

Offline Minecraft Bedrock structure editor for Android (Kotlin, Jetpack Compose, Material 3). No internet permission.

All Minecraft assets (block textures) are owned by Mojang.

## Build the APK
**GitHub (no setup):** push this project as `BedrockBuilder.zip` plus `.github/workflows/build-apk.yml`; the *Build APK* workflow
unzips it, downloads Mojang's public `bedrock-samples` resource pack, builds a texture atlas with `tools/make_textures.py`
(into `app/src/main/assets`) and builds the APK. If the texture step fails the app still builds and uses flat colours.
**Android Studio:** open the folder, run `python3 tools/make_textures.py <bedrock-samples checkout> app/src/main/assets`
(optional, enables textures), then *Build > Build APK(s)*.

## Using it
- **Dock (bottom):** the 9-slot hotbar is always visible; four tabs share one panel - **Tool** (Place/Destroy/Replace/Rotate/Pick),
  **Shape** (Single, Box, Sphere, Dome, Cylinder, Pyramid, Line, Flood fill, Hollow), **Blocks** (picker, random palette, packs) and
  **View** (presets, zoom, lock, slice, grid). Tap the active tab to collapse the panel. **Hide UI** (top bar) hides every control;
  tap **Show UI** to bring them back.
- **Hotbar:** tap a slot to select it; tap the selected slot (or long-press any slot) to choose its block.
- **Palette:** turn on *Random palette* (Blocks tab), add any number of blocks (with weights); Place/Replace then picks randomly per block.
- **Rotate tool:** rotates a block's orientation (stairs, logs, doors, chests, rails...) in the selected shape; menu has *Rotate structure 90°*.
- **Grid:** *Dynamic grid* (Settings) grows/shrinks around your build and exports cropped; or size it manually (menu > Grid size).
  Yellow plane = active layer. Drag = rotate, pinch = zoom, two fingers = pan, **Lock** freezes the view.
- **Background colour:** Settings.
- **Packs:** menu > *Packs*, the Blocks tab, or the picker's *Packs* tab imports `.mcpack` / `.mcaddon`. Custom blocks (and their textures) become available in that structure only,
  under the picker's *Packs* tab; they are deleted together with the structure.
- Structures autosave as real `.mcstructure` files; Export/Share/Import via the file picker. Deleting a structure removes it completely,
  so a new structure with the same name starts empty.

## Dev
`tools/selftest` has a JVM self-test (NBT, structures, shapes, palette, rotation, packs, picking, textured render) and
`verify_mcstructure.py`. `tools/make_block_ids.py` regenerates the block id list from `blocks.json`.
