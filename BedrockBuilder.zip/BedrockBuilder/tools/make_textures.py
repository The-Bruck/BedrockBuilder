#!/usr/bin/env python3
"""
Builds the block texture atlas used by Bedrock Builder from Mojang's public
bedrock-samples resource pack.  All textures are owned by Mojang.

usage: make_textures.py <bedrock-samples checkout> <output assets dir>
Writes <out>/atlas.png (16px cells, 64 columns, cell 0 = solid white) and
<out>/block_textures.txt  ("name east west up down south north", each "cell" or "cell:tint").
Also writes <out>/block_ids.txt (all block ids found in blocks.json).
"""
import json, os, re, sys
from PIL import Image

CELL, COLS = 16, 64
TINT = {"none": 0, "grass": 1, "foliage": 2, "water": 3, "spruce": 4, "birch": 5, "lily": 6}

def load_json(p):
    t = open(p, encoding="utf-8").read()
    t = re.sub(r"^\s*//.*$", "", t, flags=re.M)
    return json.loads(t)

def main(src, out):
    rp = os.path.join(src, "resource_pack")
    blocks = load_json(os.path.join(rp, "blocks.json"))
    terrain = load_json(os.path.join(rp, "textures", "terrain_texture.json"))["texture_data"]

    def find_file(path):
        base = os.path.join(rp, path)
        for ext in (".png", ".tga"):
            if os.path.exists(base + ext):
                return base + ext
        return None

    def resolve_key(key):
        """terrain_texture key -> texture path (prefers opaque variants)."""
        e = terrain.get(key)
        if not e:
            return None
        t = e["textures"]
        items = t if isinstance(t, list) else [t]
        paths = []
        for i in items:
            p = i["path"] if isinstance(i, dict) else i
            if find_file(p):
                paths.append(p)
                if isinstance(i, dict) and "overlay_color" in i:
                    overlays[p] = "#79c05a"   # alpha of these textures marks the tintable grass overlay
        if not paths:
            return None
        for p in paths:
            if p.endswith("_opaque"):
                return p
        return paths[0]

    def tint_for(path):
        n = os.path.basename(path)
        if n in ("grass_top", "grass_carried") or n.startswith("short_grass") or n.startswith("tall_grass") \
                or n.startswith("fern") or n.startswith("large_fern") or n.startswith("double_plant_grass") \
                or n.startswith("double_plant_fern") or n.startswith("tallgrass") or n == "reeds" or n.startswith("sugarcane"):
            return TINT["grass"]
        if n.startswith("leaves_spruce"): return TINT["spruce"]
        if n.startswith("leaves_birch"): return TINT["birch"]
        if n in ("leaves_oak_opaque", "leaves_jungle_opaque", "leaves_acacia_opaque", "leaves_big_oak_opaque",
                 "leaves_mangrove_opaque") or (n.startswith("leaves_") and "azalea" not in n and "cherry" not in n
                 and "pale" not in n and "flowering" not in n):
            return TINT["foliage"]
        if n.startswith("vine"): return TINT["foliage"]
        if n.startswith("waterlily"): return TINT["lily"]
        if "water" in n and "grey" in n: return TINT["water"]
        return TINT["none"]

    overlays = {}       # texture path -> overlay colour to bake in
    cells = {}          # texture path -> cell index
    images = [Image.new("RGBA", (CELL, CELL), (255, 255, 255, 255))]  # cell 0 = white

    def cell_for(path):
        if path in cells:
            return cells[path]
        f = find_file(path)
        if not f:
            return None
        im = Image.open(f).convert("RGBA")
        if path in overlays:
            col = overlays[path].lstrip("#")
            tr, tg, tb = (int(col[i:i + 2], 16) for i in (0, 2, 4))
            px = im.load()
            for yy in range(im.size[1]):
                for xx in range(im.size[0]):
                    r, g, b, a = px[xx, yy]
                    px[xx, yy] = (r * tr // 255, g * tg // 255, b * tb // 255, 255) if a > 0 else (r, g, b, 255)
        w = im.size[0]
        im = im.crop((0, 0, w, min(w, im.size[1])))   # first frame of animated strips
        if im.size != (CELL, CELL):
            im = im.resize((CELL, CELL), Image.NEAREST)
        # the grass side texture ships as a dirt block + separate overlay in alpha; keep as is.
        images.append(im)
        cells[path] = len(images) - 1
        return cells[path]

    DIRS = ["east", "west", "up", "down", "south", "north"]
    lines = []
    for name, entry in blocks.items():
        if name == "format_version" or not isinstance(entry, dict):
            continue
        tex = entry.get("textures")
        if tex is None:
            continue
        faces = {}
        if isinstance(tex, str):
            faces = {d: tex for d in DIRS}
        else:
            side = tex.get("side")
            for d in DIRS:
                faces[d] = tex.get(d) or (side if d in ("east", "west", "south", "north") else None) \
                    or tex.get("up") or tex.get("down") or side
        out_faces = []
        for d in DIRS:
            key = faces.get(d)
            path = resolve_key(key) if key else None
            c = cell_for(path) if path else None
            out_faces.append("-1" if c is None else f"{c}:{tint_for(path)}")
        if all(f == "-1" for f in out_faces):
            continue
        lines.append(name + " " + " ".join(out_faces))

    os.makedirs(out, exist_ok=True)
    rows = (len(images) + COLS - 1) // COLS
    atlas = Image.new("RGBA", (COLS * CELL, rows * CELL), (0, 0, 0, 0))
    for i, im in enumerate(images):
        atlas.paste(im, ((i % COLS) * CELL, (i // COLS) * CELL))
    atlas.save(os.path.join(out, "atlas.png"))
    open(os.path.join(out, "block_textures.txt"), "w").write("\n".join(sorted(lines)) + "\n")
    ids = sorted(k for k in blocks if k != "format_version")
    open(os.path.join(out, "block_ids.txt"), "w").write("\n".join(ids) + "\n")
    print(f"atlas {atlas.size}, {len(images)} textures, {len(lines)} blocks mapped")

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
