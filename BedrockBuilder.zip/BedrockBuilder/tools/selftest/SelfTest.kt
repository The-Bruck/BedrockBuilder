import com.bedrockbuilder.core.*
import java.io.File

var failures = 0
fun check(c: Boolean, msg: String) { if (!c) { failures++; println("FAIL: $msg") } else println("ok:   $msg") }

fun main(args: Array<String>) {
    val out = args.getOrElse(0) { "/tmp/out" }
    // --- build a structure and round trip ---
    val m = BuildModel.create(5, 4, 6)
    val s = EditSession(m)
    val stone = BlockState("minecraft:stone")
    val stairs = BlockState("minecraft:oak_stairs", mapOf("weirdo_direction" to 2, "upside_down_bit" to true))
    s.apply(Op.PLACE, ShapeKind.BOX, intArrayOf(0, 0, 0), intArrayOf(4, 0, 5), false, SingleBlock(stone), false)
    s.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(2, 1, 3), intArrayOf(2, 1, 3), false, SingleBlock(stairs), false)
    check(m.blockCount == 5 * 6 + 1, "box+single count ${m.blockCount}")
    val bytes = McStructure.write(m, false)
    File("$out/test.mcstructure").writeBytes(bytes)
    val r = McStructure.read(bytes)
    check(r.sizeX == 5 && r.sizeY == 4 && r.sizeZ == 6, "size roundtrip")
    check(r.blockCount == m.blockCount, "blocks roundtrip")
    check(r.get(2, 1, 3) == stairs, "stairs state roundtrip: ${r.get(2, 1, 3)}")
    check(r.get(4, 0, 5) == stone, "corner stone")
    check(r.get(0, 1, 0) == null, "empty stays empty")
    val air = McStructure.write(m, true)
    check(McStructure.read(air).emptyAsAir, "air mode detected")
    check(McStructure.read(air).blockCount == m.blockCount, "air not counted as block")

    // --- negative expansion & export normalisation ---
    val m2 = BuildModel.create(2, 2, 2)
    val s2 = EditSession(m2)
    s2.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(-3, 0, 0), intArrayOf(-3, 0, 0), false, SingleBlock(stone), true)
    check(m2.minX == -3 && m2.sizeX == 5, "grid expanded west: ${m2.minX}..${m2.maxX}")
    val r2 = McStructure.read(McStructure.write(m2, false))
    check(r2.get(0, 0, 0) == stone, "shifted to origin on export")
    check(s2.undo() && m2.blockCount == 0, "undo")
    check(s2.redo() && m2.blockCount == 1, "redo")

    // --- shapes ---
    val buf = LongBuf()
    Shapes.generate(ShapeKind.SPHERE, intArrayOf(10, 10, 10), intArrayOf(15, 10, 10), false, buf)
    check(buf.size in 700..780, "filled sphere r5 cells=${buf.size}")
    val hb = LongBuf()
    Shapes.generate(ShapeKind.SPHERE, intArrayOf(10, 10, 10), intArrayOf(15, 10, 10), true, hb)
    check(hb.size in 150..350 && hb.size < buf.size, "hollow sphere cells=${hb.size}")
    val box = LongBuf(); Shapes.generate(ShapeKind.BOX, intArrayOf(0, 0, 0), intArrayOf(4, 4, 4), true, box)
    check(box.size == 125 - 27, "hollow box 5^3 = 98, got ${box.size}")
    val ln = LongBuf(); Shapes.generate(ShapeKind.LINE, intArrayOf(0, 0, 0), intArrayOf(10, 5, 0), false, ln)
    check(ln.size == 11, "line cells ${ln.size}")
    val pyr = LongBuf(); Shapes.generate(ShapeKind.PYRAMID, intArrayOf(0, 0, 0), intArrayOf(8, 4, 8), false, pyr)
    check(pyr.size == 81 + 49 + 25 + 9 + 1, "pyramid cells ${pyr.size}")
    val cyl = LongBuf(); Shapes.generate(ShapeKind.CYLINDER, intArrayOf(5, 0, 5), intArrayOf(8, 2, 5), false, cyl)
    check(cyl.size in 100..150, "cylinder r3 h3 cells=${cyl.size}")
    val dome = LongBuf(); Shapes.generate(ShapeKind.DOME, intArrayOf(0, 0, 0), intArrayOf(5, 0, 0), false, dome)
    check(dome.size < buf.size && dome.size > 200, "dome cells ${dome.size}")

    // --- flood fill / destroy / replace ---
    val m3 = BuildModel.create(6, 6, 6); val s3 = EditSession(m3)
    s3.apply(Op.PLACE, ShapeKind.FLOOD, intArrayOf(0, 0, 0), intArrayOf(0, 0, 0), false, SingleBlock(stone), false)
    check(m3.blockCount == 216, "flood fill whole grid ${m3.blockCount}")
    val dirt = BlockState("minecraft:dirt")
    s3.apply(Op.REPLACE, ShapeKind.BOX, intArrayOf(0, 0, 0), intArrayOf(5, 1, 5), false, SingleBlock(dirt), false)
    check(m3.get(0, 1, 0) == dirt && m3.get(0, 2, 0) == stone, "replace box")
    s3.apply(Op.DESTROY, ShapeKind.SPHERE, intArrayOf(3, 3, 3), intArrayOf(5, 3, 3), false, SingleBlock(dirt), false)
    check(m3.blockCount < 216 - 50, "destroy sphere ${m3.blockCount}")
    check(s3.undo() && s3.undo() && s3.undo() && m3.blockCount == 0, "undo x3")

    // --- camera / picking ---
    val m4 = BuildModel.create(10, 10, 10); val s4 = EditSession(m4)
    s4.apply(Op.PLACE, ShapeKind.BOX, intArrayOf(0, 0, 0), intArrayOf(9, 2, 9), false, SingleBlock(stone), false)
    s4.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(4, 3, 4), intArrayOf(4, 3, 4), false, SingleBlock(dirt), false)
    for ((yaw, pitch) in listOf(35f to 30f, 200f to 50f, -70f to 20f, 0f to 89f)) {
        val cam = Camera.fit(m4, yaw, pitch)
        val w = 1080f; val h = 1800f
        val pj = Projector(cam, w, h)
        val o = FloatArray(2)
        pj.project(4.5f, 3.5f, 4.5f, o, 0)
        val p = Picker.pick(m4, cam, w, h, o[0], o[1], 0, false, 0)
        check(p != null && p.hit && p.bx == 4 && p.by == 3 && p.bz == 4, "pick single block yaw=$yaw pitch=$pitch -> ${p?.let { "${it.bx},${it.by},${it.bz}" }}")
        pj.project(1.5f, 3.0f, 1.5f, o, 0)  // top surface of the slab layer
        val q = Picker.pick(m4, cam, w, h, o[0], o[1], 0, false, 0)
        check(q != null && q.hit && q.by == 2 && q.ny == 1 && q.nx == 0 && q.nz == 0, "pick top face normal yaw=$yaw: ${q?.let { "${it.bx},${it.by},${it.bz} n=${it.nx},${it.ny},${it.nz}" }}")
    }
    // plane pick on empty cell
    val cam = Camera.fit(m4, 35f, 40f); val pj = Projector(cam, 1080f, 1800f); val o = FloatArray(2)
    pj.project(8.5f, 6.0f, 8.5f, o, 0)
    val pl = Picker.pick(m4, cam, 1080f, 1800f, o[0], o[1], 6, false, 0)
    check(pl != null && !pl.hit && pl.hasPlane && pl.px == 8 && pl.py == 6 && pl.pz == 8, "plane pick")

    // --- mesh + render ---
    val mesh = MeshBuilder.build(m4, false, 0)
    // 10x10x3 slab: top 100 + 4 sides (10*3 each) = 100+120 +1 bottom 100 = 320, plus single block 5 faces (bottom hidden)
    check(mesh.count == 99 + 100 + 120 + 5, "mesh faces ${mesh.count}")
    val fr = FrameRenderer(); var quads = 0
    val drawn = fr.render(mesh, Camera.fit(m4), 1080f, 1800f, true) { quads += it }
    check(drawn in 100..250 && quads == drawn * 2, "render drawn=$drawn quads=$quads")

    // --- state parsing ---
    check(BlockState.parseStates("a=1, b=true,c=foo") == mapOf("a" to 1, "b" to true, "c" to "foo"), "parse states")
    check(BlockState.parseStates("bad") == null, "reject bad states")
    check(BlockRegistry.all.size > 900, "registry size ${BlockRegistry.all.size}")
    check(BlockRegistry.all.toSet().size == BlockRegistry.all.size, "no duplicate ids")
    println("registry: ${BlockRegistry.all.size} ids")
    extraTests(out)
    println(if (failures == 0) "ALL PASSED" else "$failures FAILED")
    if (failures > 0) System.exit(1)
}


fun extraTests(out: String) {
    val stone = BlockState("minecraft:stone"); val dirt = BlockState("minecraft:dirt")
    // palette randomisation
    val m = BuildModel.create(20, 4, 20); val s = EditSession(m)
    val blocks = listOf(BlockState("minecraft:stone"), BlockState("minecraft:dirt"), BlockState("minecraft:gravel"))
    s.apply(Op.PLACE, ShapeKind.BOX, intArrayOf(0, 0, 0), intArrayOf(19, 0, 19), false,
        WeightedPalette(blocks, listOf(1, 1, 2), java.util.Random(7)), false)
    val counts = HashMap<String, Int>()
    for (x in 0..19) for (z in 0..19) counts.merge(m.get(x, 0, z)!!.shortName, 1, Int::plus)
    check(counts.size == 3 && counts.values.sum() == 400, "palette uses all blocks $counts")
    check((counts["gravel"] ?: 0) > (counts["stone"] ?: 0), "weights respected $counts")
    // replace with palette only touches existing blocks
    val r = s.apply(Op.REPLACE, ShapeKind.BOX, intArrayOf(0, 0, 0), intArrayOf(19, 1, 19), false,
        WeightedPalette(listOf(BlockState("minecraft:glass"), BlockState("minecraft:sand")), listOf(1, 1)), false)
    check(m.get(3, 1, 3) == null && r.changed == 400 && m.blockCount == 400, "palette replace only existing")

    // rotate op + structure rotate
    val m2 = BuildModel.create(4, 2, 3); val s2 = EditSession(m2)
    val st = BlockState("minecraft:oak_stairs", mapOf("weirdo_direction" to 0, "upside_down_bit" to false))
    val log = BlockState("minecraft:oak_log", mapOf("pillar_axis" to "x"))
    s2.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(0, 0, 0), intArrayOf(0, 0, 0), false, SingleBlock(st), false)
    s2.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(1, 0, 0), intArrayOf(1, 0, 0), false, SingleBlock(log), false)
    s2.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(2, 0, 0), intArrayOf(2, 0, 0), false, SingleBlock(stone), false)
    s2.apply(Op.ROTATE, ShapeKind.BOX, intArrayOf(0, 0, 0), intArrayOf(3, 1, 2), false, SingleBlock(stone), false, 1)
    check(m2.get(0, 0, 0)!!.states["weirdo_direction"] == 2, "stairs east->south")
    check(m2.get(1, 0, 0)!!.states["pillar_axis"] == "z", "log axis x->z")
    check(m2.get(2, 0, 0) == stone, "stone untouched")
    s2.apply(Op.ROTATE, ShapeKind.SINGLE, intArrayOf(0, 0, 0), intArrayOf(0, 0, 0), false, SingleBlock(stone), false, -1)
    check(m2.get(0, 0, 0)!!.states["weirdo_direction"] == 0, "ccw restores")
    val msg = s2.apply(Op.ROTATE, ShapeKind.SINGLE, intArrayOf(2, 0, 0), intArrayOf(2, 0, 0), false, SingleBlock(stone), false, 1)
    check(msg.changed == 0 && msg.message != null, "rotate stone gives message")
    StructureTransform.rotateY(m2, true)   // 4x2x3 -> 3x2x4
    check(m2.sizeX == 3 && m2.sizeZ == 4, "rotated size ${m2.sizeX}x${m2.sizeZ}")
    check(m2.get(2, 0, 0)?.shortName == "oak_stairs", "block (0,0,0) -> (2,0,0): ${m2.get(2, 0, 0)}")
    check(m2.get(2, 0, 1)?.shortName == "oak_log" && m2.get(2, 0, 2) == stone, "line of blocks follows rotation")
    StructureTransform.rotateY(m2, false)
    check(m2.sizeX == 4 && m2.get(0, 0, 0)?.shortName == "oak_stairs" && m2.get(2, 0, 0) == stone, "rotate back")

    // dynamic grid + crop export
    val m3 = BuildModel.create(32, 32, 32); val s3 = EditSession(m3)
    s3.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(10, 5, 10), intArrayOf(10, 5, 10), false, SingleBlock(stone), true)
    m3.applyDynamicBounds()
    check(m3.sizeX in 8..12 && m3.sizeY in 8..12 && m3.inBounds(10, 5, 10), "dynamic shrink ${m3.sizeX}x${m3.sizeY}x${m3.sizeZ}")
    s3.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(40, 5, 10), intArrayOf(40, 5, 10), false, SingleBlock(stone), true)
    m3.applyDynamicBounds()
    check(m3.inBounds(40, 5, 10) && m3.inBounds(10, 5, 10), "dynamic grow")
    val rc = McStructure.read(McStructure.write(m3, false, crop = true))
    check(rc.sizeX == 31 && rc.sizeY == 1 && rc.sizeZ == 1 && rc.blockCount == 2, "cropped export ${rc.sizeX}x${rc.sizeY}x${rc.sizeZ}")

    // packs
    val set = PackScanner.scanAll(listOf(java.io.File("$out/test.mcaddon").readBytes()))
    println("packs: ${set.packNames} blocks: ${set.blocks.map { it.id }} textures: ${set.textures.keys}")
    val ruby = set.blocks.firstOrNull { it.id == "my_pack:ruby_block" }
    check(ruby != null && ruby.facePaths[2] == "textures/blocks/ruby_top" && ruby.facePaths[4] == "textures/blocks/ruby_side", "behavior block faces")
    check(ruby != null && ruby.states["my_pack:power"] == listOf(0, 1, 2) && ruby.states["my_pack:lit"] == listOf(false, true) && ruby.states["my_pack:level"] == listOf(0, 1, 2, 3), "block states ${ruby?.states}")
    check(set.blocks.any { it.id == "my_pack:emerald_block" && it.facePaths.all { p -> p == "textures/blocks/emerald" } }, "variations + tga texture")
    check(set.blocks.any { it.id == "my_pack:legacy_gem" && it.facePaths[2] == "textures/blocks/ruby_top" }, "legacy blocks.json block")
    check(set.textures["textures/blocks/emerald"]?.ext == "tga", "tga detected")
    val tga = TgaDecoder.decode(set.textures.getValue("textures/blocks/emerald").bytes)
    check(tga != null && tga.width == 16 && (tga.argb[0] and 0xFFFFFF) == 0x14C83C, "tga decode ${tga?.argb?.get(0)?.toString(16)}")
    val txt = set.mapText { if (it.endsWith("ruby_top")) 5 else 6 }
    check(txt.contains("my_pack:ruby_block 6:0 6:0 5:0 5:0 6:0 6:0"), "map text: " + txt.lines().first())
    check(try { PackScanner.scanAll(listOf(byteArrayOf(1, 2, 3))); false } catch (e: PackException) { true }, "bad archive rejected")

    // flat addon (folders, no terrain_texture.json, direct texture paths)
    val flat = PackScanner.scanAll(listOf(java.io.File("$out/flat.mcaddon").readBytes()))
    check(flat.blocks.map { it.id }.sorted() == listOf("flat:lamp", "flat:marble"), "flat addon blocks ${flat.blocks.map { it.id }}")
    check(flat.blocks.all { b -> b.facePaths.all { it != null } }, "flat addon textures resolved")
    // two separately imported archives resolve together (BP in one file, RP in another)
    val both = PackScanner.scanAll(listOf(java.io.File("$out/test.mcaddon").readBytes(), java.io.File("$out/flat.mcaddon").readBytes()))
    check(both.blocks.size == 5 && both.packNames.size == 4, "multiple archives ${both.blocks.size} ${both.packNames}")
    // pack textures merged into the vanilla map keep vanilla entries and add custom ids
    val vmap = TextureMap.parse(java.io.File("$out/assets/block_textures.txt").readText())
    val before = vmap.entry("minecraft:stone")!!.cells[0]
    val idx = HashMap<String, Int>(); both.textures.keys.forEachIndexed { i, p -> idx[p] = vmap.addPackRect(0, 256 + 64 * i, 64, 64) }
    vmap.merge(TextureMap.parse(both.mapText { idx[it] }))
    check(vmap.entry("minecraft:stone")!!.cells[0] == before && vmap.entry("my_pack:ruby_block")!!.cells[2] >= TextureMap.PACK_BASE && vmap.entry("flat:lamp") != null, "merged texture map")
    check(vmap.rect(vmap.entry("my_pack:ruby_block")!!.cells[2])[3] == 64, "pack rect size")

    // first-person camera
    run {
        val mm = BuildModel.create(10, 6, 10); val ss = EditSession(mm)
        ss.apply(Op.PLACE, ShapeKind.BOX, intArrayOf(0, 0, 0), intArrayOf(9, 0, 9), false, SingleBlock(BlockState("minecraft:stone")), false)
        ss.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(5, 2, 2), intArrayOf(5, 2, 2), false, SingleBlock(BlockState("minecraft:dirt")), false)
        val orbit = Camera.fit(mm, 35f, 30f)
        val fp = orbit.toFirstPerson()
        val po = Projector(orbit, 1080f, 1800f); val pf = Projector(fp.copy(fp = true), 1080f, 1800f)
        val a = FloatArray(2); val b = FloatArray(2)
        po.project(5.5f, 2.5f, 2.5f, a, 0); pf.project(5.5f, 2.5f, 2.5f, b, 0)
        check(Math.abs(a[0] - b[0]) < 12f && Math.abs(a[1] - b[1]) < 12f || fp.focal(1080f, 1800f) != orbit.focal(1080f, 1800f), "fp starts at the orbit viewpoint")
        val eye = Camera(yaw = 0f, pitch = 0f, tx = 5.5f, ty = 2.5f, tz = 8f, fp = true)
        val w1 = eye.walk(1f, 0f, 0f); val w2 = eye.walk(0f, 1f, 0f); val w3 = eye.walk(0f, 0f, 2f)
        check(w1.tz == 7f && w1.tx == 5.5f, "forward at yaw 0 goes north: ${w1.tx},${w1.tz}")
        check(w2.tx == 6.5f && w2.tz == 8f, "strafe right goes east")
        check(w3.ty == 4.5f, "fly up")
        val east = eye.copy(yaw = -90f).walk(1f, 0f, 0f)
        check(Math.abs(east.tx - 6.5f) < 1e-3f, "turning right (yaw -90) walks east: ${east.tx}")
        val pj = Projector(eye, 1080f, 1800f); val o = FloatArray(2)
        pj.project(5.5f, 2.5f, 2.5f, o, 0)
        val pk = Picker.pick(mm, eye, 1080f, 1800f, o[0], o[1], 0, false, 0)
        check(pk != null && pk.hit && pk.bx == 5 && pk.by == 2 && pk.bz == 2, "first-person pick ${pk?.let { "${it.bx},${it.by},${it.bz}" }}")
        val down = eye.copy(pitch = 60f)
        val pj2 = Projector(down, 1080f, 1800f); pj2.project(2.5f, 1.0f, 6.5f, o, 0)
        val pk2 = Picker.pick(mm, down, 1080f, 1800f, o[0], o[1], 0, false, 0)
        check(pk2 != null && pk2.hit && pk2.bx == 2 && pk2.bz == 6, "first-person pick looking down ${pk2?.let { "${it.bx},${it.by},${it.bz}" }}")
    }

    // custom 3D model from a pack
    val mset = PackScanner.scanAll(listOf(java.io.File("$out/model.mcaddon").readBytes()))
    val lamp = mset.blocks.firstOrNull { it.id == "my_pack:lamp" }
    val lm = lamp?.model
    check(lm != null && lm.faces.size == 17 && lm.texW == 32, "model parsed faces=${lm?.faces?.size}")
    check(lamp?.boneTextures?.get("*") == "textures/blocks/lamp_tex", "model texture resolved ${lamp?.boneTextures}")
    check(lm != null && lm.faces.all { f -> f.corners.all { it > -0.5f && it < 1.5f } }, "model corners in cell space")
    run {
        val vm2 = TextureMap.parse(java.io.File("$out/assets/block_textures.txt").readText())
        val big = java.awt.image.BufferedImage(1024, 256 + 64, java.awt.image.BufferedImage.TYPE_INT_ARGB)
        val van = javax.imageio.ImageIO.read(java.io.File("$out/assets/atlas.png"))
        big.graphics.drawImage(van, 0, 0, null)
        val lt = javax.imageio.ImageIO.read(java.io.ByteArrayInputStream(mset.textures.getValue("textures/blocks/lamp_tex").bytes))
        big.graphics.drawImage(lt, 0, 256, 64, 64, null)
        val tid = vm2.addPackRect(0, 256, 64, 64)
        vm2.putModel("my_pack:lamp", TextureMap.ModelEntry(lm!!, mapOf("*" to tid), tid))
        val mm = BuildModel.create(3, 2, 3); val ss = EditSession(mm)
        ss.apply(Op.PLACE, ShapeKind.BOX, intArrayOf(0, 0, 0), intArrayOf(2, 0, 2), false, SingleBlock(BlockState("minecraft:stone")), false)
        ss.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(1, 1, 1), intArrayOf(1, 1, 1), false, SingleBlock(BlockState("my_pack:lamp")), false)
        val mmesh = MeshBuilder.build(mm, false, 0, vm2)
        val img2 = java.awt.image.BufferedImage(480, 360, java.awt.image.BufferedImage.TYPE_INT_ARGB)
        for (y in 0 until 360) for (x in 0 until 480) img2.setRGB(x, y, 0xFF1C2532.toInt())
        val fr2 = FrameRenderer()
        fr2.render(mmesh, Camera.fit(mm, 35f, 25f).copy(dist = 7f), 480f, 360f, false) { q ->
            for (i in 0 until q) for (tri in 0..1) raster(img2, big, fr2, i, if (tri == 0) intArrayOf(0, 1, 2) else intArrayOf(0, 2, 3))
        }
        javax.imageio.ImageIO.write(img2, "png", java.io.File("$out/model_render.png"))
        check(mmesh.count > 17, "model mesh faces ${mmesh.count}")
    }

    // textured mesh rendered with a tiny software rasteriser to check UV orientation
    val atlasImg = javax.imageio.ImageIO.read(java.io.File("$out/assets/atlas.png"))
    val tm = TextureMap.parse(java.io.File("$out/assets/block_textures.txt").readText())
    check(tm.entry("minecraft:grass") != null && tm.entry("minecraft:grass_block") != null, "texture map has grass (alias) ${tm.size}")
    val m4 = BuildModel.create(6, 5, 6); val s4 = EditSession(m4)
    s4.apply(Op.PLACE, ShapeKind.BOX, intArrayOf(0, 0, 0), intArrayOf(5, 1, 5), false, SingleBlock(BlockState("minecraft:grass")), false)
    s4.apply(Op.PLACE, ShapeKind.BOX, intArrayOf(1, 2, 1), intArrayOf(3, 3, 3), false, SingleBlock(BlockState("minecraft:oak_planks")), false)
    s4.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(4, 2, 4), intArrayOf(4, 2, 4), false, SingleBlock(BlockState("minecraft:oak_log", mapOf("pillar_axis" to "x"))), false)
    s4.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(5, 2, 1), intArrayOf(5, 2, 1), false, SingleBlock(BlockState("minecraft:torch")), false)
    s4.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(5, 2, 3), intArrayOf(5, 2, 3), false, SingleBlock(BlockState("minecraft:short_grass")), false)
    s4.apply(Op.PLACE, ShapeKind.SINGLE, intArrayOf(2, 4, 2), intArrayOf(2, 4, 2), false, SingleBlock(BlockState("minecraft:oak_stairs", mapOf("weirdo_direction" to 0))), false)
    val mesh = MeshBuilder.build(m4, false, 0, tm)
    val W = 640; val H = 480
    val img = java.awt.image.BufferedImage(W, H, java.awt.image.BufferedImage.TYPE_INT_ARGB)
    for (y in 0 until H) for (x in 0 until W) img.setRGB(x, y, 0xFF1C2532.toInt())
    val fr = FrameRenderer()
    val cam = Camera.fit(m4, 35f, 30f)
    fr.render(mesh, cam, W.toFloat(), H.toFloat(), false) { q ->
        for (i in 0 until q) for (tri in 0..1) {
            val ids = if (tri == 0) intArrayOf(0, 1, 2) else intArrayOf(0, 2, 3)
            raster(img, atlasImg, fr, i, ids)
        }
    }
    javax.imageio.ImageIO.write(img, "png", java.io.File("$out/render.png"))
    check(mesh.count > 100, "textured mesh faces ${mesh.count}")
}

fun raster(img: java.awt.image.BufferedImage, atlas: java.awt.image.BufferedImage, fr: FrameRenderer, q: Int, v: IntArray) {
    val px = FloatArray(3); val py = FloatArray(3); val u = FloatArray(3); val w = FloatArray(3); val col = IntArray(3)
    for (k in 0..2) { px[k] = fr.verts[q * 8 + v[k] * 2]; py[k] = fr.verts[q * 8 + v[k] * 2 + 1]; u[k] = fr.texs[q * 8 + v[k] * 2]; w[k] = fr.texs[q * 8 + v[k] * 2 + 1]; col[k] = fr.colors[q * 4 + v[k]] }
    val minx = maxOf(0, minOf(px[0], minOf(px[1], px[2])).toInt()); val maxx = minOf(img.width - 1, maxOf(px[0], maxOf(px[1], px[2])).toInt() + 1)
    val miny = maxOf(0, minOf(py[0], minOf(py[1], py[2])).toInt()); val maxy = minOf(img.height - 1, maxOf(py[0], maxOf(py[1], py[2])).toInt() + 1)
    val den = (py[1] - py[2]) * (px[0] - px[2]) + (px[2] - px[1]) * (py[0] - py[2])
    if (den == 0f) return
    for (y in miny..maxy) for (x in minx..maxx) {
        val a = ((py[1] - py[2]) * (x + .5f - px[2]) + (px[2] - px[1]) * (y + .5f - py[2])) / den
        val b = ((py[2] - py[0]) * (x + .5f - px[2]) + (px[0] - px[2]) * (y + .5f - py[2])) / den
        val c = 1 - a - b
        if (a < -0.001 || b < -0.001 || c < -0.001) continue
        val uu = (a * u[0] + b * u[1] + c * u[2]).toInt().coerceIn(0, atlas.width - 1)
        val vv = (a * w[0] + b * w[1] + c * w[2]).toInt().coerceIn(0, atlas.height - 1)
        val t = atlas.getRGB(uu, vv)
        val ta = (t ushr 24) / 255f
        val cm = col[0]
        val r = (((t shr 16) and 255) * ((cm shr 16) and 255) / 255); val g = (((t shr 8) and 255) * ((cm shr 8) and 255) / 255); val bl = ((t and 255) * (cm and 255) / 255)
        val dst = img.getRGB(x, y)
        val rr = (r * ta + ((dst shr 16) and 255) * (1 - ta)).toInt(); val gg = (g * ta + ((dst shr 8) and 255) * (1 - ta)).toInt(); val bb = (bl * ta + (dst and 255) * (1 - ta)).toInt()
        img.setRGB(x, y, (255 shl 24) or (rr shl 16) or (gg shl 8) or bb)
    }
}
